/*
 (C) 2005  Petr La�tovi�ka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
#include <windows.h>
#include <richedit.h>
#include <stdio.h>
#include "resource.h"

#define ID_CHECK 990
#define ID_SCROLL 991

#define MAX_CHECK 61 //must be odd number
const int edWidth=268;
const short DX=1,DY=1,DZ=1;
          
int
 width=550,	
 height=350,      
 left=50,
 top=60,            
 split=400,
 timeIncr=99,
 idleTime=9000,
 scrollUp=5,
 scrollDown=1,
 shiftStroke=0,
 mistakeSound=0,
 time,
 timeLimit,
 lastErrors,
 corrections,
 errors,
 errorLimit,
 errorPercentLimit,
 keyStrokes,
 edLen[2],
 playing,
 lost,
 DerrArray;


DWORD lastTime,lastKeyTime;

typedef char *Pchar;
Pchar zadani,instrukce,fileContent;

char *richEditClass;
static int oldW,oldH;
static WPARAM lastChar;

bool *errArray; 
bool
 resizing,
 delreg;

typedef char TfileName[MAX_PATH];
TfileName fnLecture;
HWND hWin,hEd[2];
HINSTANCE inst;
HACCEL haccel;
WNDPROC editProc;
LOGFONT font;
HFONT hFont;
char *title="Psan�"; 

const char
 *subkey="Software\\Petr Lastovicka\\typewriter";
struct Treg { char *s; int *i; } regVal[]={
{"height",&height},
{"width",&width},
{"X",&left},
{"Y",&top},
{"split",&split},
{"scrollDown",&scrollDown},
{"scrollUp",&scrollUp},
{"idleTime",&idleTime},
{"shiftStroke",&shiftStroke},
{"soundErr",&mistakeSound},
};
struct Tregs { char *s; char *i; DWORD n; } regValS[]={
{"file",fnLecture,sizeof(fnLecture)},
};

struct Tregb { TCHAR *s; void *i; DWORD n; } regValB[]={
{"font",&font,sizeof(LOGFONT)},
};

OPENFILENAME ofn={
 sizeof(OPENFILENAME),0, 0,
 "Lekce (*.les)\0*.les\0V�echny soubory\0*.*\0",
 0,0,1,
 fnLecture, sizeof(fnLecture)-10,
 0,0,0, 0, 0,0,0, "TXT", 0,0,0
};
//-----------------------------------------------------------------

#define endA(a) (a+(sizeof(a)/sizeof(*a)))

template <class T> inline void amax(T &x,int h){
 if(int(x)>h) x=h;
}

template <class T> inline void aminmax(T &x,int l,int h){
 if(int(x)<l) x=l;
 if(int(x)>h) x=h;
}

//-----------------------------------------------------------------
int vmsg(HWND w, char *caption, char *text, int btn, va_list v)
{
  char buf[1024];
  if(!text) return IDCANCEL;
  _vsnprintf(buf,sizeof(buf),text,v);
  buf[sizeof(buf)-1]=0;
  return MessageBox(w,buf,caption,btn);
}

void msg(char *text, ...)
{
  va_list ap;
  va_start(ap,text);
  vmsg(hWin,title,text,MB_OK|MB_ICONERROR,ap);
  va_end(ap);
}

int msg1(int btn, char *text, ...)
{
  va_list ap;
  va_start(ap,text);
  int result=vmsg(hWin,title,text,btn,ap);
  va_end(ap);
  return result;
}

//return pointer to name after a path
char *cutPath(const char *s)
{
  char *t;
  t=strchr(s,0);
  while(t>=s && *t!='\\') t--;
  t++;
  return t;
}

//concatenate current directory and e, write result to fn
void getExeDir(char *fn, char *e)
{
  GetModuleFileName(0,fn,192);
  strcpy(cutPath(fn), e);
}

HANDLE openFile(char *fn)
{
  HANDLE f=CreateFile(fn,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);
  if(f==INVALID_HANDLE_VALUE){
    if(fn[0]) msg("Nelze otev��t %s",fn);
  }
  return f;
}

bool openDlg(OPENFILENAME *o)
{
  for(;;){
    o->hwndOwner= hWin;
    o->Flags= OFN_FILEMUSTEXIST|OFN_HIDEREADONLY;
    if(GetOpenFileName(o)) return true;  //ok
    if(CommDlgExtendedError()!=FNERR_INVALIDFILENAME
      || !o->lpstrFile[0]) return false; //cancel
    o->lpstrFile[0]=0;
  }
}

bool isBetweenInOut(LPARAM lP,int &y)
{
  int x=(short)LOWORD(lP);
  y=(short)HIWORD(lP);
  RECT rc;
  GetWindowRect(hEd[0],&rc);
  MapWindowPoints(0,hWin,(POINT*)&rc,2);
  return y>rc.bottom && y<rc.bottom+9 && x<rc.right;
}

void resizeInOut(int y)
{
  RECT rcI,rcO;
  int i,hi,ho;

  GetWindowRect(hEd[0],&rcI);
  MapWindowPoints(0,hWin,(POINT*)&rcI,2);
  GetWindowRect(hEd[1],&rcO);
  MapWindowPoints(0,hWin,(POINT*)&rcO,2);
  i=rcI.right-rcI.left;
  aminmax(y, rcI.top+22, rcO.bottom-22);
  HDWP p=BeginDeferWindowPos(2);
  hi= y-rcI.top-4;
  DeferWindowPos(p,hEd[0],0,0,0,i,hi,SWP_NOMOVE|SWP_NOZORDER);
  ho= rcO.bottom-y-4;
  DeferWindowPos(p,hEd[1],0,rcO.left,y+4,i,ho,SWP_NOZORDER);
  EndDeferWindowPos(p);
  split= y*1000/(height-30);
}

HWND createRichEdit(int x,int y,int r,int b,int id, DWORD style)
{
  RECT rc;
  SetRect(&rc,x,y,r,b);
  MapDialogRect(hWin,&rc);
  HWND w=CreateWindowEx(0,richEditClass,"",
    ES_MULTILINE|ES_AUTOVSCROLL|WS_BORDER|WS_VISIBLE|WS_CHILD|style,
    rc.left,rc.top, rc.right-rc.left, rc.bottom-rc.top, 
    hWin,(HMENU)id,inst,0);
  SendMessage(w,EM_SETLANGOPTIONS,0,0);
  SendMessage(w,EM_SETUNDOLIMIT,0,0);   
  return w;
}

void setFont()
{
  HFONT oldF=hFont;
  hFont=CreateFontIndirect(&font);
  SendMessage(hEd[0],WM_SETFONT,(WPARAM)hFont,(LPARAM)MAKELPARAM(TRUE,0));
  SendMessage(hEd[1],WM_SETFONT,(WPARAM)hFont,(LPARAM)MAKELPARAM(TRUE,0));
  DeleteObject(oldF);
}

//-----------------------------------------------------------------
void deleteini()
{
  HKEY key;
  DWORD i;
  
  delreg=true;
  if(RegDeleteKey(HKEY_CURRENT_USER, subkey)==ERROR_SUCCESS){
    if(RegOpenKey(HKEY_CURRENT_USER,
      "Software\\Petr Lastovicka",&key)==ERROR_SUCCESS){
      i=1;
      RegQueryInfoKey(key,0,0,0,&i,0,0,0,0,0,0,0);
      RegCloseKey(key);
      if(!i)
        RegDeleteKey(HKEY_CURRENT_USER, "Software\\Petr Lastovicka");
    }
  }
}
       
void writeini()
{
  HKEY key;
  if(RegCreateKey(HKEY_CURRENT_USER, subkey, &key)!=ERROR_SUCCESS)
    msg("Nepoda�ilo se zapsat konfiguraci do registru");
  else{
    for(Treg *u=regVal; u<endA(regVal); u++){
      RegSetValueEx(key, u->s, 0,REG_DWORD,
        (BYTE *)u->i, sizeof(int));
    }
    for(Tregs *v=regValS; v<endA(regValS); v++){
      RegSetValueEx(key, v->s, 0,REG_SZ,
        (BYTE *)v->i, strlen(v->i)+1);
    }
    for(Tregb *w=regValB; w<endA(regValB); w++){
      RegSetValueEx(key, w->s, 0,REG_BINARY, (BYTE *)w->i, w->n);
    }
    RegCloseKey(key);
  }
}

void readini()
{
  HKEY key;
  DWORD d;

  if(RegOpenKey(HKEY_CURRENT_USER, subkey, &key)==ERROR_SUCCESS){
    for(Treg *u=regVal; u<endA(regVal); u++){
      d=sizeof(int);
      RegQueryValueEx(key,u->s,0,0, (BYTE *)u->i, &d);
    }
    for(Tregs *v=regValS; v<endA(regValS); v++){
      d=v->n;
      RegQueryValueEx(key,v->s,0,0, (BYTE *)v->i, &d);
    }
    for(Tregb *w=regValB; w<endA(regValB); w++){
      d=w->n;
      RegQueryValueEx(key,w->s,0,0, (BYTE *)w->i, &d);
    }
    RegCloseKey(key);
  }
}

void saveAtExit()
{
  if(!delreg) writeini();
}

//-----------------------------------------------------------------
BOOL CALLBACK OptionsProc(HWND hWnd, UINT mesg, WPARAM wP, LPARAM )
{
  switch(mesg){
  case WM_INITDIALOG:
    CheckDlgButton(hWnd,IDC_SHIFT,shiftStroke ? BST_CHECKED:BST_UNCHECKED);
    CheckDlgButton(hWnd,IDC_SOUND,mistakeSound ? BST_CHECKED:BST_UNCHECKED);
    SetDlgItemInt(hWnd,IDC_IDLETIME,idleTime/1000,FALSE);
    SetDlgItemInt(hWnd,IDC_MAX_UP,scrollUp,FALSE);
    SetDlgItemInt(hWnd,IDC_MIN_DOWN,scrollDown,FALSE);
    return TRUE;
  
  case WM_COMMAND:
    wP=LOWORD(wP);
    switch(wP){
    case IDOK:
      shiftStroke= IsDlgButtonChecked(hWnd,IDC_SHIFT);
      mistakeSound= IsDlgButtonChecked(hWnd,IDC_SOUND);
      idleTime= 1000*GetDlgItemInt(hWnd,IDC_IDLETIME,0,FALSE);
      scrollUp= GetDlgItemInt(hWnd,IDC_MAX_UP,0,FALSE);
      scrollDown= GetDlgItemInt(hWnd,IDC_MIN_DOWN,0,FALSE);
    case IDCANCEL: 
      EndDialog(hWnd,wP);
    break;
    }
  }
  return FALSE;
}

BOOL CALLBACK FinishProc(HWND hWnd, UINT mesg, WPARAM wP, LPARAM lP)
{
  static DWORD initTime;

  switch(mesg){
  case WM_INITDIALOG:
    initTime=GetTickCount();
    if(lP) SetDlgItemText(hWnd,IDC_MSG,(char*)lP);
    SetFocus(GetDlgItem(hWnd, lost ? ID_AGAIN : ID_NEXT ));
    SetWindowPos(hWnd,0,left+50,top+130,0,0,SWP_NOZORDER|SWP_NOSIZE);
    return FALSE;
  
  case WM_COMMAND:
    wP=LOWORD(wP);
    switch(wP){
    case ID_NEXT:
    case ID_AGAIN:
    case IDCANCEL: 
      if(GetTickCount()-initTime>400) EndDialog(hWnd,wP);
      break;
    }
  }
  return FALSE;
}

DWORD getVer()
{
 HRSRC r;
 HGLOBAL h;
 void *s;
 VS_FIXEDFILEINFO *v;
 UINT i;

 r=FindResource(0,(char*)VS_VERSION_INFO,RT_VERSION);
 h=LoadResource(0,r);
 s=LockResource(h);
 if(!s || !VerQueryValue(s,"\\",(void**)&v,&i)) return 0;
 return v->dwFileVersionMS;
}
 
BOOL CALLBACK AboutProc(HWND hWnd, UINT mesg, WPARAM wP, LPARAM )
{
 char buf[16];
 DWORD d;
 
 switch(mesg){
  case WM_INITDIALOG:
   d=getVer();
   sprintf(buf,"%d.%d",HIWORD(d),LOWORD(d));
   SetDlgItemText(hWnd,101,buf);
   return TRUE;

  case WM_COMMAND:
    wP=LOWORD(wP);
    switch(wP){
    case IDOK: case IDCANCEL:
      EndDialog(hWnd, wP);
    }
    break;
  }
  return FALSE;
}

UINT APIENTRY CFHookProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM )
{
  if(message==WM_COMMAND && LOWORD(wParam)==1026){
    SendMessage(hDlg, WM_CHOOSEFONT_GETLOGFONT, 0, (LPARAM)&font);
    setFont();
    return 1;
  }         
  return 0;
}
//-----------------------------------------------------------------

void showInstructions()
{
  if(instrukce && *instrukce){
    msg1(MB_OK|MB_ICONINFORMATION,"%s",instrukce);
  }
}

void repaintTime()
{
  char s[32];
  sprintf(s,"%.1f", double(time)/1000);
  SetDlgItemText(hWin,IDC_TIME,s);
}

void repaintLimit()
{
  char s[32];
  if(!timeLimit) SetDlgItemText(hWin,IDC_TIME_LIMIT,"-");
  else SetDlgItemInt(hWin,IDC_TIME_LIMIT,timeLimit,FALSE);
  if(!errorLimit){
    s[0]='-';
    s[1]=0;   
  }else{
    sprintf(s,"%d  (%d%%)",errorLimit,errorPercentLimit);
  }
  SetDlgItemText(hWin,IDC_ERR_LIMIT,s);
}

void repaintErrors()
{
  char s[64];
  double p;
  int n;

  if(!edLen[1]){
    itoa(corrections,s,10);
  }else{
    n=errors+corrections;
    if(!n){
      s[0]='0';
      s[1]=0;
    }else{
      p= n*100/double(edLen[1]);
      if(corrections) sprintf(s,"%d=%d+%d   (%.2f%%)",n,errors,corrections,p);
      else sprintf(s,"%d       (%.2f%%)",n,p);
    }
  }
  SetDlgItemText(hWin,IDC_ERRORS,s);
}

void repaintKeystrokes()
{
  SetDlgItemInt(hWin,IDC_COUNT,keyStrokes,FALSE);
  if(time<2000) SetDlgItemText(hWin,IDC_RATE,"");
  else SetDlgItemInt(hWin,IDC_RATE, keyStrokes*60000/time,FALSE);
}

void onTimer()
{
  DWORD t=lastTime;
  lastTime=GetTickCount();
  if(!playing) return;
  time+= lastTime-t;
  repaintTime();
}

void startStop()
{
  onTimer();
  playing=!playing;
  if(playing){
    SetTimer(hWin,1000,timeIncr,0);
  }else{
    KillTimer(hWin,1000);
  }
}

void stop()
{
  if(playing) startStop();
}

void play()
{
  if(!playing) startStop();
}

void restart()
{
  stop();
  lost=0;
  time=errors=corrections=keyStrokes=0;
  delete[] errArray;
  errArray=0;
  DerrArray=0;
  edLen[1]=0;
  lastKeyTime=0;
  repaintTime();
  repaintErrors();
  repaintKeystrokes();
  repaintLimit();
  SendMessage(hEd[0],EM_LINESCROLL,0,-9999);
  SetWindowText(hEd[1],"");
  SetFocus(hEd[1]);
}

void scroll()
{
  int i,curPos,top,bottom;
  CHARRANGE r0;
  POINTL pt;
  RECT rc;

  SendMessage(hEd[1],EM_EXGETSEL,0,(LPARAM)&r0);
  top=SendMessage(hEd[0],EM_GETFIRSTVISIBLELINE,0,0)+scrollUp;
  GetClientRect(hEd[0],&rc);
  pt.x=1; 
  pt.y=rc.bottom-2;
  i=LOWORD(SendMessage(hEd[0],EM_CHARFROMPOS,0,(LPARAM)&pt));
  bottom=SendMessage(hEd[0], EM_EXLINEFROMCHAR,0,i)-1-scrollDown;
  curPos=SendMessage(hEd[1], EM_EXLINEFROMCHAR,0,r0.cpMax);
  i=curPos-bottom;
  if(i<0){
    i=curPos-top;
    if(i<0 && i>-scrollUp) i=0;
  }
  if(i) SendMessage(hEd[0],EM_LINESCROLL,0,i);

}

LRESULT CALLBACK inProc(HWND hWnd, UINT mesg, WPARAM wP, LPARAM lP)
{
  if(mesg==WM_CHAR || mesg==WM_DEADCHAR){
    play();
    PostMessage(hWin,WM_COMMAND,ID_CHECK,0);
    if(wP!=8){
      keyStrokes++;
      if(shiftStroke && GetKeyState(VK_SHIFT)<0) keyStrokes++;
      repaintKeystrokes();
    }
    lastKeyTime=GetTickCount();
  }
  if(mesg==WM_KEYDOWN){
    if((wP==VK_BACK || wP==VK_DELETE) && wP!=lastChar){ 
      corrections++; 
      repaintErrors(); 
    }
    lastChar=wP;
    PostMessage(hWin,WM_COMMAND,ID_SCROLL,0);
  }
  LRESULT result=CallWindowProc((WNDPROC)editProc, hWnd, mesg, wP, lP);
  return result;
}

int openLecture(char *fn)
{
  //open file
  HANDLE f=openFile(fn);
  if(f==INVALID_HANDLE_VALUE) return 2;
  DWORD len=GetFileSize(f,0);
  if(len>50000){
    msg("Soubor je moc dlouh�");
    return 6;
  }
  //read file
  char *buf= new char[len+1];
  DWORD r;
  ReadFile(f,buf,len,&r,0);
  CloseHandle(f);
  buf[len]=0;
  
  //parse file
  timeLimit=0;
  errorLimit=0;
  zadani=strstr(buf,"[ZADANI]");
  if(!zadani){ 
    if(buf[0]=='['){
      zadani="";
      msg("Chybn� form�t souboru %s",cutPath(fn));
      delete[] buf; 
      return 5; 
    }
    zadani=buf;
  }else{
    zadani+=8;
  }
  char *cas=strstr(buf,"[CAS]");
  if(cas) timeLimit=atoi(cas+5);
  char *chybovost=strstr(buf,"[CHYBOVOST]");
  instrukce=strstr(buf,"[INSTRUKCE]");
  if(instrukce) instrukce+=11;
  else instrukce="";
  char *s=strchr(zadani,'[');
  if(s) *s=0;
  s=strchr(instrukce,'[');
  if(s) *s=0;
  char *d;
  for(s=d=zadani; ; s++,d++){
    if(*s=='\r' || *s=='\n'){
      //remove trailing spaces
      d--;
      while(d>=zadani && *d==' ') d--;
      d++;
    }
    *d=*s;
    if(*d=='\0') break;
    if(*d=='\t') *d=' ';
  }
  if(chybovost){
    errorPercentLimit= atoi(chybovost+11);
    errorLimit= int(d-zadani)*errorPercentLimit/100;
  }
  delete[] fileContent;
  fileContent=buf;
  //redraw window
  SetWindowText(hEd[0],zadani);
  char tit[128];
  _snprintf(tit,sizeof(tit),"%s - %s",title,cutPath(fn));
  tit[sizeof(tit)-1]=0;
  SetWindowText(hWin,tit);
  restart();
  return 0;
}

int openLecture()
{
  OPENFILENAME *o= &ofn;
  if(!openDlg(o)) return 1;
  return openLecture(o->lpstrFile);
}

int nextLecture(int rel)
{
  int i;
  char *s,*fn;
  char ext[16];

  fn=fnLecture;
  s=strchr(fn,'.');
  if(!s) s=strchr(fn,0);
  strncpy(ext,s,sizeof(ext));
  ext[sizeof(ext)-1]=0;
  s--;
  while(s>=fn && *s>='0' && *s<='9') s--;
  s++;
  i=atoi(s)+rel;
  if(i<0) return 4;
  sprintf(s,"%d%s",i,ext);
  return openLecture(fn);
}

void finish(char *mesg)
{
  stop();
  int i=DialogBoxParam(inst,MAKEINTRESOURCE(IDD_FINISH),hWin,FinishProc,(LPARAM)mesg);
  if(i==ID_NEXT){
    if(!nextLecture(1)) showInstructions();
  }
  if(i==ID_AGAIN){
    restart();
  }
}
//-----------------------------------------------------------------
#define CHCKLP \
  x=y=z=0x7ff0;\
  if(j>0) y=short(A[i][j-1]+DY);\
  if(j<MAX_CHECK-1) x=short(A[i-1][j+1]+DX);\
  k= i+j-checkWidth-1;\
  if(k>=0 && k<edLen[0]){\
    z=A[i-1][j];\
    neq= edBuf[0][k]!=edBuf[1][i-1];\
    if(neq) z+=DZ;\
  }\


void check()
{
  int i,j,k,len,neq,checkWidth;
  short x,y,z;
  bool isEnd;
  char *edBuf[2];
  short (*A)[MAX_CHECK];
  bool *B;
  CHARRANGE r,r0;
  CHARFORMAT cf;

  //read both edit boxes
  for(i=0; i<2; i++){
    edLen[i]=GetWindowTextLength(hEd[i]);
  }
  if(!edLen[0] || !edLen[1]) return;
  for(i=0; i<2; i++){
    edBuf[i]=new char[edLen[i]+1];
    TEXTRANGE tr;
    tr.lpstrText=edBuf[i];
    tr.chrg.cpMin=0;
    tr.chrg.cpMax=GetWindowTextLength(hEd[i]);
    edLen[i]=SendMessage(hEd[i],EM_GETTEXTRANGE,0,(LPARAM)&tr);
    edBuf[i][edLen[i]]=0;
  }
  len=edLen[1];
  SendMessage(hEd[1],EM_EXGETSEL,0,(LPARAM)&r0);
  SendMessage(hEd[1],WM_SETREDRAW,FALSE,0);

  //check
  checkWidth=(MAX_CHECK-1)/2;
  A= new short[len+1][MAX_CHECK];
  for(j=0; j<checkWidth; j++){
    A[0][j]=0x7ff0;
  }
  A[0][j++]=0;
  y=0;
  for(; j<MAX_CHECK; j++){
    y+=DY;
    A[0][j]=y;
  }
  for(i=1; i<=len; i++){
    for(j=0; j<MAX_CHECK; j++){
      CHCKLP
      A[i][j]=min(min(x,y),z);
    }
  }
  i=len;
  x=0x7fff;
  for(k=0; k<MAX_CHECK; k++){
    if(A[i][k]<x){
      x=A[i][k];
      j=k;
    }
  }
  isEnd= edLen[1]+j-checkWidth>=edLen[0];
  errors=0;
  B=new bool[len+2];
  memset(B,0,(len+1)*sizeof(bool));
  do{
    neq=1;
    CHCKLP
    errors++;
    if(A[i][j]==x){ 
      //extra character
      B[i]=1;
      i--; 
      j++; 
    }
    else if(A[i][j]==y){ 
      //missing character
      B[i+1]=1;
      j--; 
    }
    else{ //(A[i][j]==z)
      if(neq){
        //different character
        B[i]=1;
      }else{
        errors--;
      }
      i--; 
    }
  }while(i!=0);
  if(j>checkWidth){
    errors+=j-checkWidth;
    B[1]=1;
  }
  delete[] A;
  delete[] edBuf[0];
  delete[] edBuf[1];

  //change color
  cf.cbSize=sizeof(CHARFORMAT);
  cf.dwMask=CFM_COLOR;
  cf.dwEffects=0;
  for(i=1; i<=len; i++){
    if(i>DerrArray || B[i]!=errArray[i]){
      r.cpMin=i-1;
      r.cpMax=i;
      SendMessage(hEd[1],EM_EXSETSEL,0,(LPARAM)&r);
      cf.crTextColor= B[i] ? 0xff : 0;
      SendMessage(hEd[1],EM_SETCHARFORMAT,SCF_SELECTION,(LPARAM)&cf);
    }
  }
  delete[] errArray;
  errArray=B;
  DerrArray=len;
  //restore the caret position and repaint
  SendMessage(hEd[1],EM_EXSETSEL,0,(LPARAM)&r0);
  SendMessage(hEd[1],WM_SETREDRAW,TRUE,0);
  InvalidateRect(hEd[1],0,FALSE);
  repaintErrors();
  if(errors>lastErrors && mistakeSound){
    char buf[256];
    getExeDir(buf,"mistake.wav");
    PlaySound(buf,0,SND_FILENAME|SND_ASYNC|SND_NOWAIT);
  }
  lastErrors=errors;
  if(errors+corrections>errorLimit && errorLimit && !lost && lastChar!=VK_BACK){
    lost=1;
    finish("Nebyl spln�n limit chybovosti !");
  }
  else if(isEnd){
    finish("Konec lekce.");
  }       
}

//-----------------------------------------------------------------
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT mesg, WPARAM wP, LPARAM lP)
{
 static PAINTSTRUCT ps;
 int y,cmd;
 RECT rcw;

 switch(mesg){
 case WM_INITDIALOG:
   hWin= hWnd;
   hEd[0]=createRichEdit(5,28,edWidth,136,101,ES_READONLY);
   hEd[1]=createRichEdit(5,140,edWidth,166,102,ES_WANTRETURN);
   editProc = (WNDPROC) SetWindowLong(hEd[1],GWL_WNDPROC,(LONG)inProc);
   setFont();
   return TRUE;

 case WM_COMMAND:
   cmd=LOWORD(wP);
   switch(cmd){
   case ID_README:
     {                       
     static char buf[256];
     getExeDir(buf,"jakpsat.txt");
     if(ShellExecute(0,"open",buf,0,0,SW_SHOWNORMAL)==(HINSTANCE)ERROR_FILE_NOT_FOUND){
       msg("Nenalezen soubor %s",buf);
     }
     }
     break;
   case ID_ABOUT:
     DialogBox(inst, MAKEINTRESOURCE(IDD_ABOUT), hWnd, (DLGPROC) AboutProc);
     break;
   case ID_EXIT:
     SendMessage(hWin,WM_CLOSE,0,0);
     break;
   case ID_WRINI: 
     writeini();
     break;
   case ID_DELINI:
     if(msg1(MB_ICONQUESTION | MB_YESNO | MB_DEFBUTTON2,
       "Chcete smazat v�echna nastaven� ?") ==IDYES){
       deleteini();
     }
     break;
   case ID_FONT:
     {
       static CHOOSEFONT f;
       f.lStructSize=sizeof(CHOOSEFONT);
       f.hwndOwner=hWin;
       f.Flags=CF_SCREENFONTS|CF_INITTOLOGFONTSTRUCT|CF_SCRIPTSONLY|CF_ENABLEHOOK|CF_APPLY;
       f.lpLogFont=&font;
       f.lpfnHook=CFHookProc;
       if(ChooseFont(&f)) setFont();
     }
     break;
   case ID_OPEN_LECTURE:
     if(!openLecture()) showInstructions();
     break;
   case ID_INSTRUCTIONS:
     showInstructions();
     break;
   case ID_START_STOP:
     startStop();
     break;
   case ID_CLEAR:
     restart();
     break;
   case ID_NEXT_LECTURE:
     nextLecture(1);
     break;
   case ID_PREV_LECTURE:
     nextLecture(-1);
     break;
   case ID_OPTIONS:
     DialogBox(inst, MAKEINTRESOURCE(IDD_OPTIONS), hWnd, (DLGPROC) OptionsProc);
     break;
   case ID_CHECK:
     check();
     break;
   case ID_SCROLL:
     scroll();
     break;
   } 
   break;

 case WM_TIMER:
   onTimer();
   if(int(lastTime-lastKeyTime)>idleTime && lastKeyTime){
     stop();
   }
   if(time>timeLimit*1000 && timeLimit && !lost){
     lost=1;
     finish("Nebyl spln�n �asov� limit !");
   }
   break;

 case WM_SIZE:
   if(!lP) break;
   if(oldW){
     RECT rc,rcw;
     HWND w;
     int dw,dh;
     dw=LOWORD(lP)-oldW;
     dh=HIWORD(lP)-oldH;
     GetWindowRect(hWnd,&rcw);
     y= (rcw.bottom-rcw.top-30)*split/1000;
     HDWP p=BeginDeferWindowPos(2);
     w= hEd[0];
     GetWindowRect(w,&rc);
     MapWindowPoints(0,hWnd,(POINT*)&rc,2);
     DeferWindowPos(p,w,0,0,0, rc.right-rc.left+dw,
       y-rc.top-4, SWP_NOZORDER|SWP_NOMOVE);
     w= hEd[1];
     GetWindowRect(w,&rc);
     MapWindowPoints(0,hWnd,(POINT*)&rc,2);
     DeferWindowPos(p,w,0,rc.left, y+4, rc.right-rc.left+dw,
       rc.bottom-y-4+dh,SWP_NOZORDER);
     EndDeferWindowPos(p);
   }
   oldW=LOWORD(lP);
   oldH=HIWORD(lP);                
   break;
 case WM_GETMINMAXINFO:
   ((MINMAXINFO FAR*) lP)->ptMinTrackSize.x = 410;
   ((MINMAXINFO FAR*) lP)->ptMinTrackSize.y = 200;
   break;
 case WM_MOVE:
 case WM_EXITSIZEMOVE:
   if(!IsZoomed(hWnd) && !IsIconic(hWnd)){
     GetWindowRect(hWnd,&rcw);
     top= rcw.top;
     left= rcw.left;
     width= rcw.right-rcw.left;
     height= rcw.bottom-rcw.top;
   }
   break;
 case WM_MOUSEMOVE:
   {
   bool b=isBetweenInOut(lP,y);
   if(resizing){
     resizeInOut(y);
     b=true;
   }
   SetCursor(LoadCursor(0, b ? IDC_SIZENS:IDC_ARROW));
   break;
   }
 case WM_LBUTTONDOWN:
   if(isBetweenInOut(lP,y)){
     resizing=true;
     SetCapture(hWin);
   }
   break;
 case WM_LBUTTONUP:
   if(resizing){
     resizing=false;
     ReleaseCapture();
   }
   break;
 case WM_QUERYENDSESSION:
   saveAtExit();
   return FALSE;
 case WM_CLOSE:
   saveAtExit();
   DestroyWindow(hWin);
   break;
 case WM_DESTROY:
   PostQuitMessage(0);
   break;
   
 default:
   return FALSE;
 }
 return TRUE;
}
//-----------------------------------------------------------------
int pascal WinMain(HINSTANCE hInstance,HINSTANCE ,LPSTR,int )
{
 MSG mesg;
 WNDCLASS wc;

 inst=hInstance;
 font.lfHeight=-13;
 font.lfWeight=FW_NORMAL;
 font.lfCharSet=DEFAULT_CHARSET;
 strcpy(font.lfFaceName,"Courier New");
 getExeDir(fnLecture,"les\\lekce0.les");
 readini();

 int w=GetSystemMetrics(SM_CXSCREEN);
 int h=GetSystemMetrics(SM_CYSCREEN);
 aminmax(left,0,w-100);
 aminmax(top,0,h-100);
 aminmax(width,300,w);
 aminmax(height,200,h-16);

 wc.style=0;
 wc.lpfnWndProc=(WNDPROC)DefDlgProc;
 wc.cbClsExtra=0;
 wc.cbWndExtra=DLGWINDOWEXTRA;
 wc.hInstance=hInstance;
 wc.hIcon=LoadIcon(inst,MAKEINTRESOURCE(1));
 wc.hCursor=0;
 wc.hbrBackground=(HBRUSH)COLOR_BTNFACE;
 wc.lpszMenuName=MAKEINTRESOURCE(IDR_MENU);
 wc.lpszClassName="Psani";
 if(!RegisterClass(&wc)){ msg("RegisterClass error"); return 2; }
 richEditClass="RichEdit20A";
 HMODULE richLib=LoadLibrary("riched20.dll");
 if(!richLib){
   richLib=LoadLibrary("riched32.dll");
   richEditClass="RichEdit";
 }
 if(!richLib){ msg("Cannot find RICHED20.DLL or RICHED32.DLL"); return 4; }
 CreateDialog(hInstance,MAKEINTRESOURCE(IDD_MAIN),0,(DLGPROC)MainWndProc);
 if(!hWin){ msg("CreateDialog error"); return 3; }
 
 RECT rc;
 GetClientRect(hWin,&rc);
 oldW= rc.right-rc.left;
 oldH= rc.bottom-rc.top;
 MoveWindow(hWin,left,top,width,height,FALSE);
 ShowWindow(hWin,SW_SHOWDEFAULT);
 if(!openLecture(fnLecture)) showInstructions();

 haccel=LoadAccelerators(hInstance, MAKEINTRESOURCE(IDR_ACCEL));

 while(GetMessage(&mesg, NULL, 0, 0)>0){
   if(TranslateAccelerator(hWin,haccel,&mesg)==0){
     TranslateMessage(&mesg);
     DispatchMessage(&mesg);
   }
 }                       
 DeleteObject(hFont);
 FreeLibrary(richLib);
 return 0;
}
//-----------------------------------------------------------------
