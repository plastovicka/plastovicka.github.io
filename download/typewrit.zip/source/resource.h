//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by typewrit.rc
//
#define IDD_MAIN                        101
#define IDR_MENU                        102
#define IDD_ABOUT                       104
#define IDR_ACCEL                       105
#define IDD_FINISH                      106
#define IDD_OPTIONS                     108
#define IDC_TIME                        1001
#define IDC_ERRORS                      1002
#define IDC_COUNT                       1003
#define IDC_TIME_LIMIT                  1004
#define IDC_ERR_LIMIT                   1005
#define IDC_RATE                        1006
#define ID_AGAIN                        1007
#define ID_NEXT                         1008
#define IDC_MSG                         1010
#define IDC_RESULT_RATE                 1011
#define IDC_RESULT_ERR                  1012
#define IDC_SHIFT                       1013
#define IDC_IDLETIME                    1014
#define IDC_MIN_DOWN                    1015
#define IDC_MAX_UP                      1016
#define IDC_SOUND                       1017
#define ID_SOUBOR_KONEC                 40001
#define ID_EXIT                         40002
#define ID_ABOUT                        40003
#define ID_FONT                         40004
#define ID_DELINI                       40007
#define ID_WRINI                        40008
#define ID_README                       40009
#define ID_OPEN_LECTURE                 40010
#define ID_INSTRUCTIONS                 40011
#define ID_STATISTIC                    40012
#define ID_START_STOP                   40013
#define ID_CLEAR                        40014
#define ID_NEXT_LECTURE                 40015
#define ID_PREV_LECTURE                 40016
#define ID_IGNORE                       40018
#define ID_OPTIONS                      40019
#define IDC_STATIC                      -1


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40020
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
