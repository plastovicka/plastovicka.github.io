/*
 (C) 1.4.1998 - 24.5.2002  Petr La�tovi�ka
 
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <math.h>
#include <windows.h>
#include "scrnsave.h"

#ifndef __BORLANDC__
#include <time.h>
inline int random(int num){ return(int)(((long)rand()*num)/(RAND_MAX+1));}
inline void randomize() { srand((unsigned) time(NULL)); }
#endif
/*
USERC("Kruhy.rc");
//---------------------------------------------------------------------------
*/
const int citlivost=40; // citlivost my�i
HGDIOBJ penblack;

#define Mpocet 30

struct kruh
{
  COLORREF b;   //barva
  double x,y;   //poloha st�edu (v pixlech)
  int x1,y1;    //poloha nakreslen� koule
  double xs,ys; //vektor rychlosti
  unsigned r;   //polom�r
  double m;     //hmotnost
} k[Mpocet];

int pocet;    //po�et koul�
int rychlost; //po�et krok� p�i jednom vyvol�n� �asova�e
int velikost; //velikost koul�

int Width,Height; //velikost obrazovky
int skryjmys,ontop=1;
POINT mys;

const char *subkey="Software\\Petr Lastovicka\\kruhy";
const struct Treg { char *s; int *i; int def,min,max; } regVal[]={
{"speed",&rychlost,3,1,11},
{"count",&pocet,15,1,Mpocet},
{"size",&velikost,13,1,30}};
bool modif;
//---------------------------------------------------------------------------
void OnTimer(HWND hWin)
{
 struct kruh *u,*v;
 int o,i,p,sx,sy;
 double a,x,y;
 unsigned r;
 int x2,y2;
 HDC hdc;

  hdc=GetDC(hWin);
  SelectObject(hdc,penblack);
  SelectObject(hdc,GetStockObject(NULL_BRUSH));

  if(skryjmys>0){
    skryjmys--;
    if(!skryjmys) GetCursorPos(&mys);
  }

  for(p=0;p<rychlost;p++){
  //zpracuj v�echny koule
   for(o=1,u=k; o<=pocet; o++,u++){
    r=u->r;
   //posu�
    u->x+= u->xs; u->y+= u->ys;
   //nakresli
    x2= (int) u->x;
    y2= (int) u->y;
    Ellipse(hdc,u->x1 - r,u->y1 - r,u->x1 + r,u->y1 + r);
    SelectObject(hdc, CreatePen(PS_SOLID,1,u->b));
    Ellipse(hdc,x2-r,y2-r,x2+r,y2+r);
    DeleteObject(SelectObject(hdc,penblack));
    u->x1= x2; u->y1= y2;
   //sr�ky
    for(i=o,v=k+o; i<pocet; i++,v++){
     if(sqrt((u->x-v->x)*(u->x-v->x)+(u->y-v->y)*(u->y-v->y)) < r+v->r+1 ){
       sx= (int) (v->x - u->x); 
           sy= (int) (v->y - u->y);
       a=((u->xs-v->xs)*sx+(u->ys-v->ys)*sy)*2/(sx*sx+sy*sy)/(u->m+v->m);
       if(a>0){  //odraz jen sm�rem od sebe
         u->xs-= a*sx*v->m; u->ys-= a*sy*v->m;
         v->xs+= a*sx*u->m; v->ys+= a*sy*u->m;
       }
     }
    }
  //odrazy od kraj�
    x=u->x + u->xs;
    y=u->y + u->ys;
    if(x-r<1 || x+r>Width) u->xs=-u->xs;
    if(y-r<1 || y+r>Height) u->ys=-u->ys;
   }
  }
  ReleaseDC(hWin,hdc);
}
//---------------------------------------------------------------------------
void generuj()
{
 struct kruh *u,*v;
 int i,j,o;
 double K;
 int R,G,B;
 int opak,opak2;

  opak2=0;
 start:
  opak2++;
  if(opak2>10) velikost--, opak2=0;
  for(i=0, u=k; i<pocet; i++,u++){
  //velikosti
   o= (Width+Height)*velikost/500;
   u->r= random(o) + o/2;
   u->m= (double)(u->r)*(u->r)/10;
  //poloha
   opak=0;
  znovu:
   opak++;
   if(opak>1000) goto start;
   u->x= random(Width- 2*(u->r +10))+u->r +10;
   u->y= random(Height- 2*(u->r +10))+u->r +10;
   for(j=0,v=k; j<i; j++,v++)
     if(sqrt((u->x-v->x)*(u->x-v->x)+(u->y-v->y)*(u->y-v->y)) <
       u->r + v->r +10) goto znovu;
   u->x1= (int) u->x;
   u->y1= (int) u->y;
  //sm�r pohybu
   u->xs= (double)(random(60)-30)/10;
   u->ys= (double)(random(60)-30)/10;
  //barvy, jas je u v�ech stejn�
   R=random(256); G=random(256); B=random(256);
   K=700.0/(R+G+B+1);
   R=(int) (R*K); 
   G=(int) (G*K);
   B=(int) (B*K); 
   if(R>255) R=255;
   if(G>255) G=255;
   if(B>255) B=255;
   u->b= RGB(R,G,B);
  }
}
//---------------------------------------------------------------------------
void defaultini()
{
 for(int k=0; k<sizeof(regVal)/sizeof(Treg); k++){
   *regVal[k].i = regVal[k].def;
 }
}

void deleteini()
{
 HKEY key;
 DWORD i;

 modif=false;
 if(RegDeleteKey(HKEY_CURRENT_USER, subkey)==ERROR_SUCCESS){
  if(RegOpenKey(HKEY_CURRENT_USER,
    "Software\\Petr Lastovicka",&key)==ERROR_SUCCESS){
   i=1;
   RegQueryInfoKey(key,0,0,0,&i,0,0,0,0,0,0,0);
   RegCloseKey(key);
   if(!i) RegDeleteKey(HKEY_CURRENT_USER, "Software\\Petr Lastovicka");
  }
 }
 defaultini(); 
}

void writeini()
{
 HKEY key;
 modif=false;
 if(RegCreateKey(HKEY_CURRENT_USER, subkey, &key)!=ERROR_SUCCESS)
   MessageBox(NULL,"Nelze ulo�it nastaven� do registr� Windows.",
     "Kruhy", MB_OK|MB_ICONWARNING);
 else{
  for(int k=0; k<sizeof(regVal)/sizeof(Treg); k++)
    RegSetValueEx(key,regVal[k].s,0,REG_DWORD,
      (BYTE *)regVal[k].i, sizeof(int));
  RegCloseKey(key);
 }
}

void readini()
{
 HKEY key;
 DWORD d;

 defaultini(); 
 if(RegOpenKey(HKEY_CURRENT_USER, subkey, &key)==ERROR_SUCCESS){
  for(int k=0; k<sizeof(regVal)/sizeof(Treg); k++){
    d=sizeof(int);
    RegQueryValueEx(key,regVal[k].s,0,0, (BYTE *)regVal[k].i, &d);
  }
  RegCloseKey(key);
 }
}
//---------------------------------------------------------------------------
BOOL WINAPI ScreenSaverConfigureDialog(HWND hDlg, UINT msg, WPARAM wP, LPARAM lP)
{
  int *val;
  HWND h;
  int i;
  const Treg *rg;

  switch(msg){
   case WM_INITDIALOG: 
     readini();
     for(i=0; i<3; i++){
       h=GetDlgItem(hDlg, 101+i);
       SetScrollRange(h, SB_CTL, regVal[i].min, regVal[i].max, FALSE);
       SetScrollPos(h, SB_CTL, *regVal[i].i, TRUE); 
     }
   return TRUE;
   case WM_HSCROLL:
     rg = &regVal[GetDlgCtrlID((HWND)lP)-101]; 
     val = rg->i;
     switch (LOWORD(wP)) { 
      case SB_PAGEUP: 
      case SB_LINEUP: 
        --*val; 
      break; 
      case SB_PAGEDOWN: 
      case SB_LINEDOWN: 
        ++*val; 
      break; 
      case SB_THUMBTRACK: 
      case SB_THUMBPOSITION: 
        *val = HIWORD(wP); 
      break; 
      case SB_BOTTOM: 
        *val = rg->min;
      break; 
      case SB_TOP: 
        *val = rg->max;
      break;
     } 
     if(*val > rg->max) *val = rg->max;
     if(*val < rg->min) *val = rg->min;
     SetScrollPos((HWND)lP, SB_CTL, *val, TRUE); 
   break;
   case WM_COMMAND: 
   switch(LOWORD(wP)){ 
    case IDOK: 
      writeini();
    case IDCANCEL: 
      EndDialog(hDlg, LOWORD(wP)==IDOK); 
    return TRUE; 
   } 
   break;
  }
  return FALSE;
}
//---------------------------------------------------------------------------
BOOL WINAPI RegisterDialogClasses(HANDLE )  
{ 
  return TRUE; 
} 
//---------------------------------------------------------------------------
LRESULT WINAPI ScreenSaverProc(HWND hWnd, UINT msg, WPARAM wP, LPARAM lP)
{
 switch (msg) {
 case WM_CREATE:
   Sleep(200);
   Width = ((CREATESTRUCT*)lP)->cx;
   Height = ((CREATESTRUCT*)lP)->cy;
   readini();
   penblack= GetStockObject(BLACK_PEN);
   randomize();
   generuj();
   SetTimer(hWnd,1,20,NULL);
 break;
 case WM_MOUSEMOVE:
  if(Width<600) return DefScreenSaverProc(hWnd, msg, wP, lP);
  skryjmys=10;
  if(ontop && mys.x && mys.y &&
    (abs(LOWORD(lP)-mys.x) > citlivost ||
     abs(HIWORD(lP)-mys.y) > citlivost) )
     DestroyWindow(hWnd);
 break;

 case WM_TIMER:
  OnTimer(hWnd);
 break;

 case WM_KEYDOWN:
  if(wP==VK_F1){
   ontop^=1;
   SetWindowPos(hWnd,ontop ? HWND_TOPMOST:HWND_BOTTOM,
      0,0,0,0,SWP_NOSIZE|SWP_NOMOVE);
  }else if(wP==VK_F2){
    generuj();
    InvalidateRect(hWnd,NULL,TRUE);
  }else if(wP==VK_F3){
   if(pocet>regVal[1].min){
     pocet--;
     generuj();
     InvalidateRect(hWnd,NULL,TRUE);
     modif=true;
   }
  }else if(wP==VK_F4){
   if(pocet<regVal[1].max){
     pocet++;
     generuj();
     InvalidateRect(hWnd,NULL,TRUE);
     modif=true;
   }
  }else if(wP==VK_F5){
    if(rychlost>regVal[0].min) rychlost--, modif=true;
  }else if(wP==VK_F6){
    if(rychlost<regVal[0].max) rychlost++, modif=true;
  }else if(wP==VK_F8){
    if(velikost<regVal[2].max){
      velikost++;
      generuj();
      InvalidateRect(hWnd,NULL,TRUE);
      modif=true;
    }
  }else if(wP==VK_F7){
    if(velikost>regVal[2].min){
      velikost--;
      generuj();
      InvalidateRect(hWnd,NULL,TRUE);
      modif=true;
    }
  }else if(wP==VK_F12){
    deleteini();
	generuj();
    InvalidateRect(hWnd,NULL,TRUE);
  }else if(wP!=VK_F9 && wP!=VK_F11){
    DestroyWindow(hWnd);
  }
 break;

 
 case WM_DESTROY:
  if(modif) writeini();
  KillTimer(hWnd,1);
  PostQuitMessage(0);
 break;

 default:
  return DefScreenSaverProc(hWnd, msg, wP, lP);
 }
 return 0;
}
 


