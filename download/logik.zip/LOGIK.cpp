/*
(C) 9.1998, 2.2000  Petr Lastovicka
*/

#define radky 23
#define MAXb 16
#define MAXd 16

#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#ifdef WIN32
#include "winConsole.h"
#endif

static int d=8, barev=10, rad, klav;
static char m[radky],b[radky];  /* hodnocen� */
static char pole[radky][MAXd], pocb[radky][MAXb], a[MAXb];

int colorMap[16] = { 0,9,10,11,12,13,14,15,2,5, 4,6,3,1,7,8}; //prvni musi byt 0

int hodnoceni()
{
 int misto=0,barva=0,o;
 char p;

 memset(a,0,barev);
 for(o=0; o<d; o++){
   if( (p=pole[rad][o]) == pole[0][o] ) ++misto;
   ++pocb[rad][p];
   if(a[p]<pocb[0][p]){ ++barva; ++a[p]; }
 }
 m[rad]=misto;
 b[rad]=barva;

 textcolor(7);
 gotoxy(3*d+8,wherey());
 for(o=0; o<misto; o++) putch(4);
 for(o=0; o<barva-misto; o++) putch('.');
 putch('\r'); putch('\n');
 if(misto==d || rad==radky-1) return 1;
 return 0;
}

int tisk()
{
 char o,p;
 cprintf("%2d)",rad);
 for(o=0; o<d; o++){
   textcolor(colorMap[p=pole[rad][o]]);
   cprintf("%3d",p);
 }
 return hodnoceni();
}


/*##################### Hra po��ta�e ################################*/
void pocitac()
{
 int i,o,r,s,misto,barva;
 char p;
 char *u,prohod,*us,*ukaz,*ukazp[MAXd];
 char nyni[MAXd],nynib[MAXd],umisteni[MAXd],nebyla[MAXd],kod[MAXd];
 char pocit[MAXd+1][radky],vice[MAXb],zbyva[radky][MAXd];

 clrscr();
 memset(pole[1],0,sizeof(pole)-MAXd);

/* Prvn� ��dek n�hodn�, bez opakov�n� */
 rad=1;
 u=pole[1];
 for(s=0; s<d; ){
   u[s]=(char)((float)rand()/RAND_MAX*barev);
   for(i=0; i<s; i++) if(u[i]==u[s]) break;
   if(i==s || s>barev-1) s++;
 }

/*#### Bez opakov�n� ####*/
 for(;;){
   if(tisk()) return;
   if(d>=barev) break;

   *nyni=barev-1;
   for(s=0; s<d; s++){       //postupn� v�echny sloupce

test: /* mus� souhlasit hodnocen� p�edch. ��dk� vzhledem k ��dku rad */
     for(r=1; r<=rad; r++){
       for(o=barva=0; o<=s; o++)
         if(pocb[r][nyni[o]]) ++barva;  //barva, co je�t� nebyla pou�ita
       if(barva<=b[r] && barva-s+d>b[r]) continue;  //v po��dku
       for(;;){
dalbar:  if(nyni[s]-- >=d-s) goto test;  //sni� barvu na pozici s
         if (--s<0) goto sopak;          //zp�t na p�edchoz� sloupec
       }
     }
     nyni[s+1]=nyni[s]-1;  //na dal� sloupec, hodnotu z p�edchoz�ho ��dku
   }

   memset(nebyla,1,d);
   for(s=0; s<d; s++){
     for(i=0; i<d; i++)
       if(nebyla[i]) break;
     umisteni[s]=nyni[i];
     kod[s]=i;
     nebyla[i]=0;
test2:
     for(r=1; r<=rad; r++){

/* Hodnocen� vzhledem k ��dku rad */
      for(misto=o=0; o<=s; o++)
        if(umisteni[o]==pole[r][o]) ++misto;

      if(misto<=m[r] && misto-s+d>m[r]) continue;
      for(;;){
        nebyla[i=kod[s]] = 1;
        for(i++; i<d; i++)
          if(nebyla[i]){ umisteni[s]=nyni[i]; kod[s]=i; nebyla[i]=0;
             goto test2;}
        if (--s<0) {s=d-1; goto dalbar;}
      }
    }}
   memcpy(pole[++rad],umisteni,d);
 }


/*###  Kombinace barev s opakov�n�m    #####
##### ( dokud neuhodne v�echny barvy ) ###*/
sopak:
 *nyni=barev-1; /*Po��te�n�*/
 do{
  for(s=0; s<d; s++){
    if(kbhit()) return;
test3:
    for(r=1; r<=rad; r++){
      memset(a,0,barev);
      barva=0;
      for(o=0; o<=s; o++){  /*Hodnocen� vzhledem k ��dku nyn�*/
        p=nyni[o]; if(a[p]<pocb[r][p]){ ++barva; ++a[p];}}
      if(barva<=b[r] && barva-s+d>b[r]) continue;
/*Dal� mo�nost*/
      for(;;){
       if( nyni[s]--) goto test3;
       if (--s<0) { cputs("Chyba"); getch(); return;}
      }
    }
    nyni[s+1]=nyni[s];
  }

/*### Rozm�st�n� n�hodn� ###*/
  u=pole[++rad];
  for(i=0; i<d; i++){
    for(o=(char)((float)rand()/RAND_MAX*d);;){
      if(u[o]==0){ u[o]=nyni[i]; break; }
      if(++o==d) o=0;
    }
  }
  if(tisk()) return;
 }while(b[rad]<d);

/*##### Permutace #####*/
  memcpy(nynib,nyni,d);
  memset(vice,0,barev);
  for(s=0; s<d; s++) vice[nyni[s]]++;
  for(r=1; r<=rad; r++){
    o=0;
    for(s=d-1; s>=0; s--){
      zbyva[r][s]=o;
      if(vice[pole[r][s]]) o++;
    }
  }
  memcpy(pocit,m,rad+1);

  for(;;){
   for(s=0,us=nyni-1; s<d; ukazp[s++]=ukaz){
     if(kbhit()) return;
     prohod=*(ukaz=++us);
     memcpy(pocit[s+1],pocit[s],rad+1);
test4:
/* for(o=0;o<d;o++){
   textcolor(colorMap[p=nyni[o]]);
   cprintf("%3d",p);}
   putch('\r\n');_read_kbd(0,1,0);
*/
     for(r=1; r<=rad; r++){
      if(pole[r][s]!=nyni[s]){
        if(zbyva[r][s]>=pocit[s+1][r]) continue;
      }else if(pocit[s+1][r]--!=0) continue;
      for(;;){
        *ukaz=*us;
        while((++ukaz)<nyni+d)
         if(*us!=*ukaz){
           *us=*ukaz;
           *ukaz=prohod;
           memcpy(pocit[s+1],pocit[s],r+1);
           goto test4;
         }
        if(--s<0){ cputs("Chyba"); getch(); return; }
        *(us--)=prohod;
        prohod=*(ukaz=ukazp[s]);
        r=rad;
      }
     }
   }
   memcpy(pole[++rad],nyni,d);
   if(tisk()) return;
   o=0;
   for(s=d-1; s>=0; s--){
     zbyva[rad][s]=o;
     if(vice[pole[rad][s]]) o++;
   }
   pocit[0][rad]=m[rad];
   memcpy(nyni,nynib,d);
  }
}

char vstup()
{
 char s=0;
 int y;
 int klav,k;

 y=wherey();
 memset(pole[rad],0,d);
 if(rad) cprintf("%2d)",rad);
 for(;;){
   textcolor(7);
   gotoxy(s*3+7,y+1); putch('^');
   klav=tolower(getch());
   gotoxy(s*3+7,y+1); putch(' ');
   gotoxy(s*3+5,y);
   k=99;
   if(klav>='0' && klav<='9') k=klav-'0';
   if(klav>='a' && klav<='z') k=klav-87;
   if(klav==13 || klav==27) return klav;
   if(!klav || klav==224) klav=getch();
   switch(klav){
    case 75: //left
    case 8: //backspace
      if(--s<0) s=d-1; break;
    case 83: //delete
      k=0; break;
    case 71: //home
      s=0; break;
    case 79: //end
      s=d-1; break;
   }
   if(k<barev){
     textcolor(colorMap[pole[rad][s]=k]);
     cprintf("%3d",k);
   }
   if((k<barev || klav==77) && klav!=83) if(++s>=d) s=0;
 }
}

//########################################################################

main ()
{
#ifdef WIN32
  initConsole();
#endif
 clock_t cas;
 register int p,s;
 int Spocit,Spokusu,Scelkem;
 long Scas;
 char klav1;

 _setcursortype(_NOCURSOR);
 srand(time(NULL));

 do{
  clrscr();
  cprintf("  Hra  LOGIK\r\n  ----------\r\n\nC - Po�et h�dan�ch ��slic: %d\r\n",d);
  cprintf("B - Po�et barev: %d\r\n",barev);
  cputs("P - Hra po��ta�e: n�hodn� zad�n�\r\nZ -               vlastn� zad�n�\r\n\
S -               v�cekr�t pro pr�m�rn� hodnoty\r\n\
H - Hra hr��e\r\nK - Konec\r\n\n");

 /* Zad�n�*/
  memset(pocb,0,sizeof pocb);
  rad=0;
  for(s=0; s<d; s++){
    p=pole[0][s]=(char)((float)rand()/RAND_MAX*barev);
    pocb[0][p]++;}

 /* �ekej na kl�vesu */
  if(!(klav1=klav)) klav1=toupper(getch());
  klav=0;
  switch(klav1){
   case 'C':
     cprintf("Po�et h�dan�ch ��slic (max.%d): ",MAXd);
     do{ cscanf("%d",&d);} while(d<1 || d>MAXd);
     break;
   case 'B':
     cprintf("Po�et barev (max.%d): ",MAXb);
     do{ cscanf("%d",&barev);} while(barev<1 || barev>MAXb);
     break;
   case 'Z':
   case 'Y':
     cputs("Napi� zad�n�\r\n\n");
     if(vstup()==27) break;
     memset(pocb,0,sizeof pocb);
     for(s=0; s<d; s++) pocb[0][pole[0][s]]++;
   case 'P':
     cas=clock();
     pocitac();
     cprintf(" �as: %0.2f",(float)(clock()-cas)/CLOCKS_PER_SEC);
     klav=toupper(getch());
     break;
   case 'S':
     Scas=Spokusu=0; Spocit=Scelkem=25-d;
   case 's':
     cas=clock();
     pocitac();
     Scas+=clock()-cas; Spokusu+=rad;
     if(--Spocit) {klav='s'; break;}
     cprintf("Pr�m�rn� �as: %0.2f\r\nPo�et pokus�: %d",
       (float)Scas/CLOCKS_PER_SEC/Scelkem,Spokusu/Scelkem);
     klav=toupper(getch());
     break;
   case 'H':
    clrscr();
    do{
     ++rad;
     if(vstup()==27) break;
    }while(!hodnoceni());
    if(m[rad]<d && rad==radky-1) cputs("To u� je p��li� mnoho pokus� !");
    cputs("\r\nKonec hry.");
    klav=toupper(getch());
   } //end case
 }while(klav1!=27 && klav1!='K');
 return 0;
}

