#include <windows.h>

extern HANDLE hOutput,hInput;
void initConsole();
void gotoxy(int x, int y);
int wherey();
void clrscr();
void textcolor(int color);
#define _NOCURSOR 0
void _setcursortype(int t);
void delay(int ms);
