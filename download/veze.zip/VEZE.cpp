/*
 (C) 8.1998, 8.2001  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
//---------------------------------------------------------------------------
/*
 USERC("Veze.rc");
*/
#ifndef __BORLANDC__
inline int random(int num){ return(int)(((long)rand()*num)/(RAND_MAX+1));}
inline void randomize() { srand((unsigned) time(NULL)); }
#endif
//---------------------------------------------------------------------------
HDC hdc;
HWND hWin;
HBRUSH brush;
COLORREF clbrush;

#define horni 55
#define maxd 20
#define maxv 9

long A[maxv+1][maxd+1], //tahy z po��te�n� pozice
     B[maxv+1][maxd+1]; //tahy na rozm�st�n� na v�echny v�e krom� po��te�n�
int S[maxv+1][maxd+1]; //optim�ln� v��ka 1.sloupku
char zasobnik[maxd*maxd*2+100];

//disky se ��sluj� od 1, v�e od 0
int pocd=7;    //po�et disk�
int pocv=3;    //po�et v��
int D[maxv][maxd+2]; //krajn� m�sta na ka�d� v�i jsou voln�
                     // D[v][0]=0    (ty� vy�n�v� naho�e)
                     // D[v][pocd+1]=pocd+1  (vespod je max. ��slo)
BYTE V[maxd+1];   //��slo v�e, kde je disk
int H[maxv];     //index um�st�n� vrchn�ho disku = pocd+1-v��ka v�e

long tah,ctah;
int hotovo;
int sipka;   //��slo v�e se �ipkou
int vpl,vkl, //p�edchoz� tah
    vpp,vkp; //p��t� tah po��ta�e

bool nahodne=false, hraPC=false;
int sirka,krok,vyska,dolni;

const COLORREF barvy[]={0x10b0a0L,0x0000f0L,0x00f000L,0xf00000L,0x00d0d0L,
  0xd0d000L,0xd000d0L}; //barvy disk�

void dej2(int dsl,int vsl,int dpoc,int vpoc,int vk,
  char *p,char *mem,long tah,int &vpp,int &vkp,long &maxtah);
//---------------------------------------------------------------------------
void init()
{
 int d,c;
 int s;
 int j;
 long b,i;
 int C[maxd+1]; //sloupec kombina�n�ch ��sel

//nastav� pole A,B,S
 for(j=0; j<=maxd; j++) C[j]=1;
 for(int v=3; v<=maxv; v++){
  A[v][1]=B[v][1]=1;
  i=b=1; c=j=1; s=0; d=2;
  do{
   while(s<c && d<=maxd) S[v][d]=++s, B[v][d]=(b+=i), A[v][d++]=2*b-1;
   c=(C[j+1]+=C[j]);
   j++;
   while(d<=c && d<=maxd) S[v][d]=s, B[v][d]=(b+=i), A[v][d++]=2*b-1;
   i*=2;
  }while(d<=maxd);
 }
}
//---------------------------------------------------------------------------
//zv��� tah;  p�i tah=0 nastav� vpp,vkp
void dej(int dpoc,int vpoc,int vk,char *p,char *pv,long &tah,
 int &vpp,int &vkp,long maxtah)
/*
 dpoc = po�et disk�
 vpoc = po�et v��
 vk   = koncov� v�
 vpp,vkp = nejlep�� tah
*/
{
 int d,v,d1,vv;
 int vp,v1;
 long tah1;
 char *uk, *pk=p+dpoc, *pdw,*pup,*mem;

 vp=*pk;  //kde je nejv�t�� disk

//v�echny disky na 1 v�i (sloupek)
 if(dpoc>=vpoc)
  for(uk=p; *uk==vp; uk++)
   if(uk==pk){   //u� byly v�echny
     if(!tah) vpp=vp, vkp= (vpoc!=3 || dpoc%2) ? vk : (~(vp+vk))&3;
     tah += A[vpoc][dpoc];
     return;
   }

//jen 3 v�e
 if(vpoc==3){
   tah1=tah;
   for(d=dpoc,v1=vk; d>0; d--){
     if(v1!=p[d]) vp=v1, d1=d, v1=(~(v1+p[d]))&3, tah+= 1L<<(d-1);
   }
   if(!tah1) vpp=p[d1], vkp=vp;
   return;
 }

//nastav pole
// pv:  �.disku vespod v�e
// pdw: 0=disk je vespod
// pup: 0=disk je navrchu
 memset(pv,0,vpoc+2*dpoc);
 pdw=pv+vpoc-1; pup=pdw+dpoc; mem=pup+dpoc+1;
 tah1=1;  //pro dpoc<vpoc
 for(d=1;d<=dpoc;d++){
  if(*(uk=pv+p[d])) tah1++, pdw[*uk]++, pup[d]++;
  *uk=(char)d;
 }

//t�hni s nejv�t��mi disky, kdy� jsou navrchu
 if(!pv[vk]){  //koncov� v� voln�
   for(d=dpoc;!pup[d];d--){
    if(!tah++) vpp=vp,vkp=vk;
    if(!--dpoc) return; //o disk m�n�
    pv[*(pk--)]=0;     //v� se uvolnila
   }
   tah1--;
 }

//najdi volnou v� nebo vv=-1
 for(v=vpoc-1;v>=0;v--) if(!pv[v] && v!=vk) break;
 vv=v;

//po�et disk� je mal�
 if(dpoc<vpoc){
   if(!tah) vpp=pv[vk]? vk : *pk, vkp=(int)vv;
   tah+=tah1+dpoc;
   return;
 }

//vol�n� dej2 sn�� maxtah
 d1=d=S[vpoc][dpoc];    //optim�ln� v��ka 1.p�enesen�ho sloupku
 for(int i=2;i>0;i--){  //poprv� d1 a� 1, podruh� d1+1 a� dpoc-1
  while(maxtah> tah+A[vpoc][d]+B[vpoc-1][dpoc-d] && d>0 && d<dpoc){
     vp=p[d];
     if(!pdw[d] && vp!=vk)  //disk u� je vespod
       dej2(d,vp,dpoc,vpoc,vk,p,mem,tah,vpp,vkp,maxtah);
     else{
       //nejd��ve dej sloupek na volnou v�
        if(vv>=0) dej2(d,vv,dpoc,vpoc,vk,p,mem,tah,vpp,vkp,maxtah);
        if(pup[d] || vv<0)
         for(v=vpoc-1;v>=0;v--)
          if(pv[v]<d && v!=vk && pv[v]) //nelze d�t na v�t�� disk
            dej2(d,v,dpoc,vpoc,vk,p,mem,tah,vpp,vkp,maxtah);
     }
     if(d>d1) d++; else d--;
  }
  d=d1+1;
 }
 tah=maxtah; //vra� nejlep�� v�sledek
}
//---------------------------------------------------------------------------
//jako dej, ale u� v�, �e 1.sloupek v��ky dsl p�enese na vsl
//v�sledek do maxtah, ale jen kdy� je men��
void dej2(int dsl,int vsl,int dpoc,int vpoc,int vk,
  char *p,char *mem,long tah,int &vpp,int &vkp,long &maxtah)
{
 int d=dsl;
 int vpp1=vpp,vkp1=vkp,vpp2=255,vkp2;
 char *uk, *pk=p+dpoc;
 long tahsl= maxtah-A[vpoc][dsl]-B[vpoc-1][dpoc-dsl];


 for(uk=p+d;*uk==vsl && d; uk--,d--) ; //co u� jsou na vsl

//vytvo� sloupek na vsl
 if(d) if(tahsl<=tah+B[vpoc][d]) return;
       else dej(d,vpoc,vsl,p,mem,tah,vpp1,vkp1,tahsl);

//p�enes disky men�� ne� dsl na vk (bez v�e vsl)
 if(tah>=tahsl) return;
 if(vsl<vpoc-1)
  //okop�ruj pole p bez sloupku dsl;  v�e nad vsl sni� o 1
  for(uk=p+dsl+1,p=mem-1; uk<=pk; uk++,mem++)
    *mem=char(*uk-(*uk>vsl));
 else p+=dsl;
 dej(dpoc-dsl,vpoc-1,vk-(vk>vsl),p,mem,tah,vpp2,vkp2,maxtah-A[vpoc][dsl]);
 if(vpp2<255) vpp1=vpp2+(vpp2>=vsl), vkp1=vkp2+(vkp2>=vsl);

//p�enes sloupek z vsl na vk
 if((tah+=A[vpoc][dsl]) < maxtah){
  maxtah=tah; vpp=vpp1,vkp=vkp1;
 }
}
//---------------------------------------------------------------------------
//vrac� kolik tah� zb�v� do konce
//ur�� nejlep�� tah, z v�e vpp na v� vkp
long zbyva()
{
 long tahu=0;
 int d;

//zjisti, jestli jsou v�echny disky na posledn� v�i -> konec
 for(d=pocd; V[d]==pocv-1; d--){
   if(d==1){ vpp=vkp; return 0; }
 }

 dej(d,pocv,pocv-1,(char*)V, zasobnik, tahu, vpp,vkp, A[pocv][pocd]*2);
 return tahu;
}
//---------------------------------------------------------------------------
void zadani()
{
 if(pocd<1) pocd=1;
 if(pocd>maxd) pocd=maxd;
 if(pocv<3) pocv=3;
 if(pocv>maxv) pocv=maxv;

 KillTimer(hWin,10);
 hraPC=false;

 memset(D,0,sizeof D);
//vespod v�� jsou zar�ky - maj� v�t�� velikost ne� v�echny disky
 for(int v=0; v<pocv; v++){
   D[v][pocd+1]= H[v]= pocd+1;
 }
//rozm�sti v�echny disky
 for(int d=pocd; d>0; d--){
   do{
     V[d]= (BYTE)(nahodne ? random(pocv):0);
   }while(V[pocd]==pocv-1);  //nejv�t�� disk ned�vej na posledn� v�
   D[V[d]][--H[V[d]]]=d;
 }
 tah=0; hotovo=0;
 ctah=zbyva();
 sipka=0;
 vkl=255;
 InvalidateRect(hWin,0,TRUE);
}
//---------------------------------------------------------------------------
void paintdisk(int v,int d)
{
 int x,y,b;
 HBRUSH hbr;
 HGDIOBJ hbrOld;
 RECT rc;

 x=sirka/2 + sirka*v;
 y=horni + vyska*d;
 b=D[v][d];
 if(b){ //disk
  hbr=CreateSolidBrush( barvy[(b-1) % (sizeof(barvy)/sizeof(barvy[0]))] );
  hbrOld= SelectObject(hdc, hbr);
  Rectangle(hdc, x-b*krok, y, x+b*krok, y+vyska);
  DeleteObject(SelectObject(hdc,hbrOld));
 }else{  //ty�
  rc.top= y;
  rc.bottom= y+vyska;
  rc.left= x-2;
  rc.right= x+2;
  FillRect(hdc, &rc, (HBRUSH) GetStockObject(BLACK_BRUSH));
 }
}
//---------------------------------------------------------------------------
void outNum(int x,int y,char *s,long i,char *t)
{
 char buf[128];
 strcpy(buf,s);
 if(!t) strcat(buf,": ");
 ltoa(i,strchr(buf,0),10);
 if(t){
  strcat(buf," ");
  strcat(buf,t);
 }
 TextOut(hdc, x,y, buf,(int)strlen(buf));
}
//---------------------------------------------------------------------------
void tahni(int vp,int vk) //tah z v�e vp na vk
{
 int d=D[vp][H[vp]],v,h;
 int vv;
 RECT rc;

 if(d>D[vk][H[vk]]){ vv=vp,vp=vk,vk=vv; d=D[vp][H[vp]];} //men�� disk na v�t��
 if(d>pocd || vp==vk) return; //pr�zdn� v� nebo nen� p�enos

//p�esun disku v pam�ti
 D[vk][--H[vk]]=d;
 D[vp][H[vp]++]=0;
 V[d]=(BYTE)vk;

 //zvy� po�et tah�
 if(vp!=vkl) ++tah;

//spo�ti dal�� tah a nastav ProgressBar
 h= int( 100 * (ctah-zbyva()) / ctah );
 if(!(tah%3) || hraPC || h==100)  hotovo=h;
 if(hotovo<0) hotovo=0;

//p�esu� �ipku
 if(H[V[1]]==1) sipka=V[1]; //v�echno na 1 v�i
 else{
   for(int i=0,m=1;i<pocv;i++){
     if(m<D[i][H[i]]) m=D[i][H[i]], v=i; //najdi nejv�t��
   }
   while(sipka==v || H[sipka]==pocd+1 || sipka==vk) sipka++, sipka%=pocv;
 }
//uchovej pro zp�t
 vpl=vp; vkl=vk;

//p�esun disku na obrazovce
 rc.top= horni + vyska*(H[vp]-1);
 rc.bottom= rc.top+vyska;
 rc.left= sirka*vp;
 rc.right= rc.left+sirka;
 FillRect(hdc, &rc, brush);
 paintdisk(vp,H[vp]-1); //ty�
 paintdisk(vk,H[vk]);   //disk

 GetClientRect(hWin,&rc);
 rc.bottom= horni-1;
 InvalidateRect(hWin,&rc,TRUE);
}
//---------------------------------------------------------------------------
void posunsipku()
{
 RECT rc;
 GetClientRect(hWin,&rc);
 rc.bottom=horni-3;
 rc.top=horni-25;
 InvalidateRect(hWin,&rc,TRUE);
}
//---------------------------------------------------------------------------
void repaint()
{
 PAINTSTRUCT ps;
 HGDIOBJ hbrOld;
 RECT rc;
 int v,d,x;

 GetClientRect(hWin,&rc);
 BeginPaint(hWin,&ps);

 //disky a v�e
 if(ps.rcPaint.bottom >= horni){
   dolni= rc.bottom-HIWORD(GetDialogBaseUnits());
   sirka= rc.right/pocv;
   krok= sirka/pocd/2;
   vyska=(rc.bottom-horni-20)/(pocd+1);
   for(v=0; v<pocv; v++)
    for(d=0; d<=pocd; d++)
     paintdisk(v,d);
 }
//�ipka
 x=sipka*sirka+sirka/2;
 MoveToEx(hdc,x,horni-23,NULL);
 LineTo(hdc,x,horni-5);
 LineTo(hdc,x-7,horni-13);
 MoveToEx(hdc,x,horni-5,NULL);
 LineTo(hdc,x+7,horni-13);

 //texty a ��sla
 if(ps.rcPaint.bottom >= dolni){
   outNum(9,dolni, "Disk�",pocd,0);
   outNum(100,dolni, "V��",pocv,0);
   outNum(180,dolni, "Po��ta� vy�e�� za  ", ctah, "tah�.");
 }
 if(ps.rcPaint.top < 23){
   outNum(9,3,"Tah",tah,0);
   outNum(160,3,"Hotovo:   ", hotovo, "%");

  //progress bar
   const int x=290;
   hbrOld= SelectObject(hdc, CreateSolidBrush(0xd00000L));
   Rectangle(hdc, x,1,x+hotovo,20);
   DeleteObject(SelectObject(hdc,hbrOld));
   hbrOld= SelectObject(hdc, CreateSolidBrush(0xa0a0a0L));
   Rectangle(hdc, x-1+hotovo,1,x+100,20);
   DeleteObject(SelectObject(hdc,hbrOld));
 }

 EndPaint(hWin, &ps);
}
//---------------------------------------------------------------------------
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT msg, WPARAM wP, LPARAM lP)
{

switch (msg) {

 case WM_COMMAND:
  switch (LOWORD(wP)){
   case 101: //nov� hra
    nahodne=false;
    zadani();
    break;
   case 102: //zam�chat
    nahodne=true;
    zadani();
    break;
   case 103: //konec
    DestroyWindow(hWnd);
    break;
   case 201: //zp�t
    if(tah) tahni(vkl,vpl);
    break;
   case 202: //tah po��ta�e
    tahni(vpp,vkp);
    break;
   case 301: //v�ce disk�
    if(pocd<maxd){ pocd++; zadani(); }
    break;
   case 302: //m�n� disk�
    if(pocd>1){ pocd--; zadani(); }
    break;
   case 303: //v�ce v��
    if(pocv<maxv){ pocv++; zadani(); }
    break;
   case 304: //m�n� v��
    if(pocv>3){ pocv--; zadani(); }
    break;
   default: //hra po��ta�e
    if(hotovo==100) zadani();
    SetTimer(hWin,10,LOWORD(wP),NULL);
    hraPC= true;
    break;
  }
  break;

 case WM_RBUTTONDOWN:
  if(HIWORD(lP) > horni){
    sipka= LOWORD(lP)/sirka;
    posunsipku();
  }
  break;

 case WM_KEYDOWN:
  KillTimer(hWin,10);
  hraPC=false;
  if(wP==VK_LEFT || wP=='Z'){
    if(!sipka--) sipka=pocv-1;
    posunsipku();
  }
  if(wP==VK_RIGHT || wP=='X'){
    sipka++; sipka%=pocv;
    posunsipku();
  }
  break;

 case WM_LBUTTONDOWN: //lev� tla��tko
  if (HIWORD(lP) <= horni) break;
  wP = '1'+ LOWORD(lP)/sirka;
 //!
 case WM_CHAR:
  if(!hraPC){
   //v�, kam se m� p�esouvat
   if(wP>='1' && wP<'1'+(unsigned)pocv){
     tahni(sipka,(int)wP-'1'); //��slice
   }
  }
  break;

 case WM_TIMER:
  tahni(vpp,vkp);
  break;

 case WM_SIZE:
  InvalidateRect(hWin,0,TRUE);
  break;

 case WM_PAINT:
  repaint();
  break;

 case WM_GETMINMAXINFO:
  ((POINT far *)lP)[3].x = 400;
  ((POINT far *)lP)[3].y = 150+horni;
  break;

 case WM_DESTROY:
  PostQuitMessage(0);
  break;

 default:
  return DefWindowProc(hWnd, msg, wP, lP);
}
return 0;
}
//---------------------------------------------------------------------------
int pascal WinMain(HINSTANCE hInstance, HINSTANCE hPrev, LPSTR, int nCmdShow)
{
 MSG msg;
 WNDCLASS wc;
 HACCEL haccel;

 clbrush= RGB(20, 180, 20);
 brush= CreateSolidBrush(clbrush);

 wc.style= CS_OWNDC;
 wc.lpfnWndProc= MainWndProc;
 wc.cbClsExtra= 0;
 wc.cbWndExtra= 0;
 wc.hInstance= hInstance;
 wc.hIcon= LoadIcon(hInstance, "MAINICON");
 wc.hCursor= LoadCursor(NULL, IDC_ARROW);
 wc.hbrBackground= brush;
 wc.lpszMenuName= "MAINMENU";
 wc.lpszClassName= "VezeWCLS";
 if(!hPrev && !RegisterClass(&wc)) return 1;
 hWin = CreateWindow( "VezeWCLS", "Hanojsk� v�e",
   WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
   500, 314+HIWORD(GetDialogBaseUnits()),
   NULL, NULL, hInstance, NULL);
 if(!hWin) return 2;
 hdc= GetDC(hWin);
 SetBkMode(hdc,TRANSPARENT);
 ShowWindow(hWin, nCmdShow);
 haccel=LoadAccelerators(hInstance, "MAINACCEL");

 randomize();
 init();
 zadani();

 while(GetMessage(&msg, NULL, 0, 0)) {
  if(!TranslateAccelerator(hWin,haccel,&msg)){
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
 }

 return 0;
}
//---------------------------------------------------------------------------

