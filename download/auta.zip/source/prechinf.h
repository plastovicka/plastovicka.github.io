//---------------------------------------------------------------------------
#ifndef prechinfH
#define prechinfH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
//---------------------------------------------------------------------------
#include "autasim.h"
#include <vcl\ExtCtrls.hpp>

class TInfoPrechod : public TFormInfo
{
__published:	// IDE-managed Components
	TLabel *Label4;
	TLabel *Souradnice;
	TLabel *Label3;
	TLabel *Projelo;
	TPanel *Panel1;
	TLabel *Label2;
	TLabel *LabelCas;
	TLabel *LabelInt;
	TLabel *Label6;
	TLabel *Label1;
	TLabel *Label5;
private:	// User declarations
public:		// User declarations
 void update();
 void UpdateAll();
	virtual __fastcall TInfoPrechod(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TInfoPrechod *InfoPrechod;
//---------------------------------------------------------------------------
#endif
