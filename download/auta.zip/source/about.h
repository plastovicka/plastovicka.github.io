//----------------------------------------------------------------------------
#ifndef aboutH
#define aboutH
//----------------------------------------------------------------------------
#include <vcl\System.hpp>
#include <vcl\Windows.hpp>
#include <vcl\SysUtils.hpp>
#include <vcl\Classes.hpp>
#include <vcl\Graphics.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\ExtCtrls.hpp>
//----------------------------------------------------------------------------
class TFormAbout : public TForm
{
__published:        
	TButton *OKBtn;
	TBevel *Bevel1;
	TLabel *Label1;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label2;
private:
public:
	virtual __fastcall TFormAbout(TComponent* AOwner);
};
//----------------------------------------------------------------------------
extern TFormAbout *FormAbout;
//----------------------------------------------------------------------------
#endif    
