/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("main.cpp", Form1);
USERES("auta.res");
USEFORM("krizform.cpp", FormKriz);
USEUNIT("autasim.cpp");
USEFORM("semaf3.cpp", FormSemaf3);
USEFORM("semaf4.cpp", FormSemaf4);
USEFORM("vstupfrm.cpp", FormVstup);
USEFORM("krizinfo.cpp", InfoKriz);
USEFORM("vstupinfo.cpp", InfoVstup);
USEFORM("moznosti.cpp", FormMoznosti);
USEFORM("statis.cpp", FormStatis);
USEFORM("parkform.cpp", FormPark);
USEFORM("parkinfo.cpp", InfoPark);
USEFORM("silnform.cpp", FormSiln);
USEFORM("autoinfo.cpp", InfoAuto);
USEFORM("about.cpp", FormAbout);
USEFORM("prechfrm.cpp", FormPrechod);
USEFORM("prechinf.cpp", InfoPrechod);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	try
	{
		Application->Initialize();
		Application->CreateForm(__classid(TForm1), &Form1);
		Application->CreateForm(__classid(TFormKriz), &FormKriz);
		Application->CreateForm(__classid(TFormSemaf3), &FormSemaf3);
		Application->CreateForm(__classid(TFormSemaf4), &FormSemaf4);
		Application->CreateForm(__classid(TFormVstup), &FormVstup);
		Application->CreateForm(__classid(TInfoKriz), &InfoKriz);
		Application->CreateForm(__classid(TInfoVstup), &InfoVstup);
		Application->CreateForm(__classid(TFormStatis), &FormStatis);
		Application->CreateForm(__classid(TFormMoznosti), &FormMoznosti);
		Application->CreateForm(__classid(TFormPark), &FormPark);
		Application->CreateForm(__classid(TInfoPark), &InfoPark);
		Application->CreateForm(__classid(TFormSiln), &FormSiln);
		Application->CreateForm(__classid(TInfoAuto), &InfoAuto);
		Application->CreateForm(__classid(TFormAbout), &FormAbout);
		Application->CreateForm(__classid(TFormPrechod), &FormPrechod);
		Application->CreateForm(__classid(TInfoPrechod), &InfoPrechod);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	return 0;
}
//---------------------------------------------------------------------------
