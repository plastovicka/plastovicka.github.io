/*
(C) 2000  Petr Lastovicka
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include <math.h>
#include <values.h>
#include <stdio.h>
#include <dos.h>
#include "main.h"
#include "krizform.h"
#include "vstupfrm.h"
#include "parkform.h"
#include "krizinfo.h"
#include "vstupinfo.h"
#include "parkinfo.h"
#include "silnform.h"
#include "autoinfo.h"
#include "moznosti.h"
#include "statis.h"
#include "about.h"
#include "prechfrm.h"
#include "prechinf.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
#pragma resource "*.res"
TForm1 *Form1;
Graphics::TBitmap *bitmapa=0, *pozadi=0;
TCanvas* mapcanvas;  //Mapa->Canvas nebo bitmapa->Canvas

//barvy
const int clAuto[]={0xffffff,0x00ffff,0xffff00,0xff00ff,
  0xffa0a0,0xa0ffa0,0xa0a0ff};
const int clUzel[2][2]=  //[vybran�][zv�razn�n�]
   {{0x000000,0x50d0d0},{0x8080e0,0x50b0f0}};
const int clSilnice[2][2]=  //[vybran�][zv�razn�n�]
   {{0x000000,0xff0000},{0xa000e0,0xf050fa}};
const TColor clMriz= TColor(0x70b0a0); //barva m��e
const TColor clMapa= clSilver; //pozad� mapy
TColor clSilnice1= clBlack;    //silnice p�i simulaci (b�l� nebo �ern�)

//konstanty
const AnsiString formCaption="Silni�n� doprava"; //n�zev okna
const int MOVEINT=370;  //�as zm�ny kurzoru na p�esun uzlu nebo zat��ky (ms)
const int POSUNINT=100; //posun mapy (ms)
const int MINK=50;      //min. vzd�lenost mezi k�i�ovatkami (m)
const int MINZ=20;      //min. vzd�lenost mezi zat��kami (m)
const int MINZK=30;     //min. vzd�lenost zat��ky od k�i�ovatky (m)
const int autoRect=8;   //velikost �tverce kolem vybran�ho auta
const double MinDPRUHU=0.7; //min. ���ka pruhu (pix)

//volby z dialogu Mo�nosti
int DPOSUN=40;    //vzd�lenost okraje pro posun mapy  (pix)
int VYBRINT=500;  //�as automatick�ho vybr�n�  (ms)
int RychPosun=20; //rychlost posunu mapy p�i ta�en�  (ms)
short Nvykres=10, //po�et p�ekreslen� mapy za sec
      DKROK=1,    //doba pro krokov�n�  (1/5 sec)
      DQUICK=10;  //doba zrychlen� simulace p�i spu�t�n� (min)
short Dxmriz=1000, //velikost m��e (m)
      Dymriz=1000;
short xmriz=0,    //sou�adnice po��tku m��e
      ymriz=0;
short xpozadi=0, //sou�adnice po��tku bitmapy
      ypozadi=0;
short Dxpozadi=8000,
      Dypozadi=6000;
AnsiString bmpFile="mapa.bmp";//bitmapa na pozad�

//po��te�n� hodnoty pro nov� uzly
short interval0=20;
short delodboc0=30;
short prijizdi0=10;
short chodci0=15;
short auta0=25;
short Mpark0=100;
const short rychlost0=3; //50km/h

int xposun,yposun,     //poloha st�edu Mapy ve m�st� (m)
    XS,YS,             //st�ed Mapy (pix)
    lupa=10,           //m���tko, 100% = 1 metr/pixel
    mapLeft,mapRight,  //okraje m�sta (m)
    mapTop,mapBottom,
    mapaWidth,mapaHeight; //rozm�ry Mapy
int mouseX,mouseY,        //poloha my�i na Map�  (pix)
    selautoX=-1,selautoY; //�tverec vybran�ho auta (pix)

int tazeni=0;      //0=nic, 1=nov� silnice, 2=p�esun, 3=bude p�esun
int activate=-1;   //0=p�i dal��m kliknut� zm�� lupu
int vybran=0;      //0=nic, 1=cesta, 2=vstup do m�sta, 3=parkovi�t�,
                   //4=pomocn� uzel, 5=k�i�ovatka, 6=p�echod pro chodce
TFormE *activeForm=0; //okno v lev� ��sti obrazovky
Tuzel *seluzel;       //vybran� uzel (p�i vybran>1)
Tsilnice *prvniS=0;   //po��te�n� silnice pro v�b�r cesty
Tuzel *prvniU=0,*druhy1,*druhy2; //po��tek a konec pro v�b�r cesty
double SirkaPruhu=DPRUHU;    //���ka j�zdn�ho pruhu (m)
bool leftDown=false, rightDown=false, //tla��tka my�i
     shift=false,  //kl�vesa SHIFT
     canmove=true, //p�i false m��e sledovan� auto zmizet z obrazovky
     play=true,    //play se posune o DQUICK
     cara;         //nov� silnice

Tsilnice *novasiln[2];
double mapposunx,mapposuny;  //sm�r posunu mapy  (pix)
int pocPopup,novtyp,novtyp2; //v�sledky PopUpMenu p�i tvorb� nov�ho uzlu
static char buf[48];

bool modif=false;    //true=soubor zm�n�n
AnsiString filename; //jm�no souboru
FILE *f;
char *zahlavi="Silnicni sit pro simulaci dopravy ve meste     "; //v souboru

struct Tnovainfo{
 Tpos pos;
 Tuzel *uzel;
 Tsilnice *silnice;
 Tzatacka *zatacka;
 bool jezatac;
 void set(Tuzel* ,Tsilnice* );
}
 zvyraz,nova,nova2;

//---------------------------------------------------------------------------
int __fastcall calX(int x){
 return (x-xposun)*lupa/100+XS;
}

int __fastcall calY(int y){
 return (y-yposun)*lupa/100+YS;
}

int __fastcall calxm(int x){
 return (x-XS)*100/lupa+xposun;
}

int __fastcall calym(int y){
 return (y-YS)*100/lupa+yposun;
}

double vzdalenost(Tpos p1,Tpos p2){
 return sqrt(sqr(p1.x-p2.x)+sqr(p1.y-p2.y));
}

void propoj(Tsilnice *c1,Tsilnice *c2)
{
 c1->opac=c2;
 c2->opac=c1;
}

//---------------------------------------------------------------------------
//  Zobrazen�
//---------------------------------------------------------------------------
void prekresli()
{
 Form1->Mapa->Invalidate();
}
//---------------------------------------------------------------------------
int Tuzel::paint()
{
int b;
int x1=calX(pos.x), y1=calY(pos.y), d;

//zjisti polom�r kruhu
 d=max(4-2*sim,R*lupa/100);
//jen kdy� je vid�t na obrazovce
 if(x1+d<=0 || x1-d>=mapaWidth || y1+d<=0 || y1-d>=mapaHeight) return 0;
 b= clUzel[selected][zvyraz.uzel==this];
//k�i�ovatky se semafory jsou zelen�
 if(!sim && (typ & SEMAF) && ((Tuzelsemaf*)this)->jesemaf && !b) b=0xa000;
//nakresli kruh
 mapcanvas->Brush->Color= TColor(b);
 mapcanvas->Pen->Style= psClear;
 mapcanvas->Brush->Style= bsSolid;
 if(typ==PARK){
   mapcanvas->Rectangle(x1-d,y1-d,x1+d,y1+d);
 }else{
   mapcanvas->Ellipse(x1-d,y1-d,x1+d,y1+d);
 }
 mapcanvas->Pen->Style= psSolid;
 return d;
}
//---------------------------------------------------------------------------
int Tcil::paint()
{
int x1=calX(pos.x), y1=calY(pos.y);
int h,d;

 d= Tuzel::paint();
//jm�no c�le
 if(d && *jmeno && (lupa>7 || typ==VSTUP)){
   mapcanvas->Font->Height= h= lupa/3+5;
   mapcanvas->Brush->Style= bsClear; //(m�n� tak� Color na 0xffffff)
   mapcanvas->TextOut(x1-10-h/6*strlen(jmeno),
     y1+ (uhel(0)<0 ? 5+d : -(h+7+d)),jmeno);
 }
 return d;
}
//---------------------------------------------------------------------------
void Tuzelsemaf::paintSemaf()
{
int j,odboc;
int x1,y1;
double x,y,xs,ys,dm;
Tzatacka *z2,*z1;
Tsilnice *c;
TRect r;

if(sim && jesemaf && lupa>=(typ==KRIZ ? 60:30)){
 x1=calX(pos.x), y1=calY(pos.y);
 if(x1>0 && x1<mapaWidth && y1>0 && y1<mapaHeight){
  for(j=0; j<Ds; j++){
   c=s[j];
   if(c->pruhu0){
    z1=c->getZatac();
    z2=z1->nxt;
    dm=vzdalenost(z2->pos,z1->pos); if(dm<1) return;
    xs= double(z2->pos.x - z1->pos.x) /dm;
    ys= double(z2->pos.y - z1->pos.y) /dm;
    x= x1 + ((R+2.0)*xs + ys*9)*lupa/100.0;
    y= y1 + ((R+2.0)*ys - xs*9)*lupa/100.0;
    for(odboc=1; odboc<Ds; odboc++)
     if(!c->delodboc || ((Tpruhy*)c)->pruhu[odboc]){
       mapcanvas->Brush->Style= bsSolid;
       mapcanvas->Brush->Color=
          volno & (1<<(odboc+3*j-1)) ? TColor(0xc000) : clRed;
       if(lupa>130){ r.Top=y-2; r.Left=x-2; }
       else{ r.Top=y-1; r.Left=x-1; }
       r.Bottom=y+2; r.Right=x+2;
       mapcanvas->FillRect(r);
       x-=4*ys; y+=4*xs;
     }
   }
  }
 }
}
}
//---------------------------------------------------------------------------
static bool hledaniAuta=false;
static double dAuto;
//---------------------------------------------------------------------------
//zobraz� auta
void frontapaint(Tauto *a,int Dp,int d,Tzatacka *z,int R2)
{
double X0,Y0,X2,Y2,X,Y, dx,dy, xs,ys, Dp1,dm;
Tzatacka *z1;
short X1,Y1;
TColor cla;
double da;

 if(!a) return;
 Dp1=Dp*SirkaPruhu;
//projdi v�echny rovn� �seky
 X0=calX(z->pos.x + Dp1* z->px);
 Y0=calY(z->pos.y + Dp1* z->py);
 for(z1=z->nxt;  z1;  z=z1, z1=z1->nxt, d-=dm, X0=X2,Y0=Y2){
  //konec �seku
   X2=calX(z1->pos.x + Dp1* z1->px);
   Y2=calY(z1->pos.y + Dp1* z1->py);
  //d�lka �seku
   dm=sqrt(sqr(X2-X0)+sqr(Y2-Y0))*100.0/lupa;
   if(dm<1) continue;
  //zm�na pozice na 1 metr �seku
   dx= (X2-X0)/dm;
   dy= (Y2-Y0)/dm;
  //nekresli dovnit� k�i�ovatky
   if(!z1->nxt) dm-=R2;
  //sma� auta, co vyjela z Mapy
   if(X0<0 && X2<0 || X0>=mapaWidth && X2>=mapaWidth ||
      Y0<0 && Y2<0 || Y0>=mapaHeight && Y2>=mapaHeight){
     while(d+ a->d <dm){
       d+= a->d;
       a->smaz();
       a->X= -1;
       a=a->nxt;
       if(!a) return;
     }
   }else{
    //zobraz auta (nekontroluje se, zda jsou uvnit� Mapy)
     while(d+ a->d <dm){
      d+= a->d;
      X1=short(X=X0+d*dx);
      Y1=short(Y=Y0+d*dy);
      if(hledaniAuta){
        da=sqrt(sqr(X1-mouseX)+sqr(Y1-mouseY));
        if(da<dAuto){ dAuto=da; selauto=a; }
      }
      if(X1!=a->X || Y1!=a->Y){
       //sma� starou pozici
       a->smaz();
       //1.bod
       mapcanvas->Pixels[a->X= X1][a->Y= Y1]= cla= TColor(a->barva);
       if(lupa>25){
        xs= dx*100.0/lupa;
        ys= dy*100.0/lupa;
        //2.bod
        mapcanvas->Pixels[a->X2= short(X+xs)][a->Y2= short(Y+ys)]=cla;
        if(lupa>75){
         //3.bod
         mapcanvas->Pixels[a->X3= short(X+xs+xs)][a->Y3= short(Y+ys+ys)]=cla;
        }
       }
      }
      a=a->nxt;
      if(!a) return;
     }
   }

 }
 //sma� auta, kter� jsou uvnit� k�i�ovatky
 for( ;a; a=a->nxt){
   a->smaz();
   a->X= -1;
 }
}
//---------------------------------------------------------------------------
void Tsilnice::autapaint()
{
Tfronta *f;
Tzatacka *z;
int Dp,R1,R2;

 R1=uzel->R;
 R2=opac->uzel->R;
 z=getZatac();
 if((Dp=pruhu0)>0){
   for(f=fronty; Dp>0; Dp--,f++){ //fronty za��naj� prav�m pruhem
     frontapaint(f->auta, Dp, R1+delodboc, z, R2);
   }
   if(delodboc)
     for(Dp=((Tpruhy*)this)->pruhu1; Dp>0; Dp--, f++){
       frontapaint(f->auta, Dp, R1, z, R2);
     }
 }
}
//---------------------------------------------------------------------------
bool usecka(double X0,double Y0,double X1,double Y1)
{
double dx,dy;
int i;

 dx= X1-X0;
 dy= Y1-Y0;
//o��zni ��sti mimo Mapu
 if(dx>0){
    if(X0>=mapaWidth || X1<0) return false;
    if(dx>1e-3){
     if(X1>=mapaWidth){
       Y1-=(X1-mapaWidth)*dy/dx;
       X1=mapaWidth;
     }
     if(X0<0){
       Y0-=X0*dy/dx;
       X0=0;
     }
    }
 }else{
    if(X1>=mapaWidth || X0<0) return false;
    if(dx<-1e-3){
     if(X0>=mapaWidth){
       Y0-=(X0-mapaWidth)*dy/dx;
       X0=mapaWidth;
     }
     if(X1<0){
       Y1-=X1*dy/dx;
       X1=0;
     }
    }
 }
 if(dy>0){
    if(Y0>=mapaHeight || Y1<0) return false;
    if(dy>1e-3){
     if(Y1>=mapaHeight){
       X1-=(Y1-mapaHeight)*dx/dy;
       Y1=mapaHeight;
     }
     if(Y0<0){
       X0-=Y0*dx/dy;
       Y0=0;
     }
    }
 }else{
    if(Y1>=mapaHeight || Y0<0) return false;
    if(dy<-1e-3){
     if(Y0>=mapaHeight){
       X0-=(Y0-mapaHeight)*dx/dy;
       Y0=mapaHeight;
     }
     if(Y1<0){
       X1-=Y1*dx/dy;
       Y1=0;
     }
    }
 }

//p�i simulaci kresli ��ry z bod�, p�i editaci pou�ij LineTo
 if(sim){
   dx= X1-X0;
   dy= Y1-Y0;
   i=abs(dx)+abs(dy);
   if(i){ dx=dx/i; dy=dy/i; }
   while(i--) mapcanvas->Pixels[X0+=dx][Y0+=dy]=clSilnice1;
 }else{
   mapcanvas->MoveTo(X0,Y0);
   mapcanvas->LineTo(X1,Y1);
 }
 return true;
}
//---------------------------------------------------------------------------
// nakresl� pruhy Dp1 a� Dp2 (bez aut)
// o��zne na interval d01 a� dk1 metr�
// R1,R2 jsou polom�ry uzl�
void pruhpaint(int Dp1,int Dp2,int d01,int dk1,Tzatacka *z0,int R1,int R2)
{
double X0,Y0,X2,Y2,dx,dy,dp,dm;
Tzatacka *z,*z1;
int d0,dk;

 d01+=R1; dk1+=R1;
 for( ; Dp1<=Dp2; Dp1++){
  dp=Dp1*SirkaPruhu;
  d0=d01; dk=dk1;
  X0=calX(z0->pos.x + dp* z0->px);
  Y0=calY(z0->pos.y + dp* z0->py);
  for(z=z0, z1=z->nxt;  z1 && dk>0;  z=z1, z1=z1->nxt, dk-=dm, X0=X2,Y0=Y2){
    X2=calX(z1->pos.x + dp* z1->px);
    Y2=calY(z1->pos.y + dp* z1->py);
   //vypo�ti sm�rov� vektor
    dm=sqrt(sqr(X2-X0)+sqr(Y2-Y0))*100.0/lupa;
    if(dm<1) continue;
    dx= (X2-X0)/dm;
    dy= (Y2-Y0)/dm;
   //o��zni konec
    if(!z1->nxt){
      X2-=R2*dx; Y2-=R2*dy;
      dm-=R2;
    }
    if(dk<dm){
      X2-=(dm-dk)*dx; Y2-=(dm-dk)*dy;
    }
   //o��zni za��tek
    if(d0>0){
      if(d0>=dm){ d0-=dm; continue; }
      X0+=d0*dx; Y0+=d0*dy;
      d0=0;
    }
    usecka(X0,Y0,X2,Y2);
  }
 }
}
//---------------------------------------------------------------------------
void Tsilnice::paint()
{
Tzatacka *z;
int R1,R2,Dp0,Dp1;

 if(!sim) mapcanvas->Pen->Color=TColor(
    clSilnice[selected][zvyraz.silnice==this || zvyraz.silnice==opac]);
 Dp0=Dp1=pruhu0;
 if(Dp0>0){
   R1=uzel->R;
   R2=opac->uzel->R;
   z=getZatac();
   if(delodboc) Dp1=((Tpruhy*)this)->pruhu1;
   if(Dp1>=Dp0){ //p�ed k�i�ovatkou se roz�i�uje
     pruhpaint(1,Dp0,0,32000,z,R1,R2);
     if(Dp1>Dp0) pruhpaint(Dp0+1,Dp1,0,delodboc+4,z,R1,R2);
   }else{ //p�ed k�i�ovatkou se zu�uje
     pruhpaint(1,Dp1,0,32000,z,R1,R2);
     pruhpaint(Dp1+1,Dp0,delodboc,32000,z,R1,R2);
   }
 }
}
//---------------------------------------------------------------------------
void Tsilnice::paint2()
{
 paint();
 opac->paint();
}
//---------------------------------------------------------------------------
void Tauto::smaz()
{
 if(X>=0){
   mapcanvas->Pixels[X][Y]=clSilnice1;
   if(lupa>25) mapcanvas->Pixels[X2][Y2]=clSilnice1;
   if(lupa>75) mapcanvas->Pixels[X3][Y3]=clSilnice1;
 }
}
//---------------------------------------------------------------------------
void paintSelAuto()
{
//nakresl� �tverec kolem vybran�ho auta
 if(selautoX>=0){
   mapcanvas->Pen->Mode=pmXor;
   mapcanvas->Pen->Color=clMapa;
   mapcanvas->Brush->Style= bsClear;
   mapcanvas->Rectangle(selautoX-autoRect, selautoY-autoRect,
     selautoX+autoRect, selautoY+autoRect);
   mapcanvas->Pen->Mode=pmCopy;
 }
}
//---------------------------------------------------------------------------
void taznov()
{
//��ra p�i tvorb� nov� silnice se kresl� operac� XOR
 mapcanvas->Pen->Width= vzdalenost(nova.pos,zvyraz.pos)>MINK ? 2:1;
 mapcanvas->Pen->Mode=pmXor;
 mapcanvas->Pen->Color=clMapa;
 mapcanvas->MoveTo(calX(nova.pos.x),calY(nova.pos.y));
 mapcanvas->LineTo(calX(zvyraz.pos.x),calY(zvyraz.pos.y));
 mapcanvas->Pen->Mode=pmCopy;
 mapcanvas->Pen->Width=1;
}

void taznov0()
{
 if(cara){
  taznov();
  cara=false;
 }
}

void taznov1()
{
 if(tazeni==1 && !cara){
  taznov();
  cara=true;
 }
}
//---------------------------------------------------------------------------
void zvyrazni(Tuzel* k,Tsilnice* c)
{
Tuzel* kl= zvyraz.uzel;
Tsilnice* cl= zvyraz.silnice;

 paintSelAuto();
//nastav strukturu
 zvyraz.uzel=k;
 zvyraz.silnice=c;
 if(!(k || c)) Form1->TimerSelect->Interval=0;
//zru� p�edchoz� zv�razn�n�
 if(kl) kl->paint();
 if(cl && !sim) cl->paint2();
//nakresli nov�
 if(k){ k->paint(); zvyraz.pos=k->pos; }
 if(c && !sim) c->paint2();
 paintSelAuto();
}
//---------------------------------------------------------------------------
#ifdef DEBUG
void chybu(char *s,Tuzel *u)
{
 try{
  zvyrazni(u,0);
 }
 catch(...){
 }
 throw Exception(s);
}

void chybc(char *s,Tsilnice *c)
{
 try{
  zvyrazni(0,c);
 }
 catch(...){
 }
 throw Exception(s);
}

void tst()
{
Tsilnice *c;
Tuzel *u;
int j;

 fors(u,uzly){
  if(u->Ds<1) chybu("uzel->Ds <1",u);
  for(j=0; j<u->Ds; j++){
    if(!findlist(silnice,u->s[j])) chybu("uzel->s[]",u);
    if(u->typ==KRIZ && u->Ds<3) chybu("kriz->Ds <3",u);
    if(u->typ==KONEC && u->Ds>2) chybu("konec->Ds >2",u);
    if(u->typ==PRECHOD && u->Ds!=2) chybu("prechod->Ds !=2",u); 
  }
 }
 fors(c,silnice){
  if(!findlist(silnice,c->opac)) chybc("silnice->opac",c);
  if(c->zatacky){
    if(c->zatacky->nxt==0) chybc("chybi 2.zatacka",c);
    if(!findlist(uzly,c->uzel))
       chybc("silnice->uzel",c);
    if(!findlist(uzly,c->opac->uzel))
       chybc("silnice->opac->uzel",c);
    if(c->zatacky->pos!=c->uzel->pos) chybc("zatacky1.pos",c);
    if(endlist(c->zatacky)->pos!=c->opac->uzel->pos) chybc("zatacky2.pos",c);
  }
 }
}
#endif
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
//  Konstruktory
//---------------------------------------------------------------------------
Tauto::Tauto()
{
  barva= clSilnice1 ^ clAuto[random(sizeof(clAuto)/sizeof(*clAuto))];
  X=-1;
}

Tsemafory::Tsemafory(int i):interval(interval0),id(i),nxt(0){};

Tsilnice::Tsilnice(Tuzel *u)
{
 nxt=silnice;
 silnice=this;
 uzel=u;
 delodboc=0;
 pruhu0=1;
 rychlost=rychlost0;
 zatacky=0;
 selected=false;
}

Tpruhy::Tpruhy(Tuzel *u) : Tsilnice(u)
{
 lspolec=rspolec=false;
 pruhu[1]=pruhu[2]=pruhu[3]=1;
 delodboc=delodboc0;
}

Tuzel::Tuzel()
{
 nxt=uzly;
 uzly=this;
 Ds=1;
 R=6;
 selected=false;
}

Tcil::Tcil()
{
 Dcile++;
 prijizdi= prijizdi0;
 jmeno[0]=0;
}

Tvstup::Tvstup()
{
 typ=VSTUP;
 nxt=vstupy;
 vstupy=this;
 cislo[0]=0;
}

Tkonec::Tkonec()
{
 typ=KONEC;
 nxt=konce;
 konce=this;
}

Tpark::Tpark()
{
 typ=PARK;
 nxt=parkoviste;
 parkoviste=this;
 Mpark=Mpark0;
}

Tuzelsemaf::Tuzelsemaf()
{
 caszmen0=0;
 jesemaf=true;
}

Tkriz::Tkriz()
{
 typ=KRIZ;
 nxt=krizovatky;
 krizovatky=this;
 hlavni=2;
 viceurovn=false;
 semaf=0;
 jesemaf=false;
}

Tprechod::Tprechod()
{
 Ds=2;
 typ=PRECHOD;
 nxt=prechody;
 prechody=this;
 chodci=chodci0;
 auta=auta0;
 tlacitko=0;
}
//---------------------------------------------------------------------------
//  Destruktory
//---------------------------------------------------------------------------
Tuzel::~Tuzel()
{
int j;
 for(j=0; j<Ds; j++) delete s[j];
 dellist1(uzly,this);
}

Tcil::~Tcil()
{
 Dcile--;
}

Tvstup::~Tvstup()
{
 dellist1(vstupy,this);
}

Tpark::~Tpark()
{
 dellist1(parkoviste,this);
}

Tkonec::~Tkonec()
{
 dellist1(konce,this);
}

Tprechod::~Tprechod()
{
 dellist1(prechody,this);
}

Tkriz::~Tkriz()
{
 dellist(semaf);
 dellist1(krizovatky,this);
}

Tsilnice::~Tsilnice()
{
 dellist(zatacky);
 dellist1(silnice,this);
}

Tfronta::~Tfronta()
{
 dellist(auta);
 #ifdef DEBUG
 if(auton) ShowMessage("~Tfronta: auton!=0");
 #endif
}
//---------------------------------------------------------------------------
void okraje()
{
Tuzel *u;
Tsilnice *c;
Tzatacka *z;

//zjisti okraje m�sta
 mapLeft=mapTop=MAXINT;
 mapRight=mapBottom=-MAXINT;
 fors(u,uzly){
   amax(mapLeft,u->pos.x);
   amin(mapRight,u->pos.x);
   amax(mapTop,u->pos.y);
   amin(mapBottom,u->pos.y);
 }
 fors(c,silnice)
  fors(z,c->zatacky){
   amax(mapLeft,z->pos.x);
   amin(mapRight,z->pos.x);
   amax(mapTop,z->pos.y);
   amin(mapBottom,z->pos.y);
  }
 if(mapLeft==MAXINT){
  //pr�zdn� m�sto
   mapLeft=mapTop=-3000;
   mapRight=mapBottom=3000;
 }
//nastav minim�ln� lupu
 Form1->TrackBar1->Min= min(30,max(1,min(
    100*mapaWidth/(mapRight-mapLeft+900),
    100*mapaHeight/(mapBottom-mapTop+250)
    )));
//nastav ScrollBary
 Form1->ScrollBarX->SetParams(xposun,mapLeft,mapRight);
 Form1->ScrollBarY->SetParams(yposun,mapTop,mapBottom);
}

//---------------------------------------------------------------------------
//p�i smaz�n�/vytvo�en� silnice/zat��ky nebo po otev�en� souboru
void zmena()
{
Tkonec *o;
Tsilnice *c;

//sma� pomocn� uzly stupn� 2 a p�ed�lej na zat��ky
 start:
 fors(o,konce){
   if(o->naZatac()) goto start;
 }
//p�ekresli a p�epo�ti velikosti, zat��ky a okraje
 zmenaR();
 fors(c,silnice) c->spoctiZatac(1); //sta�� v jednom sm�ru
 okraje();
 modif=true;
 #ifdef DEBUG
 tst();
 #endif
}

//---------------------------------------------------------------------------
//  Vybr�n� objektu
//---------------------------------------------------------------------------
void activMain()
{
 activate=-1; //ignoruj ud�lost FormActivate
 Form1->SetFocus();
}
//---------------------------------------------------------------------------
void UpdateForms()
{
TFormE *f;

 switch(vybran*2+sim){
  case 2: f=FormSiln; break;
  case 4: f=FormVstup; break;
  case 5: f=InfoVstup; break;
  case 6: f=FormPark; break;
  case 7: f=InfoPark; break;
  case 10:f=FormKriz; break;
  case 11:f=InfoKriz; break;
  case 12:f=FormPrechod; break;
  case 13:f=InfoPrechod; break;
  default: f=0;
 }
//sma� star� okno
 if(activeForm && f!=activeForm) activeForm->Hide();
//zobraz nov� okno, ale neaktivuj ho
 if(f){
  //Show() mus� b�t p�ed UpdateAll(), jinak nefunguj� UpDown->Associate
   if(!f->Visible) f->Show();
   f->UpdateAll();
   activMain();
 }
 activeForm=f;
}
//---------------------------------------------------------------------------
void zrusVyber()
{
TUsiln *s;

 if(vybran){
  if(vybran==1){
    fors(s,selsiln){
      s->c->selected= s->c->opac->selected= false;
      s->c->paint2();
    }
    dellist(selsiln);
  }else{
    seluzel->selected=false;
    seluzel->paint();
  }
  vybran=0;
 }
}
//---------------------------------------------------------------------------
void zrusVyber2()
{
 zvyrazni(0,0);
 zrusVyber();
 UpdateForms();
 prvniU=0;
 prvniS=0;
}
//---------------------------------------------------------------------------
//vrac� d�lku nejkrat�� cesty od prvniU ke druhy1/druhy2
//seznam silnic d� do selsiln
int najdicestu()
{
Tuzel *u,*u2,*u1;
Tsilnice *c;
int d,d2,j;

//inicializace
 fors(c,silnice) c->spoctidelku();
 fors(u,uzly) u->t=MAXINT;
 u1=prvniU;
 u1->t=0;
 d=0;
 do{
  //oprav sousedy
   for(j=0; j<u1->Ds; j++){
     u2= u1->s[j]->opac->uzel;
     if(u2->typ!=PARK || u2==druhy1 && u2==druhy2){//nejezdi p�es parkovi�t�
       d2= d + u1->s[j]->delka;
       if(d2< u2->t) u2->t= d2;
     }
   }
  //ozna� za definitivn�
   u1->t= -u1->t;
  //najdi minim�ln� nedefinitivn� uzel
   d=MAXINT;
   fors(u,uzly) if(u->t<d && u->t>0){ d=u->t; u1=u; }
 }while(d<MAXINT && (druhy1->t>0 || druhy2->t>0));

//rozhodni se mezi druhy1 a druhy2
 u=druhy1;
 if(zvyraz.silnice){
   addlist(selsiln, zvyraz.silnice);
   if(prvniU==druhy1 || prvniU==druhy2)
      return zvyraz.silnice->delka;
   if(u->t < druhy2->t && druhy2->typ!=PARK || u->typ==PARK) u=druhy2;
 }
 if(u->t>=0) return MAXINT; //neexistuje cesta
 d= -u->t;
//rekonstrukce cesty
//postupuj od druhy k prvni
 while(u!=prvniU){
   for(j=0; j<u->Ds; j++){
     c= u->s[j];
     u2= c->opac->uzel;
     if(u2->t<=0 && u2->t- c->delka== u->t){
      //p�ipoj silnici do seznamu vybran�ch
       addlist(selsiln,c);
       u=u2;
       break;
     }
   }
 }
 return d;
}
//---------------------------------------------------------------------------
void TForm1::Select()
{
TUsiln *s,*s1;
Tuzel *u;
int d1,d2;
Tauto *a;

paintSelAuto();
if(sim && zvyraz.silnice){ //v�b�r jednoho auta
 if(lupa>9){
   dAuto=50.0;
   a=selauto;
   hledaniAuta=true;
   zvyraz.silnice->autapaint();
   zvyraz.silnice->opac->autapaint();
   hledaniAuta=false;
   if(a!=selauto){
     InfoAuto->cas0= cas;
     selautoX= selauto->X;
     selautoY= selauto->Y;
     InfoAuto->UpdateAll();
     InfoAuto->Show();
     activMain();
   }
 }
}else{
 if(zvyraz.uzel || zvyraz.silnice){
 zrusVyber(); //zru� p�edchoz� v�b�r
 if(shift && !sim && (prvniU || prvniS)){ //vyber nejkrat�� cestu
   if(zvyraz.uzel){
     druhy1= druhy2= zvyraz.uzel;
   }else{
     druhy1=zvyraz.silnice->uzel;
     druhy2=zvyraz.silnice->opac->uzel;
   }
   if(prvniS){
     prvniU=prvniS->uzel;
   }
   d1=najdicestu();
   if(prvniS){
    //uchovej v�sledek prvn�ho hled�n�
     s1=selsiln;
     selsiln=0;
    //hledej cestu od druh�ho uzlu silnice
     prvniU= prvniS->opac->uzel;
     d2=najdicestu();
    //vyber krat�� z nich
     if(d1<d2 && prvniS->uzel->typ!=PARK || prvniU->typ==PARK){
       dellist(selsiln);
       selsiln=s1;
     }else{
       dellist(s1);
     }
     if(!selsiln || (selsiln->c!=prvniS && selsiln->c!=prvniS->opac))
        addlist(selsiln,prvniS);
   }
   if(!selsiln){
     vybran=0;
   }else{
     vybran=1;
    //v�echny ��sti cesty mus� b�t stejn� orientovan�
     if(selsiln->nxt){
       u=selsiln->c->uzel;
       if(u!= selsiln->nxt->c->uzel && u!= selsiln->nxt->c->opac->uzel){
         selsiln->c= selsiln->c->opac;
       }
       u=0;
       fors(s,selsiln){
         if(s->c->uzel == u) s->c= s->c->opac;
         u=s->c->uzel;
       }
     }
   }
 }else{
  if(zvyraz.uzel){ //vyber uzel
   prvniU= seluzel= zvyraz.uzel;
   prvniS=0;
   switch(seluzel->typ){
    case VSTUP:
     selvstup=(Tvstup*)seluzel;
     vybran=2;
    break;
    case PARK:
     selpark=(Tpark*)seluzel;
     vybran=3;
    break;
    case KONEC:
     vybran=4;
    break;
    case KRIZ:
     selkriz=(Tkriz*)seluzel;
     vybran=5;
    break;
    case PRECHOD:
     selprechod=(Tprechod*)seluzel;
     vybran=6;
   }
   seluzel->selected=true;
   seluzel->paint();
  }else{ //vyber jednu silnici
    prvniS=zvyraz.silnice;
    addlist(selsiln,zvyraz.silnice);
    vybran=1;
  }
 }
 if(vybran==1){
   fors(s,selsiln){
     s->c->selected= s->c->opac->selected= true;
     s->c->paint2();
   }
 }
 UpdateForms();
}
}
paintSelAuto();
TimerSelect->Interval=0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TimerSelectTimer(TObject *Sender)
{
POINT p;
//automatick� vybr�n� objektu
 if(GetCursorPos(&p)){
   p=ScreenToClient(p);
   if(p.x<Mapa->Left || p.y<Mapa->Top){
     zvyrazni(0,0);
     return;
   }
 }
 if(!tazeni) Select();
 TimerSelect->Interval=0;
}

//---------------------------------------------------------------------------
//  Vytvo�en� nov� silnice
//---------------------------------------------------------------------------
Tsilnice* Tvstup::pridejsmer()
{
 throw Exception("Nelze p�ipojit silnici ke vstupu do m�sta");
}
//---------------------------------------------------------------------------
Tsilnice* Tprechod::pridejsmer()
{
 throw Exception("Nelze p�ipojit silnici k p�echodu pro chodce");
}
//---------------------------------------------------------------------------
Tsilnice* Tuzel::pridejsmer()
{
 if(Ds>=MAXDS) throw Exception("U� nelze p�ipojit dal�� silnici");
 return s[Ds++]= new Tsilnice(this);
}
//---------------------------------------------------------------------------
Tsilnice* Tkonec::pridejsmer()
{
Tkriz *k;
int j;

 if(Ds==2){
 //p�ed�lej pomocn� uzel na k�i�ovatku
   k=new Tkriz;
   k->Ds=2;
   k->pos=pos;
   for(j=0; j<2; j++){
     k->s[j]= new Tpruhy(k);
     k->s[j]->zatacky= s[j]->zatacky;
     s[j]->zatacky=0;
   }
   if(s[0]->opac->uzel==this){ //smy�ka
     propoj(k->s[0],k->s[1]);
   }else{
     propoj(k->s[0],s[0]->opac);
     propoj(k->s[1],s[1]->opac);
   }
   delete this;
   return k->pridejsmer();
 }
 return Tuzel::pridejsmer();
}
//---------------------------------------------------------------------------
Tsilnice* Tkriz::pridejsmer()
{
int i,j;
Tpruhy *p;
Tsilnice *c;
Tsemafory *e;
static int z[]= {10,4,7,8};

 if(Ds>=4) throw Exception("K�i�ovatka u� m� stupe� 4");
//vytvo� nov� sm�r
 c= p= s[Ds]= new Tpruhy(this);
 for(i=0; i<Ds; i++){
   p->pruhu[i+1]= (s[i]->opac->pruhu0 !=0); //neodbo�uj do jednosm�rky
 }
//p�idej pruh odbo�uj�c� do nov�ho sm�ru
 for(j=0; j<Ds; j++){
   p=s[j];
   for(i=Ds; i>Ds-j; i--) p->pruhu[i]= p->pruhu[i-1];
   p->pruhu[Ds-j]=1;
 }
 Ds++;
 if(Ds==4){
  //typ hlavn� silnice
   hlavni= z[hlavni];
  //semafory
   fors(e,semaf) e->id+=12;
  //p�ipoj do seznamu nov� semafor
   if(lenlist(semaf)<Msemaf) addlist(semaf,16);
 }
 return c;
}
//---------------------------------------------------------------------------
Tsilnice* novakrizov(Tnovainfo info, int typ)
{
Tpruhy *p;
Tkriz *k;
Tuzel *u;
Tzatacka *z;
int i;

 if(info.uzel){ //p�ipoj k uzlu
   return info.uzel->pridejsmer();
 }
 if(info.silnice){ //p�ipoj k silnici
    info.silnice->getZatac();
    if(info.jezatac){ //p�ipoj k zat��ce
      z=info.zatacka->nxt;
      info.zatacka->nxt= z->nxt;
      delete z;
    }
   //vytvo� k�i�ovatku stupn� 3
    k=new Tkriz;
    k->Ds=2; //nejd��ve 2, pak pridejsmer()
    k->pos=info.pos;
   //3 nov� semafory
    for(i=1;i<=3;i++) addlist(k->semaf,i);
   //vytvo� pruhy
    p= k->s[1]= new Tpruhy(k);
    p->pruhu0= p->pruhu[1]= info.silnice->opac->pruhu0;
    p->rychlost= info.silnice->opac->rychlost;
    p= k->s[0]= new Tpruhy(k);
    p->pruhu0= p->pruhu[1]= info.silnice->pruhu0;
    p->rychlost= info.silnice->rychlost;
   //rozd�l seznam zat��ek a vytvo� dv� nov� zat��ky na pozici my�i
   //    info.silnice  ---  [1](k)[0]  ---  opac
    p->zatacky= new Tzatacka(info.pos,info.zatacka->nxt);
    info.zatacka->nxt= new Tzatacka(info.pos,0);
    propoj(p,info.silnice->opac);
    propoj(k->s[1],info.silnice);
    return k->pridejsmer();
 }
//vytvo� nov� uzel
 switch(typ){ //PopUp Menu -> MenuItem -> Tag
   case 1: //pomocn� uzel
     u=new Tkonec;
   break;
   case 2: //vstup do m�sta
     u=new Tvstup;
   break;
   case 3: //parkovi�t�
     u=new Tpark;
   break;
 }
 u->pos= info.pos;
 return u->s[0]= new Tsilnice(u);
}
//---------------------------------------------------------------------------
void TForm1::novaSilnice()
{
Tuzel *u;
Tsemafory *e;
int i;

 zrusVyber2();
//vytvo� silnici
 novasiln[0]=novakrizov(nova2,novtyp2);
 novasiln[1]=novakrizov(nova,novtyp);
 novasiln[0]->zatacky= new Tzatacka( novasiln[0]->uzel->pos,
    new Tzatacka(novasiln[1]->uzel->pos,0) );

 propoj(novasiln[0],novasiln[1]);
 for(i=0;i<2;i++){
   u=novasiln[i]->uzel;
   u->setrid();
   if(u->typ==KRIZ){
     fors(e,((Tkriz*)u)->semaf) if(e->id>12) e->id-=7;
   }
 }
 zmena();
//vyber krajn� uzel a aktivuj okno
 if(!(u->typ & CIL)) u=novasiln[0]->uzel;
 zvyrazni(u,0);
 Select();
 if(activeForm && (u->typ & CIL) && !((Tcil*)u)->jmeno[0])
     activeForm->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Popup1Click(TObject *Sender)
{
 novtyp=((TMenuItem*)Sender)->Tag;
 if(novtyp){ //nebylo storno
  if(pocPopup==0){
   novtyp2=novtyp;
   if(!nova.uzel && !nova.silnice){
      popup(nova.pos);
      pocPopup=2;
      return;
   }
  }
  novaSilnice();
 }
}
//---------------------------------------------------------------------------
void TForm1::popup(Tpos &pos)
{
TPoint p;

//p�epo�ti pozici na Screen, nesm� b�t mimo obrazovku
 p.x=calX(pos.x);
 p.y=calY(pos.y);
 amax(p.x, Longint(mapaWidth-128));
 amax(p.y, Longint(mapaHeight-34));
 amin(p.x,Longint(0));
 amin(p.y,Longint(0));
 p= Mapa->ClientToScreen(p);
 SetCursorPos(p.x+7,p.y+7);
 TimerSelect->Interval=0;
 PopupMenu1->Popup(p.x,p.y);
}
//---------------------------------------------------------------------------
void Tuzel::ubersmer(int kde)
{
int i;

 if(Ds==1){
   delete this;
 }else{
   delete s[kde];
   Ds--;
   for(i=kde;i<Ds;i++) s[i]=s[i+1];
 }
}
//---------------------------------------------------------------------------
void Tprechod::ubersmer(int kde)
{
Tkonec *o;

 //p�ed�lej p�echod na pomocn� uzel
  Tuzel::ubersmer(kde);
  o=new Tkonec;
  o->pos=pos;
  o->s[0]=s[0];
  o->s[0]->uzel=o;
  Ds=0;
  delete this;
}
//---------------------------------------------------------------------------
void Tkriz::ubersmer(int kde)
{
int i,j,m;
Tsemafory *e,**pe;
Tkonec *o;
Tpruhy *p;
static int A[4][9]={{2,1,0,1,2,3,3,2,0},{2,3,1,0,2,3,3,1,0},
 {1,3,1,2,0,3,2,1,0},{1,2,1,2,3,0,2,3,0}};

//uber odbo�ky do ru�en�ho sm�ru
 for(i=0;i<Ds;i++){
   p=s[i];
   if(i!=kde){
     if((m=kde-i)<0) m+=Ds;
     for(j=m+1; j<Ds; j++) p->pruhu[j-1]=p->pruhu[j];
   }
 }
//vyma� z s[]
 Tuzel::ubersmer(kde);

 switch(Ds){
  case 2:
  //p�ed�lej k�i�ovatku na pomocn� uzel
    o=new Tkonec;
    o->Ds=2;
    o->pos=pos;
    o->s[0]=s[0];
    o->s[0]->uzel=o;
    o->s[0]->delodboc=0;
    o->s[1]=s[1];
    o->s[1]->uzel=o;
    o->s[1]->delodboc=0;
    Ds=0;
    delete this;
  break;
  case 3:
  //zm�� ze 4 na 3
   if(hlavni==10) hlavni=0;
   else hlavni=A[kde][hlavni-4];
  //semafory
   pe=&semaf;
   while((e=*pe)!=0){
     e->id=A[kde][e->id-4];
     if(!e->id){
       *pe=e->nxt;
       delete e;
     }else{
       pe=&e->nxt;
     }
   }
  break;
 }
}
//---------------------------------------------------------------------------
//p�ed�l�n� uzle stupn� 2 na zat��ku
//p�i �sp�chu vrac� true
bool Tuzel::naZatac()
{
Tsilnice *c0,*c1,*c0o,*c1o;
Tzatacka *z1,*z2;

 if(Ds!=2) return false;
 c0=s[0];
 c1=s[1];
 c0o=c0->opac;
 if(c0o==c1) return false; //vznikla by smy�ka
 c1o=c1->opac;
 z1=c0o->getZatac();
 z2=c1->getZatac();
//spoj oba seznamy a sma� jednu zat��ku uprost�ed
 catlist(z1,z2->nxt);
 delete z2;
 c1->zatacky=0;
 propoj(c0o,c1o);
 amin(c0o->pruhu0,c1->pruhu0);
 amin(c1o->pruhu0,c0->pruhu0);
 delete this;
 c0o->zruszatac();
 if(novasiln[0]==c0) novasiln[0]=c0o;
 if(novasiln[1]==c0) novasiln[1]=c0o;
 if(novasiln[0]==c1) novasiln[0]=c1o;
 if(novasiln[1]==c1) novasiln[1]=c1o;
 return true;
}

//---------------------------------------------------------------------------
//  Pr�ce se souborem
//---------------------------------------------------------------------------
void TForm1::smazMesto()
{
 modif=false;
//zastav simulaci
 ButtonResetClick(0);
//zru� v�b�r, zv�razn�n� a vedlej�� okno
 zrusVyber2();
//sma� v�echny objekty
 dellist(uzly);
 Caption=formCaption;
 okraje();
 lupa=10;
 delete pozadi;
 pozadi=0;
 zoom();
}
//---------------------------------------------------------------------------
void Tsilnice::Load()
{
 pruhu0=(short)fgetc(f);
 rychlost=(short)fgetc(f);
}
//---------------------------------------------------------------------------
void Tsilnice::Save()
{
 fputc(pruhu0,f);
 fputc(rychlost,f);
}
//---------------------------------------------------------------------------
bool TForm1::saveMesto()
{
int j;
int Dk,Dv,Dc,Dr,Dh;
Tkriz* k;
Tprechod* h;
Tvstup* v;
Tpark* r;
Tkonec *o;
Tsilnice* c;
Tpruhy* p;
Tsemafory* e;
Tzatacka* z;

 if(filename=="") return saveAs();
 if((f=fopen(filename.c_str(),"wb"))==0)
    throw Exception("Soubor nelze otev��t pro z�pis");
 fputs(zahlavi,f); //hlavi�ka
 //o��sluj uzly
 Dv=0;
 fors(v,vstupy) v->tag=Dv++;
 Dr=Dv;
 fors(r,parkoviste) r->tag=Dr++;
 Dk=Dr;
 fors(o,konce) o->tag=Dk++;
 fors(k,krizovatky) k->tag=Dk++;
 Dh=Dk;
 fors(h,prechody) h->tag=Dh++;
 Dh-=Dk;
 Dk-=Dr;
 Dr-=Dv;
//spo��tej silnice
 Dc=0;
 fors(c,silnice) Dc++;
 Dc/=2;

 fputc('7',f);   //verze
 fwrite(&Dr,2,1,f);
 fwrite(&Dk,2,1,f);
 fwrite(&Dv,2,1,f);
 fwrite(&Dc,2,1,f);
 fwrite(&Dh,2,1,f);
//ulo� vstupy
 fors(v,vstupy){
   fwrite(&v->pos,sizeof(Tpos),1,f);
   fwrite(&v->jmeno,sizeof(v->jmeno),1,f);
   fwrite(&v->cislo,sizeof(v->cislo),1,f);
   fwrite(&v->prijizdi,2,1,f);
   v->s[0]->Save();
 }
//ulo� parkovi�t�
 fors(r,parkoviste){
   fputc(r->Ds,f);
   fwrite(&r->pos,sizeof(Tpos),1,f);
   fwrite(&r->jmeno,sizeof(r->jmeno),1,f);
   fwrite(&r->prijizdi,2,1,f);
   fwrite(&r->Mpark,2,1,f);
   for(j=0; j<r->Ds; j++) r->s[j]->Save();
 }
//ulo� pomocn� uzly
 fors(o,konce){
   fputc(o->Ds,f);
   fwrite(&o->pos,sizeof(Tpos),1,f);
   for(j=0; j<o->Ds; j++) o->s[j]->Save();
 }
//ulo� k�i�ovatky
 fors(k,krizovatky){
   fputc(k->Ds,f);
   fwrite(&k->pos,sizeof(Tpos),1,f);
   fputc(k->hlavni,f);
   fputc(k->jesemaf,f);
   fputc(k->viceurovn,f);
   fwrite(&k->caszmen0,2,1,f);
   for(j=0; j<k->Ds; j++){
    p=k->s[j];
    p->Save();
    fwrite(&p->delodboc,2,1,f);
    fputc(p->lspolec,f);
    fputc(p->rspolec,f);
    fputc(p->pruhu[1],f);
    fputc(p->pruhu[2],f);
    fputc(p->pruhu[3],f);
   }
  //po�et semafor�
   fputc(lenlist(k->semaf), f);
  //ulo� semafoy
   fors(e,k->semaf){
     fputc(e->id,f);
     fwrite(&e->interval,2,1,f);
   }
 }
//ulo� p�echody pro chodce
 fors(h,prechody){
   fwrite(&h->pos,sizeof(Tpos),1,f);
   fputc(h->jesemaf,f);
   fwrite(&h->caszmen0,2,1,f);
   fwrite(&h->chodci,2,1,f);
   fwrite(&h->auta,2,1,f);
   fwrite(&h->tlacitko,2,1,f);
   for(j=0; j<2; j++) h->s[j]->Save();
 }
//ulo� silnice
 fors(c,silnice)
  if(c->zatacky){
    fwrite(&c->uzel->tag,2,1,f);
    fwrite(&c->opac->uzel->tag,2,1,f);
    fputc(c->smer,f);
    fputc(c->opac->smer,f);
  //po�et zat��ek
    for(z=c->zatacky, j=-2;  z;  z=z->nxt, j++);
    fputc(j,f);
   //ulo� zat��ky bez dvou krajn�ch
    for(z=c->zatacky->nxt;  j>0;  z=z->nxt, j--)
      fwrite(&z->pos,sizeof(Tpos),1,f);
  }
//kontroln� znak
 fputc(100,f);
//ulo� konfiguraci
 fwrite(&RychPosun,2,1,f);
 fwrite(&DPOSUN,2,1,f);
 fwrite(&VYBRINT,2,1,f);
 fwrite(&DKROK,2,1,f);
 fwrite(&DQUICK,2,1,f);
 fwrite(&interval0,2,1,f);
 fwrite(&delodboc0,2,1,f);
 fwrite(&Mpark0,2,1,f);
 fwrite(&prijizdi0,2,1,f);
 fwrite(&Dxmriz,2,1,f);
 fwrite(&xmriz,2,1,f);
 fwrite(&ymriz,2,1,f);
 fputc(M1->Checked,f);
 fwrite(&Dymriz,2,1,f);
 fputc(Inverznbarvy1->Checked,f);
 fputc(Nvykres,f);
 fwrite(&chodci0,2,1,f);
 fwrite(&auta0,2,1,f);

 fwrite(&Dxpozadi,2,1,f);
 fwrite(&Dypozadi,2,1,f);
 fwrite(&xpozadi,2,1,f);
 fwrite(&ypozadi,2,1,f);
 fputc(bmpFile.Length(),f);
 fwrite(bmpFile.c_str(),bmpFile.Length(),1,f);

 if(fclose(f)) throw Exception("Chyba p�i z�pisu do souboru");
 modif=false;
 return true;
}
//---------------------------------------------------------------------------
void TForm1::openMesto()
{
int i,j,s1,s2;
int Dk,Dv,Dc,Dr,Dh,Duzly,ind,verze;
Tkriz* k;
Tprechod* h;
Tvstup *v;
Tpark *r;
Tcil *rv;
Tuzel *u1,*u2,*u;
Tpruhy* p;
Tsemafory *e, **ue;
Tzatacka *z, **uz;
Tuzel **Auzly,**Uuzly;
Tkriz *kriz0;
char *s;

  if((f=fopen(filename.c_str(),"rb"))==0)
     throw Exception("Nelze otev��t soubor");
//zkontroluj hlavi�ku souboru a verzi
  fgets(buf,48,f);
  if(strcmp(zahlavi,buf)) throw Exception("Soubor neobsahuje silni�n� s�");
  smazMesto();
  Dk=Dv=Dh=Dc=Dr=ind=0;
  //--------------------------------------------------------
  verze=fgetc(f);
  if(verze>'6') throw Exception("Soubor byl vytvo�en nov�j�� verz� programu");
  if(verze<'3'){
   fread(&Dk,4,1,f);
   fread(&Dv,4,1,f);
   fread(&Dc,4,1,f);
   if(Dk<0 || Dk>32767 || Dv<0 || Dv>32767 || Dc<0 || Dc>32767){
     throw Exception("Soubor je po�kozen");
   }
   Uuzly=Auzly=new Tuzel*[Duzly=Dk+Dv];
   for(i=0;i<Dv;i++){
    Tpos a1;
    short a2,a3;
    Tjmeno a4;

    fread(&a1,sizeof(Tpos),1,f);
    fread(&a2,2,1,f);
    fread(&a3,2,1,f);
    fread(&a4,16,1,f);
    if(fgetc(f)){
      *Uuzly++= rv= r= new Tpark;
      r->Mpark=a3;
    }else{
      *Uuzly++= rv= new Tvstup;
    }
    rv->pos=a1;
    rv->prijizdi=a2;
    strcpy(rv->jmeno,a4);
    ( rv->s[0]= new Tsilnice(rv) )->Load();
   }
  //--------------------------------------------------------
  }else{
   fread(&Dr,2,1,f);
   fread(&Dk,2,1,f);
   fread(&Dv,2,1,f);
   fread(&Dc,2,1,f);
   if(verze>'5') fread(&Dh,2,1,f);
   Uuzly=Auzly=new Tuzel*[Duzly=Dk+Dv+Dr+Dh];
  //vstupy
   for(i=0;i<Dv;i++){
     *Uuzly++= v= new Tvstup;
     fread(&v->pos,sizeof(Tpos),1,f);
     fread(&v->jmeno,sizeof(v->jmeno),1,f);
     fread(&v->cislo,sizeof(v->cislo),1,f);
     fread(&v->prijizdi,2,1,f);
     ( v->s[0]= new Tsilnice(v) )->Load();
   }
  //parkovi�t�
   for(i=0;i<Dr;i++){
     *Uuzly++= r= new Tpark;
     r->Ds=fgetc(f);
     if(r->Ds>MAXDS || r->Ds<1) r->Ds=0;
     fread(&r->pos,sizeof(Tpos),1,f);
     fread(&r->jmeno,sizeof(r->jmeno),1,f);
     fread(&r->prijizdi,2,1,f);
     fread(&r->Mpark,2,1,f);
     for(j=0; j<r->Ds; j++){
      ( r->s[j]= new Tsilnice(r) )->Load();
     }
   }
  }
  //--------------------------------------------------------

 //k�i�ovatky
  kriz0=new Tkriz;
  for(i=0; i<Dk; i++){
    j=fgetc(f);
    if(j<3){
      *Uuzly++= u= new Tkonec;
      u->Ds=j;
      u->s[0]= new Tsilnice(u);
      if(j==2) u->s[1]= new Tsilnice(u);
      k=kriz0;
      if(verze>='5'){
       fread(&u->pos,sizeof(Tpos),1,f);
       u->s[0]->Load();
       if(j==2) u->s[1]->Load();
       k=0;
      }
    }else{
      *Uuzly++= k= new Tkriz;
      k->Ds=j;
    }
    if(k){
     if(k->Ds>4 || k->Ds<1) k->Ds=0;
     fread(&k->pos,sizeof(Tpos),1,f);
     if(verze<'3'){
       k->jesemaf=fgetc(f);
       k->hlavni=(short)fgetc(f);
     }else{
       k->hlavni=(short)fgetc(f);
       k->jesemaf=fgetc(f);
       k->viceurovn=fgetc(f);
     }
     fread(&k->caszmen0,2,1,f);
     for(j=0; j<k->Ds; j++){
      k->s[j]= p= new Tpruhy(k);
      if(verze>='3') p->Load();
      if(k->Ds>2 || verze<'3'){
        fread(&p->delodboc,2,1,f);
        p->lspolec=fgetc(f);
        p->rspolec=fgetc(f);
        if(verze<'3') p->pruhu0=(short)fgetc(f);
        p->pruhu[1]=(short)fgetc(f);
        p->pruhu[2]=(short)fgetc(f);
        p->pruhu[3]=(short)fgetc(f);
        if(verze<'3') p->rychlost=(short)fgetc(f);
      }
     }
    //semafory
     ue=&k->semaf;
     for(j=fgetc(f); j>0; j--){
       *ue=e=new Tsemafory(fgetc(f));
       ue=&e->nxt;
       fread(&e->interval,2,1,f);
     }
     *ue=0;
     if(k->Ds<3 && k->Ds>0){
       u->pos=k->pos;
       u->s[0]->pruhu0= k->s[0]->pruhu0;
       u->s[0]->rychlost= k->s[0]->rychlost;
       delete k->s[0];
     }
    }
  }
  kriz0->semaf=0;
  kriz0->Ds=0;
  delete kriz0;

 //p�echody pro chodce
  for(i=0;i<Dh;i++){
    *Uuzly++= h= new Tprechod;
    fread(&h->pos,sizeof(Tpos),1,f);
    h->jesemaf=fgetc(f);
    fread(&h->caszmen0,2,1,f);
    fread(&h->chodci,2,1,f);
    fread(&h->auta,2,1,f);
    fread(&h->tlacitko,2,1,f);
    for(j=0; j<2; j++)
      ( h->s[j]= new Tsilnice(h) )->Load();
  }

 //silnice
  for(i=0;i<Dc;i++){
    fread(&ind,2,1,f);
    if(ind>=Duzly || ind<0) break;
    u1=Auzly[ind];
    fread(&ind,2,1,f);
    if(ind>=Duzly || ind<0) break;
    u2=Auzly[ind];
    s1=fgetc(f);
    s2=fgetc(f);
    if(s1>=u1->Ds || s2>=u2->Ds) break;
    propoj(u1->s[s1],u2->s[s2]);
    j=fgetc(f);
    z= u1->s[s1]->zatacky= new Tzatacka(u1->pos,0);
    for(uz=&z->nxt; j>0; j--){
      *uz=z=new Tzatacka;
      uz=&z->nxt;
      fread(&z->pos,sizeof(Tpos),1,f);
    }
    *uz=new Tzatacka(u2->pos,0);
  }

  delete[] Auzly;
  if(verze>='3' && fgetc(f)!=100){
     smazMesto();
     fclose(f);
     filename="";
     throw Exception("Soubor je po�kozen");
  }
 //nastaven�
  fread(&RychPosun,2,1,f);
  fread(&DPOSUN,2,1,f);
  fread(&VYBRINT,2,1,f);
  fread(&DKROK,2,1,f);
  fread(&DQUICK,2,1,f);
  fread(&interval0,2,1,f);
  fread(&delodboc0,2,1,f);
  fread(&Mpark0,2,1,f);
  fread(&prijizdi0,2,1,f);
  fread(&Dxmriz,2,1,f);
  fread(&xmriz,2,1,f);
  fread(&ymriz,2,1,f);
  M1->Checked=fgetc(f);
  if(verze>'3'){
   fread(&Dymriz,2,1,f);
   if(fgetc(f)!=Inverznbarvy1->Checked) Inverznbarvy1Click(Inverznbarvy1);
   Nvykres=(short)fgetc(f);
   if(verze>'5'){
    fread(&chodci0,2,1,f);
    fread(&auta0,2,1,f);
    if(verze>'6'){
     fread(&Dxpozadi,2,1,f);
     fread(&Dypozadi,2,1,f);
     fread(&xpozadi,2,1,f);
     fread(&ypozadi,2,1,f);
     i=0;
     fread(&i,1,1,f);
     s=new char[i];
     fread(s,i,1,f);
     bmpFile=AnsiString(s,(unsigned char)i);
     delete[] s;
    }else{
     bmpFile="";
    }
   }
  }else{
   Dymriz=Dxmriz;
   RychPosun=4000/RychPosun+1;
  }
  amin(Nvykres,(short)1);
  amax(Nvykres,(short)50);
 //zav�i soubor
  if(fclose(f)){
    smazMesto();
    filename="";
    throw Exception("Chyba p�i �ten� ze souboru");
  }else{ //�sp�n� na�ten� soubor
    Caption=formCaption + "  -  " + filename;
    zmena();
    modif=false;
    if(!bmpFile.IsEmpty()){
     pozadi=new Graphics::TBitmap;
     pozadi->LoadFromFile(bmpFile);
    }
    Vycentrovat1Click(0);
    lupa=1;
    zoom();
  }
}
//---------------------------------------------------------------------------
bool TForm1::saveAs()
{
 if(TimerSim->Enabled) ButtonPauseClick(this);
 if(SaveDialog1->Execute()){
   filename=SaveDialog1->FileName;
   Caption= formCaption + "  -  " + filename;
   return saveMesto();
 }
 return false;
}
//---------------------------------------------------------------------------
bool TForm1::savemodif()
{
 if(modif){
  switch(Application->MessageBox(
   "M�sto bylo zm�n�no. Chcete ho ulo�it ?",
   "Ulo�it",MB_YESNOCANCEL)){
   default:
    return false;
   case IDNO:
    return true;
   case IDYES:
    return saveMesto();
  }
 }
 return true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonOpenClick(TObject *Sender)
{
 if(TimerSim->Enabled) ButtonPauseClick(Sender);
 if(savemodif())
  if(OpenDialog1->Execute()){
    filename=OpenDialog1->FileName;
    openMesto();
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonSaveClick(TObject *Sender)
{
 saveMesto();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonNewClick(TObject *Sender)
{
 if(savemodif()){ smazMesto(); filename=""; }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Uloitjako1Click(TObject *Sender)
{
 saveAs();
}

//---------------------------------------------------------------------------
//  Ovl�d�n� simulace
//---------------------------------------------------------------------------
void IntTo00(int i,char *t)
{
 t[0]=(char)(i/10+'0');
 t[1]=char(i%10+'0');
}
//---------------------------------------------------------------------------
char * intToCas(int i)
{
static char t[]="00:00:00";

 IntTo00(i%60,t+6);
 i/=60;
 IntTo00(i%60,t+3);
 i/=60;
 IntTo00(i%24,t);
 return t;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonPlayClick(TObject *Sender)
{
int i;

 ButtonPlay->Down=true; //kv�li odkazu z menu
 ButtonPause->Hint="Zastavit";
 startsim();
 if(play){
   Screen->Cursor= crHourGlass;
   for(i=DQUICK*300; i>0; i--) kroksim();
   Screen->Cursor= crDefault;
 }
 TimerSim->Enabled=true;
 play=true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonFastClick(TObject *Sender)
{
 ButtonFast->Down=true;
 play=false;
 ButtonPause->Hint="Zastavit";
 startsim();
 TimerSim->Enabled=true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonPauseClick(TObject *Sender)
{
int i;

 ButtonPause->Down=true;
 play=false;
 ButtonPause->Hint="Krokovat";
 startsim();
 if(TimerSim->Enabled){
  //zastaven�
   TimerSim->Enabled=false;
 }else{
  //krokov�n�
   for(i=DKROK; i>0; i--) kroksim();
   SimPaint(DKROK);
   LabelTime->Caption= intToCas(cas/5);
   InfoPaint();
 }
}
//---------------------------------------------------------------------------
void zrusSelauto()
{
 InfoAuto->Hide();
 paintSelAuto();
 selautoX=-1;
 selauto=0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonResetClick(TObject *Sender)
{
 ButtonReset->Down=true;
 play=true;
 ButtonPause->Hint="Krokovat";
 if(sim){
  resetsim();
  zrusSelauto();
  LabelTime->Caption="";
  StatusBar1->Panels->Items[2]->Text="";
  StatusBar1->Panels->Items[3]->Text="";
  TimerSim->Enabled=false;
 }
}
//---------------------------------------------------------------------------
void AutaPaint()
{
Tauto *a,*a1;
Tsilnice *c;

//sma� auta, co odjela
 for(a=odjela; a; a=a1){
   a->smaz();
   a1=a->nxt;
   a->nxt=kos;
   kos=a;
 }
 odjela=0;
//nakresli auta
 fors(c,silnice) c->autapaint();
}
//---------------------------------------------------------------------------
void TForm1::InfoPaint()
{
static char *s2="Po�et aut:           ",
            *s3="P�ijelo do m�sta:           ";

//obnov vedlej�� okna
 if(activeForm) activeForm->update();
 InfoAuto->update();
 itoa(Daut,s2+11,10);
//obnov StatusBar
 StatusBar1->Panels->Items[2]->Text=s2;
 itoa(Nprijelo,s3+18,10);
 StatusBar1->Panels->Items[3]->Text=s3;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SimPaint(int rych)
{
Tkriz *k;
Tprechod *h;
int i;
static int sec=0;

//nakresli auta
 paintSelAuto();
 AutaPaint();
//zobraz �tverec kolem vybran�ho
 if(selauto){
   selautoX=selauto->X;
   selautoY=selauto->Y;
   paintSelAuto();
 }else{
   selautoX=-1;
 }
//posu� mapu, kdy� je vybran� auto na okraji
 if(selauto && selautoX>=0){
   rych=min(200,lupa*(rych/2+2)/10);
   if(selautoX<rych || selautoX>mapaWidth-rych
       || selautoY<rych || selautoY>mapaHeight-rych){
     if(canmove) zamerit(calxm(selautoX),calym(selautoY));
   }else{
     canmove=true;
   }
 }
//ka�dou sekundu obnov �as a semafory
 i=cas/5;
 if(i!=sec){
  LabelTime->Caption= intToCas(sec=i);
  fors(k,krizovatky) k->paintSemaf();
  fors(h,prechody) h->paintSemaf();
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TimerSimTimer(TObject *Sender)
{
int m,j,mo;
static int poc=1;

//nastav �asova� podle rychlosti simulace
 if(ButtonFast->Down){
   j= max(1000/Nvykres,199/Speed->Position+1);
   mo= j* Speed->Position /200;
 }else{
   j=200;
   mo=1;
 }
 TimerSim->Interval=j;
//prove� simulaci
 for(m=mo; m>0; m--) kroksim();
 SimPaint(mo);
 if(--poc<=0){
   poc=250/j;
   InfoPaint();
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::WndProc(Messages::TMessage &Message)
{
//o smaz�n� ��st� okna mimo Mapu se postaraj� Panel1 a Panel2
 if(Message.Msg!=WM_ERASEBKGND) TForm::WndProc(Message);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::MapaPaint(TObject *Sender)
{
Tsilnice *c;
Tuzel *u;
Tfronta *f;
Tauto *a;
int i,x,y,di;

//m�sto na obrazovku se bude kreslit do bitmapy
 if(bitmapa) mapcanvas=bitmapa->Canvas;
//sma� bitmapu
 if(pozadi && !pozadi->Empty){
   mapcanvas->CopyRect(
     Rect(calX(xpozadi-Dxpozadi),calY(ypozadi-Dypozadi),
      calX(xpozadi+Dxpozadi),calY(ypozadi+Dypozadi)),
     pozadi->Canvas,
     Rect(0,0,pozadi->Width,pozadi->Height));
 }else{
   mapcanvas->Brush->Color= clMapa;
   mapcanvas->FillRect(Rect(0,0,mapaWidth,mapaHeight));
 }

 cara=false;
 if(sim){
 //v�em aut�m nastav, �e u� jsou smaz�ny
  for(f=Afronty, i=Dfronty; i>0; f++,i--)
    for(a=f->auta; a; a=a->nxt)
      a->X=-1;
 //odjet� auta dej do ko�e
  if(odjela){
    for(a=odjela; a->nxt; a=a->nxt);
    a->nxt=kos;
    kos=odjela;
    odjela=0;
  }
 }
//nakresli m��
 if(!sim && M1->Checked){
   mapcanvas->Pen->Color= clMriz;
   di=Dxmriz;
   while(di<2000/lupa) di*=2;
   for(i=mapaWidth*100/lupa-(calxm(mapaWidth)-xmriz)%di; i>0; i-=di){
     x=i*lupa/100;
     mapcanvas->MoveTo(x,0);
     mapcanvas->LineTo(x,mapaHeight-1);
   }
   di=Dymriz;
   while(di<2000/lupa) di*=2;
   for(i=mapaHeight*100/lupa-(calym(mapaHeight)-ymriz)%di; i>0; i-=di){
     y=i*lupa/100;
     mapcanvas->MoveTo(0,y);
     mapcanvas->LineTo(mapaWidth-1,y);
   }
 }
//nakresli v�echny objekty
 fors(c,silnice) c->paint();
 fors(u,uzly) u->paint();
 if(sim) AutaPaint();
//p�ekop�ruj bitmapu do okna
 mapcanvas= Mapa->Canvas;
 if(bitmapa) mapcanvas->Draw(0,0,bitmapa);
//p�i kreslen� do pam�ti by nefungovalo maz�n� operac� xor
 if(sim){
  if(selauto){
   selautoX=selauto->X;
   selautoY=selauto->Y;
   paintSelAuto();
  }else{
   selautoX=-1;
  }
 }else{
  taznov1();
 }
}
//---------------------------------------------------------------------------
void TForm1::clipCur()
{
TRect r;

 r= Mapa->ClientRect;
 r.TopLeft= Mapa->ClientToScreen(r.TopLeft);
 r.BottomRight= Mapa->ClientToScreen(r.BottomRight);
 ClipCursor((RECT *)&r);
}
//---------------------------------------------------------------------------
void TForm1::setCursor(TCursor cur)
{
//p�i proveden� SetCapture lze m�nit jen kurzor cel� aplikace
  if(leftDown || rightDown) Screen->Cursor=cur;
  else Mapa->Cursor=cur;
}
//---------------------------------------------------------------------------
bool TForm1::MapaPosun1(int b,int X,int Y)
{
/*
b: 0=jen zm�� kurzor my�i, (p�i MouseMove)
   1=hned posu� mapu,   (p�i MouseDown)
   2=nastav TimerPosun  (p�i ta�en�)
*/
int dx,dy;
int XMAX,YMAX;

 XMAX= 32000-XS*100/lupa;
 YMAX= 32000-YS*100/lupa;
 dx=dy=0;
 if(X<DPOSUN && xposun>-XMAX){
    dx=X-DPOSUN;
    setCursor(crMovLeft);
 }
 if(X>mapaWidth-DPOSUN && xposun<XMAX){
    dx=X-mapaWidth+DPOSUN;
    setCursor(crMovRight);
 }
 if(Y<DPOSUN && yposun>-YMAX){
    dy=Y-DPOSUN;
    setCursor( X<DPOSUN ? crMovLU :
      (X>mapaWidth-DPOSUN ? crMovRU : crMovUp));
 }
 if(Y>mapaHeight-DPOSUN && yposun<YMAX){
    dy=Y-mapaHeight+DPOSUN;
    setCursor( X<DPOSUN ? crMovLD :
      (X>mapaWidth-DPOSUN ? crMovRD : crMovDown));
 }
 mapposunx= dx*RychPosun/20.0;
 mapposuny= dy*RychPosun/20.0;
 if(mapposunx || mapposuny){
   if(b==1) MapaPosun2();
   if(b) TimerPosun->Interval=POSUNINT;
   TimerSelect->Interval=0;
   return true;
 }else{
 //kurzor nen� na okraji
   if(tazeni) TimerPosun->Interval=0;
   setCursor(tazeni==2 ? crPresun:crArrow);
   return false;
 }
}
//---------------------------------------------------------------------------
void TForm1::MapaPosun2()
{
canmove=false;
if(mapposunx || mapposuny){  //glob�ln� prom�nn�
 zamerit(xposun+int(mapposunx*100.0/lupa),yposun+int(mapposuny*100.0/lupa));
}
}
//---------------------------------------------------------------------------
//p�esunut� zvyraz na pozici p
//ma�ou se jen p�esouvan� objekty
void Presun(Tpos p,bool allowRet)
{
int j,Ds;
Tuzel *u1,*u2;
Tsilnice *c;

 if(nova.uzel){ //p�esun uzlu
   Ds=nova.uzel->Ds;
  //sousedn� zat��ky a uzly
   for(j=0; j<Ds; j++){
     c=nova.uzel->s[j];
     if(vzdalenost(p, c->opac->uzel->pos) <MINK && allowRet) return;
     if(vzdalenost(p, c->getZatac()->nxt->pos) <MINK && allowRet) return;
   }
  //zm�� pozici
   nova.uzel->pos=p;
   for(j=0; j<Ds; j++) nova.uzel->s[j]->getZatac()->pos= nova.uzel->pos;
  //oprav po�ad� sm�r�
   nova.uzel->setrid();
   for(j=0; j<Ds; j++){
     nova.uzel->s[j]->opac->uzel->setrid();
     nova.uzel->s[j]->spoctiZatac(0);
   }
 }else{ //p�esun zat��ky
   nova.silnice->getZatac();
   u1= nova.silnice->uzel;
   u2= nova.silnice->opac->uzel;
   if(vzdalenost(p,nova.zatacka->pos)<MINZ && allowRet) return;
   if(vzdalenost(p,nova.zatacka->nxt->nxt->pos)<MINZ && allowRet) return;
   if(nova.silnice->zatacky==nova.zatacka){
     if(vzdalenost(p,u1->pos)<MINZK && allowRet) return;
   }
   if(!nova.zatacka->nxt->nxt->nxt){
     if(vzdalenost(p,u2->pos)<MINZK && allowRet) return;
   }
  //zm�� pozici
   nova.zatacka->nxt->pos= p;
   nova.silnice->spoctiZatac(0);
  //oprav po�ad� sm�r�
   u1->setrid();
   u2->setrid();
 }
//oprav pozici v prom�nn� zvyraz
 if(nova.uzel==zvyraz.uzel || nova.silnice==zvyraz.silnice ||
    nova.silnice && nova.silnice->opac==zvyraz.silnice){
    zvyraz.pos= p;
 }
 modif=true;
}
//---------------------------------------------------------------------------
void TForm1::UpdateXY()
{
static char *s0="X:       ", *s1="Y:       ";

 itoa(calxm(mouseX),s0+3,10);
 itoa(calym(mouseY),s1+3,10);
 StatusBar1->Panels->Items[0]->Text= s0;
 StatusBar1->Panels->Items[1]->Text= s1;
}
//---------------------------------------------------------------------------
void TForm1::MouseZvyrazni(int x,int y)
{
int a,b,c,o,d,d1;
int X,Y;
Tuzel* uzel,*u;
Tzatacka* z,*z1,*zm;
Tsilnice* s,*c1;
Tpos pos1,pos2,posm;

int SELS=max(int(3*SirkaPruhu),650/lupa), SELZ=sqr(max(SELS,MINZ)),
    dkr2=650/lupa, dkr1= sim ? 0:26;

 X=calxm(x); Y=calym(y);
 //na okraji mapy nezv�raz�uj
 if(x>=DPOSUN && x<=mapaWidth-DPOSUN && y>=DPOSUN && y<=mapaHeight-DPOSUN){
   d1=0x7fffffff;
   fors(u,uzly){
     if(u->typ==PARK){
       d=sqr(max( abs(X- u->pos.x), abs(Y- u->pos.y) )); //�tverec
     }else{
       d=(sqr(X - u->pos.x) + sqr(Y - u->pos.y)); //kruh
     }
     if( d<d1 && d<sqr( max(u->R+dkr1,dkr2) ) ) d1=d, uzel=u;
   }
   if(d1<0x7fffffff){
     //zv�razni uzel
     if(zvyraz.uzel!=uzel){
       zvyrazni(uzel,0);
       TimerSelect->Interval=VYBRINT;
     }
     return;
   }
   fors(s,silnice){
    z=s->zatacky;
    if(z){
      pos1=z->pos;
      while((z1=z, z=z->nxt)!=0){
        pos2=z->pos;
        d=(sqr(X - pos2.x)+sqr(Y - pos2.y));
        if(d<SELZ){
          //my� je na zat��ce
           if(s->opac==zvyraz.silnice) zvyraz.silnice=s;
           if(zvyraz.silnice!=s){
             zvyrazni(0,s);
             TimerSelect->Interval= sim ? 0 : VYBRINT*2;
           }
           zvyraz.zatacka=z1;
           zvyraz.pos=pos2;
           zvyraz.jezatac=true;
           return;
        }
       //od kurzoru spus� kolmici na p��mku
        a=pos2.y-pos1.y;  b=pos1.x-pos2.x;
        c=pos2.x*pos1.y-pos1.x*pos2.y;
        o=a*a+b*b;
        if(o>0){
         x=((double)b*b*X-(double)a*c-(double)a*b*Y)/o;
         y=((double)a*a*Y-(double)b*c-(double)a*b*X)/o;
        //pata kolmice mus� b�t uvnit� �se�ky
         if(labs(a)<labs(b)?(x<pos1.x)!=(x<pos2.x):(y<pos1.y)!=(y<pos2.y)){
          //vypo�ti vzd�lenost od �se�ky
           d=(abs(X*a + Y*b + c)/sqrt(o));
           if(d<d1){
             d1=d, c1=s, zm=z1;
             posm.x=x;
             posm.y=y;
           }
         }
        }
        pos1=pos2;
      }
    }
   }
   if(d1<SELS){
      //zv�razni silnici
      if(c1->opac==zvyraz.silnice) zvyraz.silnice=c1;
      if(zvyraz.silnice!=c1){
       zvyrazni(0,c1);
       TimerSelect->Interval= sim ? 0 : VYBRINT*2;
      }
      zvyraz.zatacka=zm;
      zvyraz.jezatac=false;
      zvyraz.pos=posm;
      return;
   }
 }
//zru� zv�razn�n�
 zvyrazni(0,0);
 zvyraz.pos.x=X;
 zvyraz.pos.y=Y;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::MapaMouseDown(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y)
{
static lastX,lastY;
 if(Button==mbLeft){
   if(rightDown) return;
   leftDown=true;
 }else if(Button==mbRight){
   if(leftDown) return;
   rightDown=true;
   SetCapture(Handle);
 }
  if(ActiveControl!=TrackBar1){
    ActiveControl=TrackBar1;
    activate=1;
  }
  if(!MapaPosun1(1,X,Y)){  //posun mapy, kdy� je kurzor na okraji
   MouseZvyrazni(X,Y);
   if(Button==mbRight){ //prav� tla��tko
     if(!sim){
      if((!zvyraz.uzel || zvyraz.uzel->typ==KRIZ && zvyraz.uzel->Ds<4
         || zvyraz.uzel->typ==PARK && zvyraz.uzel->Ds<MAXDS ||
         zvyraz.uzel->typ==KONEC)){
       //za��tek vytv��en� nov� silnice
       nova=zvyraz;
       tazeni=1;
       clipCur();
      }
     }else{ //zmen�en� m���tka
       MouseZoom(X,Y,false);
     }
   }
   if(Button==mbLeft){ //lev� tla��tko
     if((zvyraz.uzel || zvyraz.silnice) && (X!=lastX || Y!=lastY)){
       if(!sim){ //p�esun uzlu nebo zat��ky
        nova=zvyraz;
        TimerMove->Interval=MOVEINT;
        tazeni=3;
        clipCur();
       }
     }else{ //zv�t�en� m���tka
       MouseZoom(X,Y,true);
     }
   }
  }
  lastX=X,lastY=Y;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::MapaMouseMove(TObject *Sender, TShiftState Shift, int X,
	int Y)
{
Tpos p;

switch(tazeni){
 case 3: //za��tek p�esunu
   p= nova.pos;
   if(sqr(X-calX(p.x))+sqr(Y-calY(p.y)) > 300){
     //je dostate�n� daleko
     TimerMoveTimer(this);
   }
 break;
 case 2: //p�esun
  p.x=calxm(X); p.y=calym(Y);
  Presun(p,true);
  prekresli();
 break;
 case 0: //zv�razn�n�
 case 1:
  taznov0();
  if(Sender) MouseZvyrazni(X,Y);
  else zvyrazni(0,0);
  taznov1();
 break;
}
mouseX=X; mouseY=Y;
MapaPosun1(tazeni ? 2:0,X,Y);
UpdateXY();
}
//---------------------------------------------------------------------------
void TForm1::MouseZoom(int X,int Y,bool zvetsi)
{
int x1,y1;

 if(!activate){
  x1=calxm(X); y1=calym(Y);
  if(zvetsi){
    if(lupa==TrackBar1->Max) return;
    lupa+=3;
    if(lupa>14) lupa+=12;
    if(lupa>55) lupa+=10;
  }else{
    if(lupa==TrackBar1->Min) return;
    if(lupa>65) lupa-=10;
    if(lupa>26) lupa-=12;
    lupa-=3;
  }
  zoom();
	 mapposunx= calX(x1)-X;
	 mapposuny= calY(y1)-Y;
  MapaPosun2();
 }
 activate=0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TimerMoveTimer(TObject *Sender)
{
Tpos p;

 TimerMove->Interval=0;
 if(tazeni==3){
   //za��tek p�esunu
   tazeni=2;
   Screen->Cursor= crPresun;
  //vytvo� novou zat��ku
   if(nova.silnice && !nova.jezatac){
     nova.silnice->getZatac();
     nova.zatacka->nxt=new Tzatacka(nova.pos,nova.zatacka->nxt);
     nova.silnice->spoctiZatac(0);
   }
   p.x=calxm(mouseX); p.y=calym(mouseY);
   Presun(p,true);
   prekresli();
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TimerPosunTimer(TObject *Sender)
{
//posun mapy
 if(tazeni==3) tazeni=0;
	MapaMouseMove(0,TShiftState(),mouseX,mouseY);
 MapaPosun2();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TrackBar1Change(TObject *Sender)
{
 if(lupa!=TrackBar1->Position){
  lupa= TrackBar1->Position;
  zoom();
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key,
    TShiftState Shift)
{
int x,y;
Tuzel *h;
Tsilnice *c,*c0,*c1;
Tzatacka *z;
Tnovainfo info;

 if(Key==VK_SHIFT) shift=true;
 if(tazeni){
   //p�eru�en� ta�en�
   if(Key==VK_ESCAPE){
     if(tazeni==2){
       Presun(nova.pos,false);
       if(nova.silnice) nova.silnice->zruszatac();
       Screen->Cursor= crDefault;
       prekresli();
     }
     taznov0();
     tazeni=0;
   }
 }else{

  if(sim){ //simulace
  //zru�it sledov�n� auta
   if(Key==VK_ESCAPE) zrusSelauto();
  //inverzn� barvy
   if(Key==VK_INSERT) Inverznbarvy1Click(0);

  }else{ //editace
   info=zvyraz;
   c=info.silnice;
   if(Key==VK_BACK){
    zrusVyber2();
   //smaz�n� zat��ky
    if(c && info.jezatac){
      c->getZatac();
      if(c->opac->uzel!=c->uzel || lenlist(c->zatacky)>4){
        z= info.zatacka->nxt;
        info.zatacka->nxt= z->nxt;
        delete z;
        zmena();
      }
    }else
   //smaz�n� p�echodu pro chodce
    if((h=info.uzel)!=0){
      if(h->typ!=PRECHOD) throw Exception("Nelze smazat k�i�ovatku");
      if(!h->naZatac())
         throw Exception("Smaz�n�m p�echodu by ze silnice vznikla smy�ka");
      zmena();
    }
   }

  //vytvo�en� p�echodu pro chodce
   if(Key==VK_INSERT){
    zrusVyber2();
    if(!c) throw Exception("Um�st�te ukazatel my�i nad silnici,"
        " kde chcete vytvo�it p�echod pro chodce, a pak stiskn�te Insert");
    c->getZatac();
    if(info.jezatac){ //zni� zat��ku
      z=info.zatacka->nxt;
      info.zatacka->nxt= z->nxt;
      delete z;
    }
    h=new Tprechod;
    h->pos=info.pos;
   //vytvo� silnice
    c1= h->s[1]= new Tsilnice(h);
    c1->pruhu0= c->opac->pruhu0;
    c1->rychlost= c->opac->rychlost;
    c0= h->s[0]= new Tsilnice(h);
    c0->pruhu0= c->pruhu0;
    c0->rychlost= c->rychlost;
   //rozd�l seznam zat��ek a vytvo� dv� nov� zat��ky na pozici my�i
   //    c===c1 (h) c0===c->opac
    c0->zatacky= new Tzatacka(info.pos,info.zatacka->nxt);
    info.zatacka->nxt= new Tzatacka(info.pos,0);
    propoj(c0,c->opac);
    propoj(c1,c);
    zmena();
   }

  //smaz�n� silnice
   if(Key==VK_DELETE){
    if(!c && vybran==1 && !selsiln->nxt){
      c=selsiln->c;
    }
    zrusVyber2();
    if(!c) throw Exception("Um�st�te ukazatel my�i nad silnici,"
       " kterou chcete odstranit, a pak stiskn�te Delete");
    c->opac->uzel->ubersmer(c->opac->smer);
    c->uzel->ubersmer(c->smer);
    zmena();
   }
  }

 //kurzory
  x=y=0;
  if(Key==VK_NUMPAD1) x--,y++;
  if(Key==VK_NUMPAD2 || Key==VK_DOWN) y++;
  if(Key==VK_NUMPAD3) x++,y++;
  if(Key==VK_NUMPAD4 || Key==VK_LEFT) x--;
  if(Key==VK_NUMPAD6 || Key==VK_RIGHT) x++;
  if(Key==VK_NUMPAD7) x--,y--;
  if(Key==VK_NUMPAD8 || Key==VK_UP) y--;
  if(Key==VK_NUMPAD9) x++,y--;
  if(x || y){
    if(Shift.Contains(ssShift)){
     if(Shift.Contains(ssCtrl)){
    //CTRL+SHIFT=posun pozad�
      xpozadi+= short(x*(100/lupa+1));
      ypozadi+= short(y*(100/lupa+1));
     }else{
    //SHIFT=posun m��e
      xmriz+= short(x*(200/lupa+1));
      ymriz+= short(y*(200/lupa+1));
      xmriz%= Dxmriz;
      ymriz%= Dymriz;
     }
     modif=true;
     prekresli();
    }else{
     //posun mapy
     //CTRL=pomalu, ALT=o celou obrazovku
      if(Shift.Contains(ssCtrl)){
        x*=5; y*=5;
      }else{
        x*= mapaWidth;
        y*= mapaHeight;
        if(!Shift.Contains(ssAlt)){
         x= x*RychPosun/200;
         y= y*RychPosun/200;
        }
      }
      mapposunx=x; mapposuny=y;
      MapaPosun2();
      MapaMouseMove(0,TShiftState(),mouseX,mouseY);
    }
  }

 //vycentrovat
  if(Key==VK_NUMPAD5){
   Vycentrovat1Click(0);
  }
 //na vybran� uzel
  if(Key==VK_SPACE){
   Navybranou1Click(0);
  }
 //lupa
  if(Key==VK_PRIOR){ //PageUp
    ButtonZoomInClick(this);
    MapaMouseMove(0,TShiftState(),mouseX,mouseY);
  }
  if(Key==VK_NEXT){ //PageDown
    ButtonZoomOutClick(this);
    MapaMouseMove(0,TShiftState(),mouseX,mouseY);
  }
 //rychlost simulace
  if(Key==VK_SUBTRACT){
    Speed->Position--;
  }
  if(Key==VK_ADD){
    Speed->Position++;
  }
 //Na dal�� vstup nebo parkovi�t�
  if(Shift.Contains(ssCtrl)){
   if(Key=='L') Dalvstup1Click(0);
   if(Key=='P') Dalparkovit1Click(0);
  }
 }
}
//---------------------------------------------------------------------------
void TForm1::zamerit(int x,int y)
{
int XMAX,YMAX;

 XMAX= 32000-XS*100/lupa;
 YMAX= 32000-YS*100/lupa;
 amin(x,-XMAX);
 amax(x,XMAX);
 amin(y,-YMAX);
 amax(y,YMAX);
 ScrollBarX->Position= xposun= x;
 ScrollBarY->Position= yposun= y;
 UpdateXY();
 prekresli();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
//toto kliknut� nezm�n� lupu
//p�i programov�m vol�n� SetFocus bylo activate -1 a zde se vr�t� na 0
 activate++;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
//mapa pokr�v� cel� okno krom� tla��tek a StatusBaru
 Mapa->Left= 0;
 Mapa->Top= Panel1->Height;
 Mapa->Width= mapaWidth= ClientWidth - ScrollBarY->Width;
 Mapa->Height= mapaHeight= ClientHeight - Mapa->Top -
    StatusBar1->Height - ScrollBarX->Height;
//posuvn�ky um�sti na okraje Mapy
 ScrollBarY->Height= mapaHeight;
 ScrollBarY->Top= Mapa->Top;
 ScrollBarY->Left= mapaWidth;
 ScrollBarX->Width= mapaWidth;
 ScrollBarX->Left= Mapa->Left;
 ScrollBarX->Top= Mapa->Top +mapaHeight;
 Panel2->Left= ScrollBarY->Left;
 Panel2->Top= ScrollBarX->Top;
 Panel2->Width= ScrollBarY->Width;
 Panel2->Height= ScrollBarX->Height;
//vytvo� bitmapu s rozm�ry Mapy
 delete bitmapa;      
 bitmapa=new Graphics::TBitmap;
 if(bitmapa){
  bitmapa->Height=mapaHeight;
  bitmapa->Width=mapaWidth;
 }
//st�ed Mapy
	XS=mapaWidth/2;
 YS=mapaHeight/2;
 zamerit(xposun,yposun);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::RestrictSize(TMessage& Msg)
{
 ((POINT far *)Msg.LParam)[3].x = 400;
 ((POINT far *)Msg.LParam)[3].y = 400;
 TForm::Dispatch(&Msg);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
 char fn[256];

 int l=GetModuleFileName(0,fn,sizeof(fn)-12);
 while(l>=0 && fn[l]!='\\') l--;
 l++;
 strcpy(fn+l, "Auta.hlp");
 Application->HelpFile = fn;

 Screen->Cursors[crMovLeft]=LoadCursor((void *)HInstance,"Crleft");
 Screen->Cursors[crMovRight]=LoadCursor((void *)HInstance,"Crright");
 Screen->Cursors[crMovUp]=LoadCursor((void *)HInstance,"Crup");
 Screen->Cursors[crMovDown]=LoadCursor((void *)HInstance,"Crdown");
 Screen->Cursors[crMovLU]=LoadCursor((void *)HInstance,"Crlu");
 Screen->Cursors[crMovLD]=LoadCursor((void *)HInstance,"Crld");
 Screen->Cursors[crMovRU]=LoadCursor((void *)HInstance,"Crru");
 Screen->Cursors[crMovRD]=LoadCursor((void *)HInstance,"Crrd");
 Screen->Cursors[crPresun]=LoadCursor((void *)HInstance,"Crmove");
//maximalizuj, ale nech levou ��st volnou na dal�� okna
 mapcanvas= Mapa->Canvas;
 Left=178;
 Top=-1;
 Width= Screen->Width - Left +3;
 Height= Screen->Height - 24;
 smazMesto();
//parametr m��e b�t soubor
 if(_argc>1){
   filename=_argv[1];
   openMesto();
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormMouseMove(TObject *Sender, TShiftState Shift, int X,
	int Y)
{
 Mapa->Cursor=crArrow;
//prav� tla��tko
 if(rightDown){
  X-=Mapa->Left; Y-=Mapa->Top;
  mouseX=X; mouseY=Y;
  taznov0();
  MouseZvyrazni(X,Y);
  taznov1();
  MapaPosun1(tazeni ? 2:0,X,Y);
  UpdateXY();
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormMouseUp(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y)
{
ClipCursor(0);
if(Button==mbRight && rightDown){
 ReleaseCapture();
 rightDown=false;
 X-=Mapa->Left; Y-=Mapa->Top;
 MapaPosun1(0,X,Y);
 Screen->Cursor=crDefault;
 TimerPosun->Interval=0;
 if(tazeni==1){
  //vytvo�en� nov� silnice
  taznov0();
  MouseZvyrazni(X,Y);
  taznov1();
  tazeni=0;
  nova2=zvyraz;
  if(vzdalenost(nova.pos,nova2.pos)*lupa<600){
     MouseZoom(X,Y,false);  //zmen�en�
  }else{
    if( (!nova2.uzel || nova2.uzel!=nova.uzel) &&
        vzdalenost(nova.pos,nova2.pos)>MINK ){

     if(nova2.silnice && (nova2.silnice==nova.silnice ||
        nova2.silnice->opac==nova.silnice) )
         throw Exception("Oba konce le�� na stejn� silnici");
     if(nova2.uzel)
     switch(nova2.uzel->typ){
      case VSTUP:
       throw Exception("Nelze p�ipojit silnici ke vstupu do m�sta");
      case PARK:
       if(nova2.uzel->Ds >=MAXDS){
         throw Exception("U� nelze p�ipojit dal�� silnici k parkovi�ti");
       }
      break;
      case KRIZ:
       if(nova2.uzel->Ds>=4){
         throw Exception("K�i�ovatka u� m� stupe� 4");
       }
      break;
      case PRECHOD:
       throw Exception("Nelze p�ipojit silnici k p�echodu pro chodce");
     }
    //zobraz PopupMenu
     if(!nova2.uzel && !nova2.silnice){
       popup(nova2.pos);
       pocPopup=0;
       return;
     }
     if(!nova.uzel && !nova.silnice){
       popup(nova.pos);
       pocPopup=1;
       return;
     }
     novaSilnice();
     TimerSelect->Interval=0;
    }
  }
 }
}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::MapaMouseUp(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y)
{
 ClipCursor(0);
 if(Button==mbRight && rightDown) FormMouseUp(Sender,Button,Shift,X,Y);
 if(Button==mbLeft && leftDown){
   leftDown=false;
   if(tazeni==2){
     //konec p�esunu
     if(zvyraz.silnice) zvyraz.silnice->zruszatac();
     UpdateForms();
     okraje();
   }else{
     //vybr�n�
     Select();
   }
   tazeni=0;
   MapaPosun1(0,X,Y);
   Screen->Cursor=crDefault;
   TimerPosun->Interval=0;
 }
 activate=0;
}
//---------------------------------------------------------------------------
void TForm1::zoom()
{
 amin(lupa, TrackBar1->Min);
 amax(lupa, TrackBar1->Max);
 EditZoom->Text=IntToStr(lupa);
 TrackBar1->Position= lupa;
 ScrollBarX->LargeChange= TScrollBarInc(min(mapaWidth*100/lupa,32767));
 ScrollBarY->LargeChange= TScrollBarInc(min(mapaHeight*100/lupa,32767));
 SirkaPruhu= max(DPRUHU,MinDPRUHU*100.0/lupa);
 prekresli();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::EditZoomChange(TObject *Sender)
{
 int i;
 try{
  i=StrToInt(EditZoom->Text);
 }
 catch(...){
  i=0;
 }
 if(i) lupa=i;
 zoom();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonZoomInClick(TObject *Sender)
{
 lupa++;
 if(lupa>15) lupa+=4;
 if(lupa>50) lupa+=5;
 zoom();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonZoomOutClick(TObject *Sender)
{
 lupa--;
 if(lupa>15) lupa-=4;
 if(lupa>50) lupa-=5;
 zoom();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::EditKeyPress(TObject *Sender, char &Key)
{
 if(Key==13) ActiveControl=TrackBar1;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::EditClick(TObject *Sender)
{
 ((TEdit*)Sender)->SelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCloseQuery(TObject *Sender, bool &CanClose)
{
 CanClose= savemodif();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Konec1Click(TObject *Sender)
{
 Application->Terminate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Monosti1Click(TObject *Sender)
{
short mx,my,px,py;
AnsiString s;

 FormMoznosti->UpDown2->Min= FormKriz->DelOdboc->Min;
 FormMoznosti->UpDown2->Max= FormKriz->DelOdboc->Max;
 FormMoznosti->UpDown3->Min= FormPark->Park->Min;
 FormMoznosti->UpDown3->Max= FormPark->Park->Max;
 FormMoznosti->UpDown4->Min= FormVstup->Prijizdi->Min;
 FormMoznosti->UpDown4->Max= FormVstup->Prijizdi->Max;
 FormMoznosti->UpDown1->Min= FormPrechod->Auta->Min;
 FormMoznosti->UpDown1->Max= FormPrechod->Auta->Max;
 FormMoznosti->UpDown13->Min= FormPrechod->Chodci->Min;
 FormMoznosti->UpDown13->Max= FormPrechod->Chodci->Max;
 FormMoznosti->UpDown1->Position= auta0;
 FormMoznosti->UpDown2->Position= delodboc0;
 FormMoznosti->UpDown3->Position= Mpark0;
 FormMoznosti->UpDown4->Position= prijizdi0;
 FormMoznosti->UpDown5->Position= short(VYBRINT/10);
 FormMoznosti->UpDown6->Position= short(DPOSUN);
 FormMoznosti->UpDown7->Position= short(RychPosun);
 FormMoznosti->UpDown8->Position= DKROK;
 FormMoznosti->UpDown9->Position= DQUICK;
 FormMoznosti->UpDown10->Position= my= Dymriz;
 FormMoznosti->UpDown11->Position= mx= Dxmriz;
 FormMoznosti->UpDown12->Position= Nvykres;
 FormMoznosti->UpDown13->Position= chodci0;
 FormMoznosti->UpDown14->Position= interval0;
 FormMoznosti->UpDown15->Position= px=Dxpozadi;
 FormMoznosti->UpDown16->Position= py=Dypozadi;
 FormMoznosti->Edit17->Text= s= bmpFile;
 if(FormMoznosti->ShowModal()==mrOk){
   auta0= FormMoznosti->UpDown1->Position;
   delodboc0= FormMoznosti->UpDown2->Position;
   Mpark0= FormMoznosti->UpDown3->Position;
   prijizdi0= FormMoznosti->UpDown4->Position;
   VYBRINT= 10*FormMoznosti->UpDown5->Position;
   DPOSUN= FormMoznosti->UpDown6->Position;
   RychPosun= FormMoznosti->UpDown7->Position;
   DKROK= FormMoznosti->UpDown8->Position;
   DQUICK= FormMoznosti->UpDown9->Position;
   Dymriz= FormMoznosti->UpDown10->Position;
   Dxmriz= FormMoznosti->UpDown11->Position;
   Nvykres= FormMoznosti->UpDown12->Position;
   chodci0= FormMoznosti->UpDown13->Position;
   interval0= FormMoznosti->UpDown14->Position;
   Dxpozadi= FormMoznosti->UpDown15->Position;
   Dypozadi= FormMoznosti->UpDown16->Position;
   bmpFile= FormMoznosti->Edit17->Text;
   if(mx!=Dxmriz || my!=Dymriz ||
      px!=Dxpozadi || py!=Dypozadi || s!=bmpFile){
     if(s!=bmpFile){
       delete pozadi;
       pozadi=new Graphics::TBitmap;
       pozadi->LoadFromFile(bmpFile);
     }
     modif=true;
     prekresli();
   }
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Vycentrovat1Click(TObject *Sender)
{
Tuzel *u;
Tsilnice *c;
Tzatacka *z;
int xr,yr;

//posu� v�echny sou�adnice
 xr=-(mapLeft+mapRight)/2;
 yr=-(mapTop+mapBottom)/2;
 fors(u,uzly){
   u->pos.x+= xr;
   u->pos.y+= yr;
 }
 fors(c,silnice){
  fors(z,c->zatacky){
    z->pos.x+= xr;
    z->pos.y+= yr;
  }
 }
 xmriz+= (short)xr;
 ymriz+= (short)yr;
//p�esu� se na st�ed
 okraje();
 zamerit(0,0);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Statistika1Click(TObject *Sender)
{
 FormStatis->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::vyberUzel(Tuzel *u)
{
bool b;

 zvyrazni(u,0);
 zamerit(u->pos.x, u->pos.y);
 b=shift;
 shift=false;
 Select();
 shift=b;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Dalvstup1Click(TObject *Sender)
{
Tuzel *u;

//Na dal�� vstup
 if(vstupy){
  u=vstupy;
  if(vybran==2){
    if(shift) u=prevlist(vstupy,selvstup);
    else u=nextlist(vstupy,selvstup);
  }
  vyberUzel(u);
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Dalparkovit1Click(TObject *Sender)
{
Tuzel *u;

//Na dal�� parkovi�t�
 if(parkoviste){
  u=parkoviste;
  if(vybran==3){
    if(shift) u=prevlist(parkoviste,selpark);
    else u=nextlist(parkoviste,selpark);
  }
  vyberUzel(u);
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Navybranou1Click(TObject *Sender)
{
//Zam��it vybranou
 if(vybran>1){
   if(xposun!=seluzel->pos.x || yposun!=seluzel->pos.y){
     zamerit(seluzel->pos.x,seluzel->pos.y);
   }else{
     lupa= lupa<130 ? TrackBar1->Max : 10;
     zoom();
   }
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::M1Click(TObject *Sender)
{
//M��
 ((TMenuItem*) Sender)->Checked= !((TMenuItem*) Sender)->Checked;
 prekresli();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::N51Click(TObject *Sender)
{
 lupa= ((TMenuItem *)Sender)->Tag;
 zoom();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TrackBar1KeyUp(TObject *Sender, WORD &Key,
	TShiftState Shift)
{
 if(Key==VK_SHIFT) shift=false;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Inverznbarvy1Click(TObject *Sender)
{
Tfronta *f;
Tauto *a;
int i;

 Inverznbarvy1->Checked= !Inverznbarvy1->Checked;
//invertuj barvu silnice a barvy v�ech aut
	clSilnice1=TColor(clSilnice1 ^ 0xffffff);
 if(sim){
   for(f=Afronty, i=Dfronty; i>0; f++,i--)
     for(a=f->auta; a; a=a->nxt)
       a->barva^=0xffffff;
   fors(a,kos) a->barva^=0xffffff;
   fors(a,odjela) a->barva^=0xffffff;
   prekresli();
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Seaditvstupy1Click(TObject *Sender)
{
Tvstup *v,*v1,*vm,**pv,**pvm;
Tpark *r,*r1,*rm,**pr,**prm;
double um;

 if(sim) throw Exception("Tato funkce je dostupn� jen v edita�n�m re�imu");
//vstupy
 //p�edpo��tej �hly vstup� od st�edu mapy
  fors(v,vstupy){
    if(v->pos.y || v->pos.x) v->u= atan2(v->pos.y,v->pos.x);
    else v->u=0;
  }
 //selection sort
  v1=0;
  while(vstupy){
   //vyber maximum
    um=-9;
    pv=&vstupy;
    fors(v,vstupy){
      if(v->u >=um){
        pvm=pv; um=v->u; vm=v;
      }
      pv= &v->nxt;
    }
   //p�eho� do seznamu v1
    *pvm= vm->nxt;
    vm->nxt= v1;
    v1= vm;
  }
  vstupy=v1;

//parkovi�t�
  fors(r,parkoviste){
    if(r->pos.y || r->pos.x) r->u= atan2(r->pos.y,r->pos.x);
    else r->u=0;
  }
  r1=0;
  while(parkoviste){
    um=-9;
    pr=&parkoviste;
    fors(r,parkoviste){
      if(r->u >=um){
        prm=pr; um=r->u; rm=r;
      }
      pr= &r->nxt;
    }
    *prm= rm->nxt;
    rm->nxt= r1;
    r1= rm;
  }
  parkoviste=r1;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ScrollBarXChange(TObject *Sender)
{
 zamerit(ScrollBarX->Position,yposun);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ScrollBarYChange(TObject *Sender)
{
 zamerit(xposun,ScrollBarY->Position);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonNewMouseMove(TObject *Sender,
	TShiftState Shift, int X, int Y)
{
 Mapa->Cursor= crArrow;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Oprogramu1Click(TObject *Sender)
{
 FormAbout->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Obsah1Click(TObject *Sender)
{
 Application->HelpCommand(HELP_FINDER,0);
}
//---------------------------------------------------------------------------