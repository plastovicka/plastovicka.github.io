//---------------------------------------------------------------------------
#ifndef semaf3H
#define semaf3H
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFormSemaf3 : public TForm
{
__published:	// IDE-managed Components
	TLabel *Label1;
	TPanel *Panel1;
	TPaintBox *PaintBox1;
	TPaintBox *PaintBox2;
	TPaintBox *PaintBox3;
	void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall PaintBox1Paint(TObject *Sender);
	
	void __fastcall FormShow(TObject *Sender);
	void __fastcall PaintBox1MouseUp(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y);
	
	void __fastcall PaintBox1MouseDown(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y);
private:	// User declarations
public:		// User declarations
  int sel;

	virtual __fastcall TFormSemaf3(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TFormSemaf3 *FormSemaf3;
//---------------------------------------------------------------------------
#endif
