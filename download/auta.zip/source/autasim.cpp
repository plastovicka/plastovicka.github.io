/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include "autasim.h"
#include <values.h>
#include <math.h>

bool sim; //0=editace, 1=simulace
int cas; //�as od spu�t�n� simulace (1/5 sec)

Tuzel* uzly;
Tkriz* krizovatky;
Tprechod* prechody;
Tkonec* konce;
Tvstup* vstupy;
Tpark* parkoviste;
Tsilnice* silnice;

Tfronta *Afronty;
int Dfronty;
char *Atrasy;
int Dtrasy;
int *Aprijizdi;
int Sprijizdi;

Tauto *kos=0;
Tauto *odjela=0; //auta, co se maj� smazat z obrazovky a d�t do ko�e

int Dcile;    //po�et c�l�
int Daut,     //aut ve m�st� (bez parkovi��)
    Nvyjelo,  //kolik vyjelo z m�sta od spu�t�n� simulace
    Nprijelo; //kolik p�ijelo do m�sta od spu�t�n� simulace

//vzdal2-krok>vzdal1 ,krok+VZDAL1<DPREDN
int krok=3;   //rychlost (metr� za �asovou jednotku)
const int VZDAL2=9; //vzd�lenost mezi jedouc�mi auty
const int VZDAL1=4; //mezi stoj�c�mi auty (v�etn� d�lky auta)
const int DPREDN=30; //vzd�lenost auta, kter�mu se d� p�ednost

//---------------------------------------------------------------------------
//1=zelen�, 0=�erven�
unsigned semafory[]={
07777, //0:  v�ude zelen�
//stupe� 3
0103,  //1:  0-2
0031,  //2:  1-0
0310,  //3:  2-1
//stupe� 4
00303, //4:  0-2
03030, //5:  1-3
01007, //6:  0-3
00071, //7:  1-0
00710, //8:  2-1
07100, //9:  3-2
04141,//10:  0-1,2-3
01414,//11:  1-2,3-0
01111 //12:  v�e vpravo
};
//---------------------------------------------------------------------------
//sm�r:  ��sluje od 0 proti sm�ru hodinov�ch ru�i�ek
//odboc: 1=vpravo, 2=rovn�, 3=vlevo  (stupe� 4)
//       1=vpravo, 2=vlevo           (stupe� 3)

//prednost[typ k�i�ovatky][v�ceurov�ov�][3*sm�r+odbo�-1]
unsigned prednost[][2][12]={
//stupe� 3:
//0:  prav� ruka
{{0000,0030,0, 0000,0300,0, 0000,0003,0, 0,0,0},
 {0000,0010,0, 0000,0100,0, 0000,0001,0, 0,0,0}},
//1:  hlavn� 0-2
{{0000,0000,0, 0002,0302,0, 0000,0003,0, 0,0,0},
 {0000,0200,0, 0002,0100,0, 0000,0000,0, 0,0,0}},
//2:  hlavn� 1-0
{{0000,0030,0, 0000,0000,0, 0020,0023,0, 0,0,0},
 {0000,0000,0, 0000,0002,0, 0020,0001,0, 0,0,0}},
//3:  hlavn� 2-1
{{0200,0230,0, 0000,0300,0, 0000,0000,0, 0,0,0},
 {0200,0010,0, 0000,0000,0, 0000,0020,0, 0,0,0}},
//stupe� 4:
//4:  hlavn� 0-2
{{00000,00000,00300, 00002,00706,03606, 00000,00000,00003, 00200,00607,00636},
 {02400,00000,02070, 06002,00000,00200, 00024,00000,07020, 00260,00000,00002}},
//5:  hlavn� 1-3
{{02000,06070,06360, 00000,00000,03000, 00020,07060,06063, 00000,00000,00030},
 {02600,00000,00020, 04002,00000,00702, 00026,00000,02000, 00240,00000,00207}},
//6:  hlavn� 0-3
{{00000,00000,00000, 04002,04706,03606, 00004,07004,06003, 00000,00007,00006},
 {06000,06000,00000, 04002,04706,05602, 00004,01000,06003, 00000,00000,00000}},
//7:  hlavn� 1-0
{{00000,00070,00060, 00000,00000,00000, 00024,07064,06063, 00040,00047,00036},
 {00000,00000,00000, 00006,00006,00000, 00024,07064,06025, 00040,00001,00036}},
//8:  hlavn� 2-1
{{00400,00470,00360, 00000,00700,00600, 00000,00000,00000, 00240,00647,00636},
 {00400,00010,00360, 00000,00000,00000, 00060,00060,00000, 00240,00647,00256}},
//9:  hlavn� 3-2
{{02400,06470,06360, 04000,04700,03600, 00000,07000,06000, 00000,00000,00000},
 {02400,06470,02560, 04000,00100,03600, 00000,00000,00000, 00600,00600,00000}},
//10: prav� ruka
{{00000,00070,00360, 00000,00700,03600, 00000,07000,06003, 00000,00007,00036},
 {02400,00000,00020, 04002,00000,00200, 00024,00000,02000, 00240,00000,00002}},
};
//---------------------------------------------------------------------------
Tauto *Odpoj(Tfronta *f)
{
Tauto *a;

//odeber prvn� auto z fronty
 a=f->auta;
 f->auta= a->nxt;
 if(f->auta){
   f->auta->d+= a->d;
 }else{
   f->dk+= a->d;
   f->autok= &f->auta;
 }
 return a;
}
//---------------------------------------------------------------------------
void Pripoj(Tauto *a,Tfronta *fk,bool byl)
{
int d;

 if(a){
 //p�idej auto na konec fronty
  a->nxt=0;
  if(byl){
    *fk->autok= a;
    fk->autok= &a->nxt;
    d=min(krok - a->d, fk->dk - VZDAL2);
    a->d= fk->dk - d;
    fk->dk= d; //m��e b�t <0
  }else{
    fk->auton= a;
  }
 }
}
//---------------------------------------------------------------------------
Tauto *noveAuto(int cil)
{
Tauto *a;

 if(kos){
   a=kos;
   kos=a->nxt;
 }else{
   a=new Tauto;
 }
 if(a){
  Daut++;
  a->d=0;
  a->X=-1;
  a->cil=cil;
 }
 return a;
}
//---------------------------------------------------------------------------
void smazAuto(Tauto *a)
{
 Daut--;
 if(a==selauto) selauto=0;
 if(a->X>=0){
   a->nxt=odjela;
   odjela=a;
 }
 else{
   a->nxt=kos;
   kos=a;
 }
}
//---------------------------------------------------------------------------
void popojed(Tfronta *f)
{
int d,i;
Tauto *a=f->auta,
      *al=f->autol,
      *a0;

 d=0;
 while(a){
   d=krok-d;
//stoj�
   while(a && a->d<=VZDAL1) a=a->nxt;
//brzd�
   while(a && (i= a->d -VZDAL1) >0){
     if(a==al){ f->autol= al= al->nxt; }
     if(d<=i){ a->d-=d; a=a->nxt; d=0; break; }
     d-=i;
     a->d= VZDAL1;
     a=a->nxt;
   }
   d=krok-d;
//jede
   a0=a;
   while(a!=al && a->d >=VZDAL2) a=a->nxt;
   if(a==al){
     f->autol= a0;
     break; //se zbytkem fronty se nic d�lat nemus�
   }
//rozj�d� se
   while(a && (i= VZDAL2- a->d) >0){
     if(d<=i){ a->d+=d; a=a->nxt; d=0; break; }
     d-=i;
     a->d= VZDAL2;
     a=a->nxt;
   }
 }
 f->dk+=d;
//p�ipoj na konec nov� auto
 if(f->auton){
   Pripoj(f->auton,f,true);
   f->auton=0;
 }
}
//---------------------------------------------------------------------------
void kroksim()
{
Tkriz *k;
Tprechod *h;
Tvstup *v;
Tpark *r;
Tpruhy *p;
Tsilnice *ck,*c;
Tfronta *f,*fk;
Tauto *a;
int i,j,q,Ds,Dp,kam,odboc,cil,mask;

 cas++;

 fors(v,vstupy){
 //v�jezd z m�sta
  c=v->s[0];
  krok= c->rychlost;
  f=c->fronty;
  for(i=c->pruhu0; i>0; i--,f++){
    if((a=f->auta)!=0 && a->d < 8){
      smazAuto(Odpoj(f));
      ///Nvyjelo++;
      v->vyjelo++;
    }
    popojed(f);
  }
 //p��jezd nov�ho auta
  if((v->Iprojede--)<0){
   //vyber n�hodn� c�l
    q=random(Sprijizdi);
    cil=-1;
    do{
      q-= Aprijizdi[++cil];
    }while(q>=0);
    if(cil!= v->tag){
    //mus� existovat cesta do c�le
     ck=c->opac;
     if(v->trasa[cil]!=9){
     //najdi voln� pruh
      f=ck->fronty;
      for(i=ck->pruhu0; i>0; i--,f++){
       if(!f->auton && f->dk>=VZDAL2){
         Nprijelo++;
         v->prijelo++;
         Pripoj(noveAuto(cil),f, ck->t < c->t );
        //za jak dlouho p�ijede dal�� auto
         v->Iprojede+= random(600/v->prijizdi);
         break;
       }
      }
     }
    }
  }
 }

 fors(r,parkoviste){
 //p��jezd na parkovi�t�
  for(j=0; j<r->Ds; j++){
    c=r->s[j];
    krok= c->rychlost;
    f=c->fronty;
    for(i=c->pruhu0; i>0; i--,f++){
      if((a=f->auta)!=0 && a->d < 7 && r->parkaut < r->Mpark){
        smazAuto(Odpoj(f));
        r->parkaut++;
        r->prijelo++;
      }
      popojed(f);
    }
  }
 //v�jezd z parkovi�t�
  if((r->Iprojede--)<0 || r->Mpark == r->parkaut){
   //vyber n�hodn� c�l
    q=random(Sprijizdi);
    cil=-1;
    do{
      q-= Aprijizdi[++cil];
    }while(q>=0);
    if(cil!= r->tag){
    //ur�i, na kterou stranu vyjet z parkovi�t�
     i= r->trasa[cil];
    //mus� existovat cesta do c�le
     if(i!=9){
      ck= r->s[i]->opac;
     //najdi voln� pruh
      f=ck->fronty;
      for(i=ck->pruhu0; i>0; i--,f++){
       if(!f->auton && f->dk>=VZDAL2){
        //vytvo� nov� auto
         r->parkaut--;
         ///r->vyjelo++;
         Pripoj(noveAuto(cil),f, ck->t < r->t);
        //za jak dlouho vyjede dal�� auto
         r->Iprojede+=random(444* r->Mpark/(r->parkaut+1)/r->prijizdi);
         break;
       }
      }
     }
    }
  }
 }

 fors(k,krizovatky){
   Ds=k->Ds;
   for( j=0, mask= ~7;   j<Ds;   j++, mask<<=3 ){
     p=k->s[j];
     if(p->pruhu0){ //nen� jednosm�rka
      k->jeauto&= mask; //vynuluj sm�r j
      krok= p->rychlost;

     //fronty p�ed k�i�ovatkou
      f= p->fronty + p->pruhu0;
      for(Dp=p->pruhu1; Dp>0; Dp--, f++){
       if((a=f->auta)!=0 && a->d <= DPREDN){
        //ozna�, �e p�ij�d� auto
         k->jeauto|= 1 << a->smer;
        //nem� �ervenou nebo ned�v� nikomu p�ednost
         if(a->d < krok+VZDAL1 && (
           k->jesemaf ? k->volno & (1 << a->smer) :
           !(prednost[k->hlavni][k->viceurovn][a->smer] & k->jeauto) )
           ){
         //rozhodnut� o sm�ru j�zdy
           kam= p->trasa[a->cil];
           #ifdef DEBUG
           if(kam>= k->Ds || kam<0)
             throw Exception("Chybn� ur�en� trasa pro auto");
           #endif
           ck= k->s[kam]->opac;
          //najdi voln� m�sto za k�i�ovatkou
           fk= ck->fronty;
           for(i=ck->pruhu0; i>0; i--,fk++){
             if(!fk->auton &&  fk->dk >= VZDAL2-a->d){
             //proje� p�es k�i�ovatku
               Pripoj(Odpoj(f),fk, ck->t < p->t);
               k->projelo++;
               break;
             }
           }
         }
       }
       popojed(f);
      }//for

     //fronty na silnici (p�ed v�tven�m)
      f=p->fronty;
      for(i=p->pruhu0; i>0; i--,f++){
       if((a=f->auta)!=0 && a->d < krok+VZDAL1){
        //rozhodnut� o sm�ru j�zdy
         fk= p->fronty + p->pruhu0;
         odboc= p->trasa[a->cil]-j;
         if(odboc<=0) odboc+=Ds;
         #ifdef DEBUG
         if(odboc>=Ds) throw Exception("Chybn� ur�en� trasa pro auto");
         #endif
         if(odboc>1){ fk+= p->pruhu[1]- p->rspolec;
           if(odboc>2) fk+= p->pruhu[2]- p->lspolec;
         }
         a->smer= j*3+odboc-1;
        //za�a� se do voln�ho pruhu
         for(Dp=p->pruhu[odboc]; Dp>0; Dp--,fk++){
           if(fk->dk >= VZDAL2- a->d){
           //proje� p�es v�tven�
             Pripoj(Odpoj(f),fk,true);
             break;
           }
         }
       }
       popojed(f);
      }//for
     }
   }
   if(k->jesemaf && k->caszmen<=cas && k->stav){
   //p�epnut� semafor�
     k->stav= k->stav->nxt;
     if(!k->stav) k->stav= k->semaf;
     k->volno= semafory[k->stav->id];
     k->caszmen+= k->stav->interval*5;
   }
 }

 fors(h,prechody){
   for(j=0; j<2; j++){
     c=h->s[j];
     if(c->pruhu0){ //nen� jednosm�rka
      krok= c->rychlost;
      f= c->fronty;
      for(i=c->pruhu0; i>0; i--,f++){
      //p�ij�d� auto a nem� �ervenou
       if((a=f->auta)!=0 && a->d < krok+VZDAL1 &&
           (!h->jesemaf || h->volno)){
        //najdi voln� m�sto
         ck= h->s[1-j]->opac;
         fk= ck->fronty;
         for(i=ck->pruhu0; i>0; i--,fk++){
           if(!fk->auton &&  fk->dk >= VZDAL2- a->d){
           //proje� p�es p�echod
             Pripoj(Odpoj(f),fk, ck->t < c->t);
             h->projelo++;
             break;
           }
         }
       }
       popojed(f);
      }//for
     }
   }
   if(h->jesemaf && h->caszmen<=cas){
   //p�epnut� semafor�
     h->volno^= ~0;
     if(h->volno){
       h->caszmen+= (random(h->tlacitko*2) + h->auta)*5;
     }else{
       h->caszmen+= h->chodci*5;
     }
   }
 }
}
//---------------------------------------------------------------------------
void startsim()
{
Tuzel *u;
Tcil *k0;
Tpark *r;
Tvstup *v;
Tkriz *k;
Tprechod *h;
Tfronta *f;
Tpruhy *p;
Tsilnice *kc,*c, *nedefin, **pc,**Pkc;
char *Utrasy;
int i,j,m,n,Dp,d,mind,cil;

 if(!sim){
  sim=true;
  cas=0;
  Daut= Nvyjelo= Nprijelo= 0;
  fors(c,silnice) c->spoctidelku();
  fors(u,uzly) u->start();
  prekresli();
  UpdateForms();

//vytvo� pole pro fronty a pro trasy

//zjisti velikost pol�
  Dfronty= Dtrasy= 0;
  fors(u,uzly){
    for(j=u->Ds-1; j>=0; j--){
      c=u->s[j];
      if(c->pruhu0){
        Dp=0;
        if(c->delodboc){
          Dp=((Tpruhy*)c)->pruhu1;
          Dtrasy+=Dcile;
        }
        Dfronty+= Dp+ c->pruhu0;
      }
    }
  }
  fors(r,parkoviste) Dtrasy+=Dcile;
  fors(v,vstupy) Dtrasy+=Dcile;
//alokuj pole
  Utrasy= Atrasy= new char[Dtrasy];
  memset(Atrasy,9,Dtrasy);
  f= Afronty= new Tfronta[Dfronty];
//do objekt� zapi� ukazatele dovnit� pol�
  fors(u,uzly){
    for(j=u->Ds-1; j>=0; j--){
      c=u->s[j];
      if(c->pruhu0){
        Dp=0;
        if(c->delodboc){
          Dp=((Tpruhy*)c)->pruhu1;
          ((Tpruhy*)c)->trasa= Utrasy;
          Utrasy+= Dcile;
        }
        c->fronty=f;
        for(m=c->pruhu0; m>0; m--,f++){ //pruhy se berou z prav� strany
          f->dk= c->delkaP(m) - c->delodboc;
        }
        for(; Dp>0; Dp--,f++){
          f->dk= c->delodboc;
        }
      }
    }
  }
  fors(r,parkoviste){
    r->trasa= Utrasy;
    Utrasy+= Dcile;
  }
  fors(v,vstupy){
    v->trasa= Utrasy;
    Utrasy+= Dcile;
  }

//Dijkstr�v algoritmus

  Aprijizdi=new int[Dcile];
  Sprijizdi=0;
  cil=0;
 //nejd��ve vstupy, pak parkovi�t�
  for(n=0; n<2; n++){
   if(n) k0=parkoviste; else k0=vstupy;
   while(k0){
    Sprijizdi+= Aprijizdi[cil]= k0->prijizdi;
    k0->tag= cil;
   //inicializace
    fors(r,parkoviste) r->t=MAXINT;
    fors(v,vstupy) v->t=MAXINT;
    fors(c,silnice) c->t=MAXINT;
   //nastav ukazatele na p�edchoz� prvek
    for(pc=&silnice; (c=*pc)!=0; pc=&c->nxt) c->pre=pc;
   //po��tek
    nedefin=0;
    for(j=0; j<k0->Ds; j++){
      c=k0->s[j];
      c->t=0;
      *c->pre= c->nxt;
      if(c->nxt) c->nxt->pre= c->pre;
      c->nxt=nedefin;
      nedefin=c;
    }

    while(nedefin){
     //najdi minim�ln� nedefinitivn� silnici
      mind=nedefin->t;
      Pkc=&nedefin;
      for(pc=&(nedefin->nxt); (c=*pc)!=0; pc=&c->nxt){
        if(c->t <mind){
          mind= c->t;
          Pkc= pc;
        }
      }
     //ozna� za definitivn�
      kc=*Pkc;
      kc->t=0;
      *Pkc= kc->nxt;
      if(silnice) silnice->pre= &kc->nxt;
      kc->nxt= silnice;
      silnice= kc;
     //oprav uzel, odkud se jede do pruh� kc
      u= kc->opac->uzel;
      m= kc->opac->smer;
      d= kc->delka + mind;
      switch(u->typ){
       case PARK:
       case VSTUP:
        if(d< u->t){
          u->t=d;
          ((Tcil*)u)->trasa[cil]=char(m);
        }
       break;
       case KRIZ:
        for(j=0; j<u->Ds; j++){
         p=(Tpruhy*)u->s[j];
         //nen� jednosm�rka a d� se odbo�it do sm�ru m
         if(j!=m && p->pruhu0 && p->pruhu[(m-j+u->Ds)%u->Ds]){
          if(d< p->t){
            p->trasa[cil]=(char) m;
            if(p->t==MAXINT){
              *p->pre= p->nxt;
              if(p->nxt) p->nxt->pre= p->pre;
              p->nxt=nedefin;
              nedefin=p;
            }
            p->t=d;
          }
         }
        }
       break;
       case PRECHOD:
        c= u->s[1-m];
        if(d< c->t && c->pruhu0){
          if(c->t==MAXINT){
            *c->pre= c->nxt;
            if(c->nxt) c->nxt->pre= c->pre;
            c->nxt=nedefin;
            nedefin=c;
          }
          c->t=d;
        }
       break;
      }
    }
    cil++;
    if(n) k0=((Tpark*)k0)->nxt; else k0=((Tvstup*)k0)->nxt;
   }
  }

 //o��sluj silnice v po�ad�, v jak�m se budou zpracov�vat
  i=0;
  fors(v,vstupy)
    v->s[0]->t= i++;
  fors(r,parkoviste){
    for(j=0; j<r->Ds; j++) r->s[j]->t= i++;
    r->t= i++;
  }
  fors(k,krizovatky){
    for(j=0; j<k->Ds; j++) k->s[j]->t= i++;
  }
  fors(h,prechody){
    h->s[0]->t= i++;
    h->s[1]->t= i++;
  }
 }
}
//---------------------------------------------------------------------------
void resetsim()
{
 if(sim){
   sim=false;
   delete[] Aprijizdi;
   delete[] Afronty; //sma�e tak� auta
   delete[] Atrasy;
   dellist(kos);
   dellist(odjela);
   prekresli();
   UpdateForms();
 }
}
//---------------------------------------------------------------------------
void Tkriz::start()
{
int i,j;
Tpruhy *p;
short n;

 projelo=0;
 jeauto=0; //kv�li jednosm�rk�m, jinak se nuluje pr�b�n�
 //odeber odbo�ky do jednosm�rek a oprav delodboc
 for(j=0; j<Ds; j++){
   p=s[j];
   if(p->delodboc > p->delka -15) p->delodboc= short(max(10,p->delka -15));
   for(i=1; i<Ds; i++){
     n= s[(j+i)%Ds]->opac->pruhu0;
     if(p->pruhu[i] >n) p->pruhu[i]=n;
   }
 }
//podle caszmen0 nastav stav a caszmen
 if(jesemaf){
  stav=semaf;
  if(semaf){
   for(i=caszmen0; i>=stav->interval; ){
     i-=stav->interval;
     stav= stav->nxt;
     if(!stav){
      stav=semaf;
      if(i==caszmen0) break;
     }
   }
   caszmen= (stav->interval-i)*5;
  //na�ti prvn� stav semaforu
   volno=semafory[stav->id];
  }else{
   volno=07777;
  }
 }
}
//---------------------------------------------------------------------------
void Tprechod::start()
{
int i;

 projelo=0;
//podle caszmen0 nastav caszmen
 if(jesemaf){
  volno=~0;
  caszmen= auta*5;
  if(chodci){
    for(i=caszmen0;;){
      i-=auta;
      if(i<0) break;
      i-=chodci;
      if(i<0){ volno=0; break; }
    }
    caszmen= -i*5;
  }
 }
}
//---------------------------------------------------------------------------
void Tcil::start()
{
 vyjelo= prijelo= 0;
 Iprojede= prijizdi>0 ? 0 : MAXINT;
}
//---------------------------------------------------------------------------
void Tpark::start()
{
 Tcil::start();
 parkaut=Mpark*3/4;
}
//---------------------------------------------------------------------------
int Tsilnice::getSmer()
{
 for(int j=0; j<uzel->Ds; j++){
   if(uzel->s[j]==this) return j;
 }
 throw Exception("getSmer: Uzel neobsahuje ukazatel na silnici");
}
//---------------------------------------------------------------------------
int Tpruhy::getPruhu1(){ // Ds>2 && pruhu0!=0
int Dp;
 Dp=pruhu[1] + pruhu[2] - rspolec;
 if(uzel->Ds>3) Dp+= pruhu[3] - lspolec;
 return Dp;
}
//---------------------------------------------------------------------------
double Tuzel::uhel(int smer)
{
Tzatacka *z1,*z2;
Tsilnice *c;

 c= s[smer];
 z1= c->zatacky;
 if(z1){
   z2=z1->nxt;
 }else{
   z1=c->opac->zatacky;
   do{
     z2=z1;
     z1=z1->nxt;
   }while(z1->nxt);
 }
 return atan2(z2->pos.y - z1->pos.y, z2->pos.x - z1->pos.x);
}
//---------------------------------------------------------------------------
Tzatacka * Tsilnice::getZatac()
{
Tzatacka *z;

 if(!zatacky){
  zatacky=opac->zatacky;
  opac->zatacky=0;
  reverselist(zatacky);
  fors(z,zatacky){ z->px= -z->px; z->py= -z->py; }
 }
 return zatacky;
}
//---------------------------------------------------------------------------
int Tsilnice::delkaP(int m)
{
Tzatacka *z;
double dm=0, X0,Y0,X2,Y2;
double dp=m*DPRUHU;

 z=getZatac();
 X0= z->pos.x + dp* z->px;
 Y0= z->pos.y + dp* z->py;
 while( (z=z->nxt)!=0 ){
   X2= z->pos.x + dp* z->px;
   Y2= z->pos.y + dp* z->py;
   dm+= sqrt(sqr(X2-X0)+sqr(Y2-Y0));
   X0=X2;
   Y0=Y2;
 }
 return dm;
}
//---------------------------------------------------------------------------
//nastav� delka a opac->delka
int Tsilnice::spoctidelku()
{
Tzatacka *z1,*z2;
int d;

 z1=zatacky;
 if(!z1) z1=opac->zatacky;
 d=0;
 do{
   z2=z1;
   z1=z1->nxt;
   d+=vzdalenost(z2->pos,z1->pos);
 }while(z1->nxt);
 return delka= opac->delka= d;
}
//---------------------------------------------------------------------------
//vypo�te px,py ve v�ech zat��k�ch, kdy� zatacky!=0
//��dn� �sek nesm� m�t nulovou d�lku
//b!=0  ->  p�i zatacky=0 nic ned�lej
void Tsilnice::spoctiZatac(int b)
{
double a1,b1,c1,a2,b2,c2,o2,D;
Tzatacka *z1,*z2,*z3;

 z1=zatacky;
 if(!z1){
   if(b) return;
   z1=opac->zatacky;
 }
 z2=z1->nxt;
 z3=z2->nxt;
//norm�lov� vektor
 a2= z2->pos.y - z1->pos.y;
 b2= z1->pos.x - z2->pos.x;
//uprav na jednotkov�
 o2= sqrt(sqr(a2)+sqr(b2));
 a2/=o2; b2/=o2;
 c2= 1 - (z2->pos.x * z1->pos.y - z1->pos.x * z2->pos.y)/o2;
 z1->px=a2;
 z1->py=b2;
 for( ; z3; z1=z2,z2=z3,z3=z3->nxt){
   a1=a2; b1=b2; c1=c2;
  //koeficienty p��mky
   a2= z3->pos.y - z2->pos.y;
   b2= z2->pos.x - z3->pos.x;
   o2= sqrt(sqr(a2)+sqr(b2));
   a2/=o2; b2/=o2;
  //posu� p��mku o 1 metr vpravo
   c2= 1 - (z3->pos.x * z2->pos.y - z2->pos.x * z3->pos.y)/o2;
  //pr�se��k obou p��mek vypo�ti Cramerov�m pravidlem
   D=a1*b2-b1*a2;
   if(fabs(D)>1e-8){
     z2->px= ((c1*b2-b1*c2)/D - z2->pos.x);
     z2->py= ((a1*c2-c1*a2)/D - z2->pos.y);
     D=sqrt(sqr(z2->px)+sqr(z2->py));
     if(D>20){ //p��li� ostr� zat��ka
       z2->px*= 20/D;
       z2->py*= 20/D;
     }
   }else{
    //determinant je 0, kdy� se zat��ka bl�� p��m�mu �hlu
     z2->px= a2;
     z2->py= b2;
   }
 }
 z2->px=a2;
 z2->py=b2;
}
//---------------------------------------------------------------------------
void Tsilnice::zruszatac()
{
Tzatacka *z,*z1,*z2;
double s,a,b,c;

//odstran� zat��ky, kter� se bl�� p��m�mu �hlu
zac:
 z1=zatacky;
 if(!z1) z1=opac->zatacky;
 z=z1->nxt;
 while(z->nxt){
  z2=z1; z1=z; z=z->nxt;
 //pou�ij Heron�v vzorec na v�po�et v��ky troj�heln�ku
  a=vzdalenost(z1->pos,z->pos);
  b=vzdalenost(z2->pos,z1->pos);
  c=vzdalenost(z2->pos,z->pos);
  s=(a+b+c)/2;
  if(sqrt(s*(s-a)*(s-b)*(s-c))/c <8){
   //sma� zat��ku
    z2->nxt=z;
    delete z1;
    prekresli();
    goto zac;
  }
 }
 spoctiZatac(0);
}
//---------------------------------------------------------------------------
//od nejv�t��ho �hlu k nejmen��mu
void Tuzel::setrid()
{
int i,j,m;
double U[MAXDS],u;
Tsilnice *w;

 if(Ds>1){
  for(j=0; j<Ds; j++) U[j]=uhel(j);
 //selection sort
  for(j=Ds-1; j>0; j--){
    u=U[m=j];
    for(i=0; i<j; i++){
      if(U[i]<u) u=U[m=i];
    }
    U[m]=U[j];
    w=s[m]; s[m]=s[j]; s[j]=w;
  }
 }
}
//---------------------------------------------------------------------------
//prohod� sm�ry j,j+1
//pak se je�t� mus� zavolat pripoj
void Tkriz::prohod(int j)
{
Tpruhy *w;
Tpruhy *p;
Tsemafory *e;
int i;
short h;
static int z[][3]={{0,0,0},{3,2,1},{2,1,3},{1,3,2}, //[typ][sm�r]
  {8,7,6},{6,9,8},{5,6,4},{7,4,7},{4,8,5},{9,5,9},{10,10,10}};
static int zs[][3]={{10,12,10},{12,11,12},{11,10,11},
   {14,13,13},{13,15,14},{15,14,16},{16,16,15}};

//proho� pruhy
 w=s[j]; s[j]=s[j+1]; s[j+1]=w;
 if(Ds>2){
 //typ hlavn� silnice
  fors(e,semaf) e->id= (e->id>9) ? zs[e->id-10][j] : z[e->id][j];
  hlavni= z[hlavni][j];
 //odbo�ky
  if(Ds==3){
    for(i=0; i<3; i++){
      p=s[i];
      h=p->pruhu[1];
      p->pruhu[1]=p->pruhu[2];
      p->pruhu[2]=h;
    }
  }else{
    p=s[j+1];
     h=p->pruhu[1];
     p->pruhu[1]=p->pruhu[2];
     p->pruhu[2]=p->pruhu[3];
     p->pruhu[3]=h;
    p=s[j];
     h=p->pruhu[3];
     p->pruhu[3]=p->pruhu[2];
     p->pruhu[2]=p->pruhu[1];
     p->pruhu[1]=h;
    p=s[(j+2)%Ds];
     h=p->pruhu[3];
     p->pruhu[3]=p->pruhu[2];
     p->pruhu[2]=h;
    p=s[(j+3)%Ds];
     h=p->pruhu[1];
     p->pruhu[1]=p->pruhu[2];
     p->pruhu[2]=h;
  }
 }
}
//---------------------------------------------------------------------------
void Tkriz::setrid()
{
int i,j,m;
double U[4],u;

 for(j=0; j<Ds; j++) U[j]=uhel(j);
 switch(Ds){
  case 2:
    if(U[0]<U[1]) prohod(0);
  break;
  case 3:
   //sta�� 3 porovn�n�
    for(i=0; i<3; i++){
      m=i&1;
      if(U[m]<U[m+1]){
        u=U[m]; U[m]=U[m+1]; U[m+1]=u;
        prohod(m);
      }
    }
  break;
  case 4:
   //bubble sort
    for(i=Ds-1; i>0; i--)
     for(j=0; j<i; j++){
      if(U[j]<U[j+1]){
       u=U[j]; U[j]=U[j+1]; U[j+1]=u;
       prohod(j);
      }
     }
  break;
 }
}
//---------------------------------------------------------------------------
void zmenaR()
{
Tuzel *u;

 fors(u,uzly) u->spoctiR();
 prekresli();
}
//---------------------------------------------------------------------------
void Tuzel::spoctiR()
{
 R=max(s[0]->pruhu0,s[0]->opac->pruhu0)*DPRUHU+2;
}

void Tpark::spoctiR()
{
 R=sqrt(Mpark)*3;
}

void Tkriz::spoctiR()
{
int j;
int m=0;

 for(j=0; j<Ds; j++){
   amin(m,s[j]->pruhu1);
   amin(m,int(s[j]->opac->pruhu0));
 }
 R=m*DPRUHU+2;
 if(viceurovn) R=max(R,20);
}
//---------------------------------------------------------------------------

