/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "prechinf.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TInfoPrechod *InfoPrechod;
//---------------------------------------------------------------------------
__fastcall TInfoPrechod::TInfoPrechod(TComponent* Owner)
	: TFormInfo(Owner)
{
}
//---------------------------------------------------------------------------
void TInfoPrechod::update()
{
 if(selprechod->jesemaf){
   if(selprechod->volno){
     Label5->Caption= "zelen� pro auta";
     LabelInt->Caption=IntToStr(selprechod->auta + selprechod->tlacitko);
   }else{
     Label5->Caption= "p�ech�zej� chodci";
     LabelInt->Caption=IntToStr(selprechod->chodci);
   }
   LabelCas->Caption=IntToStr(int((selprechod->caszmen -cas)/5));
 }
 Projelo->Caption= IntToStr(selprechod->projelo);
}
//---------------------------------------------------------------------------
void TInfoPrechod::UpdateAll()
{
 update();
 Panel1->Visible= selprechod->jesemaf;
 Souradnice->Caption= "[" + IntToStr(selprechod->pos.x) + ", "
    + IntToStr(selprechod->pos.y) + "]";
}
//---------------------------------------------------------------------------
