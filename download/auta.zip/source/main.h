//---------------------------------------------------------------------------
#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>
#include <vcl\ExtCtrls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\Menus.hpp>
#include <vcl\Dialogs.hpp>
//---------------------------------------------------------------------------
#include "autasim.h"

class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TStatusBar *StatusBar1;
	TTimer *TimerSelect;
 TMainMenu *MainMenu1;
 TMenuItem *Soubor1;
 TMenuItem *Otevt1;
 TMenuItem *Uloit1;
 TMenuItem *Nov1;
 TMenuItem *Uloitjako1;
 TMenuItem *Konec1;
 TMenuItem *Simulace1;
 TMenuItem *Spustit1;
 TMenuItem *N1;
 TMenuItem *Resetovat1;
 TMenuItem *Urychlit1;
 TOpenDialog *OpenDialog1;
 TSaveDialog *SaveDialog1;
 TTimer *TimerSim;
	TPaintBox *Mapa;
	TMenuItem *N3;
	TMenuItem *N2;
	TTimer *TimerMove;
	TTimer *TimerPosun;
	TMenuItem *Lupa1;
	TMenuItem *N51;
	TMenuItem *N251;
	TMenuItem *N501;
	TMenuItem *N1001;
	TMenuItem *Zvtit1;
	TMenuItem *Zmenit1;
	TMenuItem *Monosti1;
	TMenuItem *Mapa1;
	TMenuItem *Vycentrovat1;
	TMenuItem *Statistika1;
	TMenuItem *Dalvstup1;
	TMenuItem *N4;
	TMenuItem *Navybranou1;
	TMenuItem *M1;
	TMenuItem *Dalparkovit1;
	TPopupMenu *PopupMenu1;
	TMenuItem *Vstupdomsta1;
	TMenuItem *Parkovit1;
	TMenuItem *Storno1;
	TMenuItem *Kiovatka1;
	TMenuItem *N5;
	TScrollBar *ScrollBarX;
	TScrollBar *ScrollBarY;
	TMenuItem *Inverznbarvy1;
	TMenuItem *Seaditvstupy1;
	TMenuItem *Npovda1;
	TMenuItem *Oprogramu1;
	TMenuItem *Obsah1;
	TMenuItem *N101;
	TMenuItem *N1501;
	TPanel *Panel1;
	TSpeedButton *ButtonNew;
	TSpeedButton *ButtonOpen;
	TSpeedButton *ButtonSave;
	TSpeedButton *ButtonReset;
	TSpeedButton *ButtonPlay;
	TSpeedButton *ButtonFast;
	TSpeedButton *ButtonPause;
	TEdit *EditSpeed;
	TUpDown *Speed;
	TSpeedButton *SpeedButton1;
	TSpeedButton *ButtonZoomIn;
	TSpeedButton *ButtonZoomOut;
	TEdit *EditZoom;
	TLabel *Label1;
	TTrackBar *TrackBar1;
	TLabel *LabelTime;
	TPanel *Panel2;
	TMenuItem *N6;
 void __fastcall TimerSelectTimer(TObject *Sender);
 void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
 void __fastcall Konec1Click(TObject *Sender);
 void __fastcall ButtonResetClick(TObject *Sender);
 void __fastcall ButtonOpenClick(TObject *Sender);
 void __fastcall ButtonPlayClick(TObject *Sender);
 void __fastcall ButtonPauseClick(TObject *Sender);
 void __fastcall ButtonFastClick(TObject *Sender);
 void __fastcall Uloitjako1Click(TObject *Sender);
	void __fastcall TimerSimTimer(TObject *Sender);
	void __fastcall EditZoomChange(TObject *Sender);
	void __fastcall ButtonZoomInClick(TObject *Sender);
	void __fastcall ButtonZoomOutClick(TObject *Sender);
	void __fastcall ButtonSaveClick(TObject *Sender);
	void __fastcall EditKeyPress(TObject *Sender, char &Key);
	void __fastcall MapaMouseDown(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y);
	void __fastcall MapaMouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall MapaPaint(TObject *Sender);
	void __fastcall EditClick(TObject *Sender);
	void __fastcall FormResize(TObject *Sender);
	void __fastcall ButtonNewClick(TObject *Sender);
	void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall TimerMoveTimer(TObject *Sender);
	void __fastcall TimerPosunTimer(TObject *Sender);
	void __fastcall TrackBar1Change(TObject *Sender);
	void __fastcall N51Click(TObject *Sender);
	void __fastcall FormMouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall Monosti1Click(TObject *Sender);
	void __fastcall Vycentrovat1Click(TObject *Sender);
	void __fastcall Statistika1Click(TObject *Sender);
	void __fastcall Dalvstup1Click(TObject *Sender);
	void __fastcall Navybranou1Click(TObject *Sender);
	void __fastcall M1Click(TObject *Sender);
	void __fastcall Dalparkovit1Click(TObject *Sender);
	void __fastcall Popup1Click(TObject *Sender);
	void __fastcall FormMouseUp(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y);
	void __fastcall MapaMouseUp(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y);
	void __fastcall TrackBar1KeyUp(TObject *Sender, WORD &Key,
	TShiftState Shift);
	void __fastcall Inverznbarvy1Click(TObject *Sender);
	void __fastcall Seaditvstupy1Click(TObject *Sender);
	void __fastcall ScrollBarXChange(TObject *Sender);
	void __fastcall ScrollBarYChange(TObject *Sender);
	void __fastcall ButtonNewMouseMove(TObject *Sender, TShiftState Shift,
	int X, int Y);
	void __fastcall Oprogramu1Click(TObject *Sender);
	void __fastcall Obsah1Click(TObject *Sender);

private:	// User declarations
public:		// User declarations
 void zoom();
 bool saveAs();
 bool saveMesto();
 void openMesto();
 bool savemodif();
 void smazMesto();
 void MouseZvyrazni(int X,int Y);
 void MouseZoom(int X,int Y,bool zvetsi);
 void UpdateXY();
 bool MapaPosun1(int b,int X,int Y);
 void MapaPosun2();
 void setCursor(TCursor cur);
 void novaSilnice();
 void zamerit(int x,int y);
 void clipCur();
 void Select();
 void popup(Tpos &pos);
 void __fastcall SimPaint(int rych);
 void InfoPaint();
 void __fastcall vyberUzel(Tuzel *u);
 void __fastcall ApplActiv(TObject *Sender);
	virtual __fastcall TForm1(TComponent* Owner);
 void virtual __fastcall WndProc(Messages::TMessage &Message);
 void virtual __fastcall RestrictSize(TMessage& Msg);
BEGIN_MESSAGE_MAP
MESSAGE_HANDLER(WM_GETMINMAXINFO,TMessage,RestrictSize)
END_MESSAGE_MAP(TForm)
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
const TCursor crMovLeft=5;
const TCursor crMovRight=6;
const TCursor crMovUp=7;
const TCursor crMovDown=8;
const TCursor crMovLU=9;
const TCursor crMovLD=10;
const TCursor crMovRU=11;
const TCursor crMovRD=12;
const TCursor crPresun=1;
//---------------------------------------------------------------------------
#endif
