/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include "krizinfo.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TInfoKriz *InfoKriz;

extern void __fastcall PaintSemaf1(TPaintBox* b,bool s);
extern void __fastcall PaintHlavni(TPaintBox *Sender);
//---------------------------------------------------------------------------
__fastcall TInfoKriz::TInfoKriz(TComponent* Owner)
	: TFormInfo(Owner)
{
}
//---------------------------------------------------------------------------
void TInfoKriz::update()
{
int i;

 if(selkriz->jesemaf && selkriz->semaf){
   i=selkriz->stav->interval;
   LabelInt->Caption=IntToStr(i);
   LabelCas->Caption=IntToStr(int((selkriz->caszmen -cas)/5));
   if(PaintBox1->Tag!= selkriz->stav->id){
     PaintBox1->Tag= selkriz->stav->id;
     PaintBox1->Invalidate();
   }
 }
 Projelo->Caption= IntToStr(selkriz->projelo);
}
//---------------------------------------------------------------------------
void TInfoKriz::UpdateAll()
{
 update();
 Panel1->Visible= selkriz->jesemaf && selkriz->semaf;
 if(!(selkriz->jesemaf && selkriz->semaf)){
   PaintBox2->Invalidate();
 }
 Souradnice->Caption= "[" + IntToStr(selkriz->pos.x) + ", "
    + IntToStr(selkriz->pos.y) + "]";
}
//---------------------------------------------------------------------------
void __fastcall TInfoKriz::PaintBox1Paint(TObject *Sender)
{
 PaintSemaf1((TPaintBox *)Sender,false);
}
//---------------------------------------------------------------------------
void __fastcall TInfoKriz::PaintBox2Paint(TObject *Sender)
{
 PaintHlavni((TPaintBox *)Sender);
}
//---------------------------------------------------------------------------

