//---------------------------------------------------------------------------
#ifndef moznostiH
#define moznostiH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>
#include <vcl\ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFormMoznosti : public TForm
{
__published:	// IDE-managed Components
	TButton *Button1;
	TButton *Button2;
	TPageControl *PageControl1;
	TTabSheet *TabSheet1;
	TTabSheet *TabSheet2;
	TTabSheet *TabSheet3;
	TEdit *Edit9;
	TEdit *Edit8;
	TUpDown *UpDown8;
	TUpDown *UpDown9;
	TEdit *Edit5;
	TEdit *Edit6;
	TEdit *Edit7;
	TUpDown *UpDown7;
	TUpDown *UpDown6;
	TUpDown *UpDown5;
	TEdit *Edit11;
	TUpDown *UpDown11;
	TUpDown *UpDown10;
	TEdit *Edit10;
	TEdit *Edit12;
	TUpDown *UpDown12;
	TPanel *Panel1;
	TPanel *Panel2;
	TPanel *Panel3;
	TPanel *Panel4;
	TPanel *Panel5;
	TPanel *Panel6;
	TPanel *Panel7;
	TPanel *Panel8;
	TPanel *Panel10;
	TPanel *Panel11;
	TPanel *Panel12;
	TLabel *Label11;
	TLabel *Label13;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TLabel *Label6;
	TLabel *Label7;
	TLabel *Label8;
	TLabel *Label9;
	TPanel *Panel13;
	TLabel *Label10;
	TLabel *Label12;
	TEdit *Edit2;
	TUpDown *UpDown2;
	TEdit *Edit3;
	TUpDown *UpDown3;
	TEdit *Edit4;
	TUpDown *UpDown4;
	TGroupBox *GroupBox1;
	TPanel *Panel15;
	TLabel *Label15;
	TEdit *Edit14;
	TUpDown *UpDown14;
	TPanel *Panel9;
	TLabel *Label1;
	TEdit *Edit1;
	TUpDown *UpDown1;
	TPanel *Panel14;
	TLabel *Label14;
	TEdit *Edit13;
	TUpDown *UpDown13;
	TBevel *Bevel1;
	TTabSheet *TabSheet4;
	TPanel *Panel16;
	TLabel *Label16;
	TLabel *Label17;
	TLabel *Label18;
	TEdit *Edit15;
	TUpDown *UpDown15;
	TEdit *Edit16;
	TUpDown *UpDown16;
	TPanel *Panel17;
	TEdit *Edit17;
	TLabel *Label19;
	void __fastcall FormShow(TObject *Sender);
	
	
	
private:	// User declarations
public:		// User declarations
	virtual __fastcall TFormMoznosti(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TFormMoznosti *FormMoznosti;
//---------------------------------------------------------------------------
#endif
