//---------------------------------------------------------------------------
#ifndef statisH
#define statisH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
//---------------------------------------------------------------------------
#include "autasim.h"

class TFormStatis : public TForm
{
__published:	// IDE-managed Components
	TButton *Button1;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *LabelSirka;
	TLabel *LabelVyska;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TLabel *LabelDv;
	TLabel *LabelDp;
	TLabel *LabelDc;
	TLabel *Label6;
	TLabel *LabelDk;
	TBevel *Bevel1;
	TBevel *Bevel2;
	TLabel *Label7;
	TLabel *LabelDelka;
	void __fastcall FormShow(TObject *Sender);
	
private:	// User declarations
public:		// User declarations
	virtual __fastcall TFormStatis(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TFormStatis *FormStatis;
//---------------------------------------------------------------------------
#endif
