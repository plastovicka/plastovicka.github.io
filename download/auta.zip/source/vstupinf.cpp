/*
(C) 2000  Petr Lastovicka

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation

*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include "vstupinfo.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TInfoVstup *InfoVstup;
//---------------------------------------------------------------------------
__fastcall TInfoVstup::TInfoVstup(TComponent* Owner)
	: TFormInfo(Owner)
{
}
//---------------------------------------------------------------------------
void TInfoVstup::update()
{
 LabelVyjelo->Caption= IntToStr(selvstup->vyjelo);
 LabelPrijelo->Caption= IntToStr(selvstup->prijelo);
}
//---------------------------------------------------------------------------
void TInfoVstup::UpdateAll()
{
 update();
 Caption= selvstup->jmeno;
 Prijizdi->Caption= IntToStr(selvstup->prijizdi);
 Souradnice->Caption= "[" + IntToStr(selvstup->pos.x) + ", "
    + IntToStr(selvstup->pos.y) + "]";
}
//---------------------------------------------------------------------------
