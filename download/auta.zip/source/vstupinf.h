//---------------------------------------------------------------------------
#ifndef vstupinfoH
#define vstupinfoH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
//---------------------------------------------------------------------------
#include "autasim.h"

class TInfoVstup : public TFormInfo
{
__published:	// IDE-managed Components
	TLabel *Label2;
	TLabel *LabelVyjelo;
	TLabel *Label3;
	TLabel *Prijizdi;
	TLabel *Label4;
	TLabel *Souradnice;
	TLabel *Label1;
	TLabel *LabelPrijelo;
private:	// User declarations
public:		// User declarations
 void UpdateAll();
 void update();
	virtual __fastcall TInfoVstup(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TInfoVstup *InfoVstup;
//---------------------------------------------------------------------------
#endif
