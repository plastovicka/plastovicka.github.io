//---------------------------------------------------------------------------
#ifndef autoinfoH
#define autoinfoH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
//---------------------------------------------------------------------------
#include "autasim.h"

class TInfoAuto : public TFormE
{
__published:	// IDE-managed Components
	TLabel *Label4;
	TLabel *Souradnice;
	TLabel *Label3;
	TLabel *Label5;
	TLabel *LabelPred;
	TLabel *LabelZa;
	TLabel *Label6;
	TLabel *Label7;
	TLabel *Label8;
	TLabel *LabelCil;
	TLabel *Label10;
	TLabel *LabelCas;
private:	// User declarations
public:		// User declarations
 long cas0; //�as vybr�n� auta

 void UpdateAll();
 void update();
	virtual __fastcall TInfoAuto(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TInfoAuto *InfoAuto;
//---------------------------------------------------------------------------
#endif
