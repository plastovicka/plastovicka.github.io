//---------------------------------------------------------------------------
#ifndef list1H
#define list1H
//---------------------------------------------------------------------------

#define fors(a,list) for(a=list;a;a=a->nxt)

//sma�e cel� seznam
template <class T> void dellist(T* &list)
{
T *a,*a1;
 for(a=list; a; a=a1){
   a1=a->nxt;
   delete a;
 }
 list=0;
}

//vytvo�� nov� prvek na za��tku seznamu
template <class T,class P> void addlist(T* &list,P param)
{
T *a;
 a=new T(param);
 a->nxt=list;
 list=a;
}

//spoj� dva seznamy
template <class T> void catlist(T* &list,T* item)
{
T **pa;
 pa=&list;
 while(*pa) pa=&(*pa)->nxt;
 *pa=item;
}

//d�lka seznamu
template <class T> int lenlist(T* list)
{
int i=0;
 while(list){ i++; list=list->nxt; }
 return i;
}

//najde konec seznamu
template <class T> T* endlist(T* list)
{
 if(list)
   for(; list->nxt; list=list->nxt);
 return list;
}

//najde ukazatel na item
//p�i chyb� vr�t� ukazatel na nxt posledn�ho prvku
template <class T> T** ptrlist(T* &list,T* item)
{
T **pa;
 pa=&list;
 while(*pa!=item && *pa) pa=&(*pa)->nxt;
 return pa;
}

//najde ukazatel na i-t� prvek
//p�i chybn�m i vr�t� ukazatel na nxt posledn�ho prvku
template <class T> T** ptrlist(T* &list,int i)
{
T **pa;
 pa=&list;
 while(--i && *pa) pa=&(*pa)->nxt;
 return pa;
}

//najde i-t� prvek
template <class T> T* findlist(T* list,int i)
{
 while(--i && list) list=list->nxt;
 return list;
}

//zjist� po�ad� prvku v seznamu
//p�i chyb� vr�t� 0
template <class T> int findlist(T* list,T* item)
{
int i=1;
 while(list!=item){
   if(!list) return 0;
   list=list->nxt;
   i++;
 }
 return i;
}

//sma�e i-t� prvek
template <class T> void dellist(T* &list,int i)
{
T *a,**pa;
 pa=ptrlist(list,i);
 a=*pa;
 if(a){
   *pa=a->nxt;
   delete a;
 }
}

//vyjme prvek item ze seznamu
template <class T> void dellist1(T* &list,T* item)
{
 *ptrlist(list,item)=item->nxt;
}

//sma�e prvek item
//mus� b�t v seznamu
template <class T> void dellist(T* &list,T* item)
{
 if(item){
  *ptrlist(list,item)=item->nxt;
  delete item;
 }
}

//na dal�� prvek, na konci se p�esune na za��tek
template <class T> T* nextlist(T* list,T* item)
{
 if((item=item->nxt)==0) return list;
 return item;
}

//na p�edchoz� prvek, na za��tku se p�esune na konec
template <class T> T* prevlist(T* list,T* item) //list!=0
{
 while(list->nxt!=item && list->nxt) list=list->nxt;
 return list;
}

//obr�t� seznam
template <class T> void reverselist(T* &list)
{
T *a,*b,*c;
 a=0;
 b=list;
 while(b){
   c=b->nxt;
   b->nxt=a;
   a=b;
   b=c;
 }
 list=a;
}
//---------------------------------------------------------------------------
#endif
