/*
(C) 2000  Petr Lastovicka
*/
//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "about.h"
//--------------------------------------------------------------------- 
#pragma resource "*.dfm"
TFormAbout *FormAbout;
//---------------------------------------------------------------------
__fastcall TFormAbout::TFormAbout(TComponent* AOwner)
	: TForm(AOwner)
{
}
//---------------------------------------------------------------------
