/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include <math.h>
#include "krizform.h"
#include "semaf3.h"
#include "semaf4.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TFormKriz *FormKriz;

Tkriz *selkriz; //vybran� k�i�ovatka
int selsmer;    //vybran� sm�r (0 a� selkriz->Ds-1)
Tpruhy* pruhy;  //   "
int selsem,     //vybran� stav semaforu (1 a� Dsemaf)
    Dsemaf;     //po�et stav�
int changing=0; //p�i update nep�episuj objekty na map�

TPaintBox* box[Msemaf+1];
TEdit* ed[Msemaf+1];
TUpDown* updw[Msemaf+1];

//---------------------------------------------------------------------------
__fastcall TFormKriz::TFormKriz(TComponent* Owner)
    : TFormE(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::FormCreate(TObject *Sender)
{
//vytvo� edita�n� pole a obr�zky pro stavy semafor� ve ScrollBoxu1
 for(int i=1;i<=Msemaf;i++){
   box[i]=new TPaintBox(this);
   ed[i]=new TEdit(this);
   updw[i]=new TUpDown(this);
   ed[i]->Tag=i;
   updw[i]->Tag= i;
   box[i]->Left=8;
   box[i]->Top=40*i-40;
   box[i]->Height= 40;
   box[i]->Width= 40;
   box[i]->OnPaint= PaintSemaf;
   box[i]->OnClick= boxClick;
   box[i]->Parent= ScrollBox1;
   ed[i]->Left=65;
   ed[i]->Top=40*i-32;
   ed[i]->Width=41;
   ed[i]->Parent= ScrollBox1;
   ed[i]->OnEnter= edEnter;
   ed[i]->OnChange= edChange;
   ed[i]->OnKeyPress= EditKeyPress;
   updw[i]->OnClick= updwClick;
   updw[i]->Min=1;
   updw[i]->Max=127;
   updw[i]->Parent= ScrollBox1;
   updw[i]->Associate=ed[i];
 }
}
//---------------------------------------------------------------------------
void TFormKriz::UpdateCelkem()
{
Tsemafory *e;
int c=0;

//se�ti intervaly v�ech stav� semafor�
 fors(e,selkriz->semaf) c+=e->interval;
 Celkem->Caption=IntToStr(c);
}
//---------------------------------------------------------------------------
void TFormKriz::UpdateSemaf()
{
Tsemafory *e;
int i=0;

 changing++;
//zobraz edita�n� pole pro stavy semafor�
 fors(e,selkriz->semaf){
   i++;
   box[i]->Visible=true;
   ed[i]->Visible=true;
   updw[i]->Visible=true;
   box[i]->Tag= e->id;
   box[i]->Invalidate();
   updw[i]->Position=e->interval;
 }
 Dsemaf=i;
 if(selsem>i) selsem=i;
 if(selsem<1) selsem=1;
//zb�vaj�c� nezobrazuj
 while(++i<=Msemaf){
    box[i]->Visible=false;
    ed[i]->Visible=false;
    updw[i]->Visible=false;
 }
 UpdateCelkem();
 changing--;
}
//---------------------------------------------------------------------------
void TFormKriz::UpdatePruhy()
{
 changing++;
 if(selsmer>=selkriz->Ds) selsmer=0;
 pruhy=(Tpruhy*)selkriz->s[selsmer];
 if(selkriz->Ds==4){
  Vlevo->Position=pruhy->pruhu[3];
  Rovne->Position=pruhy->pruhu[2];
  LSpolec->Checked= pruhy->lspolec;
 }else if(selkriz->Ds==3){
  Vlevo->Position=pruhy->pruhu[2];
 }
 Vpravo->Position=pruhy->pruhu[1];
 DelOdboc->Position=pruhy->delodboc;
 RSpolec->Checked= pruhy->rspolec;
 PaintBox1->Invalidate();
 changing--;
}
//---------------------------------------------------------------------------
void TFormKriz::UpdateAll()
{
 changing++;
//p�i stupni 3 nezobrazuj edita�n� pole pro sm�r rovn�
 if(selkriz->Ds==4){
  Rovne->Visible=true;
  EditS->Visible=true;
  LabelS->Visible=true;
  LSpolec->Visible=true;
  RSpolec->Caption= "vpravo-rovn�";
  RSpolec->Hint= "Pruh pro sm�r vpravo a rovn�";
  RSpolec->Left=88;
  BtnKrizem->Visible=true;
 }else if(selkriz->Ds==3){
  Rovne->Visible=false;
  EditS->Visible=false;
  LabelS->Visible=false;
  LSpolec->Visible=false;
  RSpolec->Caption= "vlevo-vpravo";
  RSpolec->Hint= "Pruh pro sm�r vlevo a vpravo";
  RSpolec->Left=50;
  BtnKrizem->Visible=false;
 }
 UpdatePruhy();
 UpdateSemaf();
 Zacatek->Position=selkriz->caszmen0;
 Jesemaf->Checked= selkriz->jesemaf;
 Viceurovn->Checked= selkriz->viceurovn;
 PaintBox2->Invalidate();
 changing--;
}
//---------------------------------------------------------------------------
// podle PaintBox->Tag: 0=tu�n� hlavn� silnici, 1=�erven� selsmer
void __fastcall PaintHlavni(TPaintBox *Sender)
{
Tkriz *k;
double u,U[5];
int id,j;
TCanvas* ca= Sender->Canvas;
int x0= Sender->Width/2,
    y0= Sender->Height/2;
const int V=13;
static bool jehlavni[][4]={{1,0,1,0},{0,1,0,1},
  {1,0,0,1},{1,1,0,0},{0,1,1,0},{0,0,1,1},{0,0,0,0}};
static bool jeurov[][4]={{1,1,1,0},{1,1,0,0},{0,1,1,0},{1,0,1,0},
  {1,0,1,0},{0,1,0,1},{1,0,1,0},{0,1,0,1},{1,0,1,0},{0,1,0,1},{1,1,1,1}};

 k= selkriz;
 if(k->hlavni>10){
   k->hlavni=0;
   throw Exception("Chybn� typ hlavn� silnice");
 }
 for(j=0; j< k->Ds; j++){
  U[j]= u= k->uhel(j);
  ca->Pen->Color= clBlack;
  if(Sender->Tag){ //v�b�r sm�ru
    if(j==selsmer) ca->Pen->Color= clRed;
    ca->Pen->Width= 1+(k->s[j]->pruhu0 >0);
  }else{ //hlavn� a vedlej�� silnice
    ca->Pen->Width= k->hlavni && (k->Ds==4 ?
      jehlavni[k->hlavni-4][j]:k->hlavni %3 !=j) ? 3:1;
  }
  ca->MoveTo(x0,y0);
  ca->LineTo(x0*(1+cos(u)), y0*(1+sin(u)));
 }
//v�ce�rov�ov�
 if(Sender->Tag==0 && k->viceurovn){
  id=k->hlavni;
  U[k->Ds]=U[0];
  ca->Pen->Width=1;
  for(j=0; j< k->Ds; j++){
    if(jeurov[id][j]){
     ca->MoveTo(x0+V*cos(U[j]), y0+V*sin(U[j]));
     ca->LineTo(x0+V*cos(U[j+1]), y0+V*sin(U[j+1]));
    }
  }
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::PaintBox1Paint(TObject *Sender)
{
 PaintHlavni((TPaintBox*)Sender);
}
//---------------------------------------------------------------------------
// vykresl� semafor typu PaintBox->Tag
// P�i s=true nakresl� kolem �ern� obd�ln�k
void __fastcall PaintSemaf1(TPaintBox* b,bool s)
{
TCanvas* ca=b->Canvas;
int x0,y0,id,i,j,m;
double u;
static short zele[][2]={{0,0},{0,2},{1,0},{2,1},
{0,2},{1,3},{0,3},{1,0},{2,1},{3,2}};
const double q=5;

 if(s){ //vybran� stav
   ca->Pen->Color=clBlack;
   ca->Rectangle(0,0,b->Width-1,b->Height-1);
 }
 x0=b->Width/2; y0=b->Height/2;
 id= b->Tag;
//typy 9 a 10 jsou cel� zelen� a uprost�ed se neprot�naj�
 if(id>9){
   if(id>12){
     b->Tag=0;
     throw Exception("Chybn� typ semaforu");
   }
   ca->Pen->Color= TColor(0xa000);
   j=id-10;
   for(m=0; m<=(id==12); m++,j++)
   for(i=0; i<2; i++){
     u=selkriz->uhel(j);
     j++;
     if(j==4) j=0;
     ca->MoveTo(x0*(1+cos(u)), y0*(1+sin(u)));
     ca->LineTo(x0+q*cos(u), y0+q*sin(u));
     u=selkriz->uhel(j);
     j++;
     if(j==4) j=0;
     ca->LineTo(x0+q*cos(u), y0+q*sin(u));
     ca->LineTo(x0*(1+cos(u)), y0*(1+sin(u)));
   }
 }else{
  for(j=0; j<selkriz->Ds; j++){
   u=selkriz->uhel(j);
   ca->Pen->Color=(zele[id][0]==j || zele[id][1]==j)? TColor(0xb000):clRed;
   ca->MoveTo(x0,y0);
   ca->LineTo(x0*(1+cos(u)), y0*(1+sin(u)));
  }
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::PaintSemaf(TObject *Sender)
{
 PaintSemaf1((TPaintBox*)Sender,box[selsem]==(TPaintBox*)Sender);
}
//---------------------------------------------------------------------------
void TFormKriz::setselsem(int i)
{
int j;
//zm�� aktivn� stav semafor�
 if(i!=selsem){
   j=selsem;
   selsem=i;
   box[i]->Invalidate();
   box[j]->Invalidate();
   ed[j]->SelLength=0;
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::ButtonLeftClick(TObject *Sender)
{
 selsmer++;
 if(selsmer==selkriz->Ds) selsmer=0;
 UpdatePruhy();
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::ButtonRightClick(TObject *Sender)
{
 if(!selsmer) selsmer=selkriz->Ds;
 selsmer--;
 UpdatePruhy();
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::ButtonNewClick(TObject *Sender)
{
int i;

 if(Dsemaf==Msemaf) ShowMessage("Seznam semafor� je u� moc dlouh� !");
 else
//zobraz dialog pro v�b�r typu semaforu
 if((selkriz->Ds==4 ? FormSemaf4->ShowModal() : FormSemaf3->ShowModal())
       == mrOk){
  //p�ipoj nov� stav na konec seznamu
   i= selkriz->Ds==4 ? FormSemaf4->sel : FormSemaf3->sel;
   catlist(selkriz->semaf, new Tsemafory(i));
   selsem= Dsemaf+1;
   modif=true;
   UpdateSemaf();
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::ButtonDelClick(TObject *Sender)
{
//sma� stav semaforu
 dellist(selkriz->semaf,selsem);
 modif=true;
 UpdateSemaf();
}
//---------------------------------------------------------------------------
void TFormKriz::prohodsemaf()
{
Tsemafory **pe,*e1,*e2;
//prohod� stav selsem s n�sleduj�c�m, (selsem!=Dsemaf)
  pe= ptrlist(selkriz->semaf,selsem);
  e1=*pe;
  e2=e1->nxt;
  e1->nxt=e2->nxt;
  e2->nxt=e1;
  *pe=e2;
  modif=true;
  UpdateSemaf();
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::ButtonDownClick(TObject *Sender)
{
 if(selsem<Dsemaf){
   prohodsemaf();
   selsem++;
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::ButtonUpClick(TObject *Sender)
{
 if(selsem>1){
   selsem--;
   prohodsemaf();
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::edEnter(TObject *Sender)
{
//vstup do edita�n�ho pole vybere odpov�daj�c� stav semaforu
 setselsem(((TEdit*)Sender)->Tag);
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::boxClick(TObject *Sender)
{
int i;
 for(i=1; box[i]!=(TPaintBox*)Sender; i++);
 setselsem(i);
 ed[i]->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::updwClick(TObject *Sender, TUDBtnType Button)
{
int i=((TUpDown*)Sender)->Tag;
 setselsem(i);
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::EditKeyPress(TObject *Sender, char &Key)
{
 if(Key==13){
   ActiveControl=0;
   activMain();
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::EditClick(TObject *Sender)
{
 ((TEdit*)Sender)->SelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::PaintBox1MouseDown(TObject *Sender,
	TMouseButton Button, TShiftState Shift, int X, int Y)
{
int j;
double u0,du,dum;

//v�b�r sm�ru pomoci my�i
 Y-=((TPaintBox*)Sender)->Height/2;
 X-=((TPaintBox*)Sender)->Width/2;
 if(X || Y){
  u0=atan2(Y,X);
 //najdi nejmen�� odchylku �hlu silnice od my�i
  dum=7;
  for(j=0; j< selkriz->Ds; j++){
   du=fabs(selkriz->uhel(j)-u0);
   if(du>M_PI) du=2*M_PI-du;
   if(du<dum){ dum=du; selsmer=j; }
  }
  UpdatePruhy();
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::BtnHlavVedlLClick(TObject *Sender)
{
 selkriz->hlavni++;
 if(selkriz->hlavni==4) selkriz->hlavni=1;
 if(selkriz->hlavni>9) selkriz->hlavni=6;
 PaintBox2->Invalidate();
 modif=true;
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::BtnHlavVedlRClick(TObject *Sender)
{
 selkriz->hlavni--;
 if(selkriz->hlavni==3 || selkriz->hlavni==5) selkriz->hlavni=9;
 if(selkriz->hlavni<1) selkriz->hlavni=3;
 PaintBox2->Invalidate();
 modif=true;
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::PaintBox2MouseDown(TObject *Sender,
	TMouseButton Button, TShiftState Shift, int X, int Y)
{
 if(Button==mbLeft) BtnHlavVedlRClick(Sender);
 else BtnHlavVedlLClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::BtnPravaRukaClick(TObject *Sender)
{
//typ 0 nebo 10 - pravidlo prav� ruky (nebo v�ce�rov�ov�)
 int i= selkriz->Ds==4 ? 10:0;
 if(selkriz->hlavni!=i){
   selkriz->hlavni=i;
   PaintBox2->Invalidate();
   modif=true;
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::BtnKrizemClick(TObject *Sender)
{
//typ 4 nebo 5 - hlavn� jde rovn�
 if(selkriz->hlavni==4) selkriz->hlavni=5;
 else selkriz->hlavni=4;
 PaintBox2->Invalidate();
 modif=true;
}
//---------------------------------------------------------------------------
void cbch(bool &p,TCheckBox *h,bool repaint)
{
 if(!changing && p!= h->Checked){
   p= h->Checked;
   modif=true;
   if(repaint) zmenaR();
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::LSpolecClick(TObject *Sender)
{
 cbch(pruhy->lspolec, (TCheckBox*)Sender, true);
 if(pruhy->lspolec){
   if(!pruhy->pruhu[3]) Vlevo->Position= ++pruhy->pruhu[3];
   if(!pruhy->pruhu[2]) Rovne->Position= ++pruhy->pruhu[2];
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::RSpolecClick(TObject *Sender)
{
 cbch(pruhy->rspolec, (TCheckBox*)Sender, true);
 if(pruhy->rspolec){
   if(!pruhy->pruhu[1]) Vpravo->Position= ++pruhy->pruhu[1];
   if(!pruhy->pruhu[2])
     (selkriz->Ds>3 ? Rovne:Vlevo)->Position= ++pruhy->pruhu[2];
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::JesemafClick(TObject *Sender)
{
 cbch(selkriz->jesemaf, (TCheckBox*)Sender, false);
 PanelSemaf->Visible= selkriz->jesemaf;
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::ViceurovnClick(TObject *Sender)
{
//v�ce�rov�ov�
 cbch(selkriz->viceurovn, (TCheckBox*)Sender, true);
 PaintBox2->Invalidate();
}
//---------------------------------------------------------------------------
void edch(short &p,TUpDown *h,bool repaint)
{
 if(!changing && p!= h->Position){
   p= h->Position;
   modif=true;
   if(repaint) zmenaR();
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::edChange(TObject *Sender)
{
Tsemafory *e;
int j,i;

 i=j=((TEdit*)Sender)->Tag;
 if(i<=Dsemaf){
  for(e=selkriz->semaf; --i;  e=e->nxt);
  edch(e->interval,updw[j],false);
  UpdateCelkem();
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::EditZChange(TObject *Sender)
{
 edch(selkriz->caszmen0,Zacatek,false);
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::EditLChange(TObject *Sender)
{
 edch(pruhy->pruhu[2+(selkriz->Ds>3)],Vlevo,true);
 if(!Vlevo->Position) ((selkriz->Ds>3)? LSpolec:RSpolec)->Checked=0;
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::EditSChange(TObject *Sender)
{
 edch(pruhy->pruhu[2],Rovne,true);
 if(!Rovne->Position){ RSpolec->Checked= 0; LSpolec->Checked= 0; }
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::EditRChange(TObject *Sender)
{
 edch(pruhy->pruhu[1],Vpravo,true);
 if(!Vpravo->Position) RSpolec->Checked=0;
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::EditDChange(TObject *Sender)
{
 edch(pruhy->delodboc,DelOdboc,true);
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::SpeedButton1Click(TObject *Sender)
{
 Application->HelpContext(100);
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::SpeedButton2Click(TObject *Sender)
{
 Application->HelpContext(101);
}
//---------------------------------------------------------------------------
void __fastcall TFormKriz::SpeedButton3Click(TObject *Sender)
{
 Application->HelpContext(102);
}
//---------------------------------------------------------------------------


