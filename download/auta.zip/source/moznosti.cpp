/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "moznosti.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TFormMoznosti *FormMoznosti;
//---------------------------------------------------------------------------
__fastcall TFormMoznosti::TFormMoznosti(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormMoznosti::FormShow(TObject *Sender)
{
//nastav� Edit->Text podle UpDown->Position
 UpDown1->Associate= Edit1;
 UpDown2->Associate= Edit2;
 UpDown3->Associate= Edit3;
 UpDown4->Associate= Edit4;
 UpDown5->Associate= Edit5;
 UpDown6->Associate= Edit6;
 UpDown7->Associate= Edit7;
 UpDown8->Associate= Edit8;
 UpDown9->Associate= Edit9;
 UpDown10->Associate=Edit10;
 UpDown11->Associate=Edit11;
 UpDown12->Associate=Edit12;
 UpDown13->Associate=Edit13;
 UpDown14->Associate=Edit14;
 UpDown15->Associate=Edit15;
 UpDown16->Associate=Edit16;
}
//---------------------------------------------------------------------------
