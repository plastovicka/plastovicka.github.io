//---------------------------------------------------------------------------
#ifndef parkinfoH
#define parkinfoH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
//---------------------------------------------------------------------------
#include "autasim.h"

class TInfoPark : public TFormInfo
{
__published:	// IDE-managed Components
	TLabel *Label1;
	TLabel *Park;
	TLabel *Label3;
	TLabel *Prijizdi;
	TLabel *Label4;
	TLabel *Souradnice;
	TLabel *LabelPrijelo;
	TLabel *Label5;
private:	// User declarations
public:		// User declarations
 void UpdateAll();
 void update();
	virtual __fastcall TInfoPark(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TInfoPark *InfoPark;
//---------------------------------------------------------------------------
#endif
