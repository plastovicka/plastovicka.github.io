/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include <math.h>
#include "silnform.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TFormSiln *FormSiln;
TUsiln *selsiln=0;
bool nepruh,nerych,nepruh0,nerych0,nepruh1,nerych1;

const int tabrych[]={0,20,40,50,70,90,110}; //rychlosti (km/h)
//---------------------------------------------------------------------------
__fastcall TFormSiln::TFormSiln(TComponent* Owner)
	: TFormE(Owner)
{
}
//---------------------------------------------------------------------------
void TFormSiln::UpdateLabel()
{
 nepruh= nepruh0 || nepruh1 || Pruhu0->Position!=Pruhu1->Position;
 nerych= nerych0 || nerych1 || Rychlost0->Position!=Rychlost1->Position;

 Pruhu->Position=1;
 //bez p�edchoz�ho p��kazu nelze p�i�adit hodnotu 4 (Pro� ?)
 Pruhu->Position= Pruhu0->Position;
 Rychlost->Position=1;
 Rychlost->Position= Rychlost0->Position;

 if(nepruh)  Pruhu->Position= 4;
 if(nepruh0) Pruhu0->Position= 4;
 if(nepruh1) Pruhu1->Position= 4;
 if(nerych)  Rychlost->Position= 4;
 if(nerych0) Rychlost0->Position= 4;
 if(nerych1) Rychlost1->Position= 4;

 if(nepruh) LabelPruh->Caption= "--";
 else LabelPruh->Caption= IntToStr(Pruhu->Position);
 if(nerych) LabelRych->Caption= "--";
 else LabelRych->Caption= IntToStr(tabrych[Rychlost->Position]);
 if(nepruh0) LabelPruh0->Caption= "--";
 else LabelPruh0->Caption= IntToStr(Pruhu0->Position);
 if(nerych0) LabelRych0->Caption= "--";
 else LabelRych0->Caption= IntToStr(tabrych[Rychlost0->Position]);
 if(nepruh1) LabelPruh1->Caption= "--";
 else LabelPruh1->Caption= IntToStr(Pruhu1->Position);
 if(nerych1) LabelRych1->Caption= "--";
 else LabelRych1->Caption= IntToStr(tabrych[Rychlost1->Position]);
}
//---------------------------------------------------------------------------
void TFormSiln::UpdateAll()
{
TUsiln *s;
int delka=0;

 nepruh0=nepruh1=false;
 nerych0=nerych1=false;

 Pruhu0->Position= selsiln->c->pruhu0;
 Rychlost0->Position= selsiln->c->rychlost;
 Pruhu1->Position= selsiln->c->opac->pruhu0;
 Rychlost1->Position= selsiln->c->opac->rychlost;

 fors(s,selsiln){
   delka+= s->c->spoctidelku();
   if(s->c->pruhu0!= Pruhu0->Position) nepruh0=true;
   if(s->c->opac->pruhu0!= Pruhu1->Position) nepruh1=true;
   if(s->c->rychlost!= Rychlost0->Position) nerych0=true;
   if(s->c->opac->rychlost!= Rychlost1->Position) nerych1=true;
 }

 LabelDelka->Caption= IntToStr(delka)+" m";
 PaintBox0->Invalidate();
 PaintBox1->Invalidate();
 UpdateLabel();
}
//---------------------------------------------------------------------------
void zmenp0(short p)
{
TUsiln *s;
Tsilnice *cl,*c;
int m;

 cl=0;
 fors(s,selsiln){
   c= s->c;
  //zm�� ���ku silnice
   c->pruhu0= p;
  //na konc�ch vybran� cesty nem�� pruhy pro odbo�en�
   if(cl && cl->delodboc){
     m= c->opac->smer - cl->smer;
     if(m<0) m+= cl->uzel->Ds;
     ((Tpruhy*)cl)->pruhu[m] = p;
   }
   cl=c;
 }
}
//---------------------------------------------------------------------------
void zmenp1(short p)
{
TUsiln *s;
Tsilnice *cl,*c;
int m;

 cl=0;
 fors(s,selsiln){
   c= s->c->opac;
  //zm�� ���ku silnice
   c->pruhu0= p;
  //na konc�ch vybran� cesty nem�� pruhy pro odbo�en�
   if(cl && c->delodboc){
     m= cl->smer - c->smer;
     if(m<0) m+= c->uzel->Ds;
     ((Tpruhy*)c)->pruhu[m] = p;
   }
   cl=s->c;
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormSiln::PruhuClick(TObject *Sender, TUDBtnType Button)
{
short i;

 if(nepruh){
   if(nepruh0 || nepruh1){
     i=Smallint(Button==btPrev ? 1:2);
     Pruhu0->Position=i;
     Pruhu1->Position=i;
   }else{
     if((Pruhu0->Position > Pruhu1->Position)==(Button==btPrev) ){
       if(!Pruhu1->Position) Pruhu1->Position=1;
       Pruhu0->Position= Pruhu1->Position;
     }else{
       if(!Pruhu0->Position) Pruhu0->Position=1;
       Pruhu1->Position= Pruhu0->Position;
     }
   }
 }else{
   Pruhu0->Position= Pruhu->Position;
   Pruhu1->Position= Pruhu->Position;
 }
 nepruh0=nepruh1=false;
 zmenp0(Pruhu0->Position);
 zmenp1(Pruhu1->Position);
 UpdateLabel();
 modif=true;
 zmenaR();
}
//---------------------------------------------------------------------------
void __fastcall TFormSiln::Pruhu0Click(TObject *Sender, TUDBtnType Button)
{
 if(nepruh0){
   Pruhu0->Position= Smallint( (Button==btPrev) ? 1:2 );
   nepruh0=false;
 }
 if(!(nepruh0 || nepruh1 || Pruhu0->Position || Pruhu1->Position)){
   Pruhu1->Position++;
   zmenp1(Pruhu1->Position);
 }
 zmenp0(Pruhu0->Position);
 UpdateLabel();
 modif=true;
 zmenaR();
}
//---------------------------------------------------------------------------
void __fastcall TFormSiln::Pruhu1Click(TObject *Sender, TUDBtnType Button)
{
 if(nepruh1){
   Pruhu1->Position= Smallint( (Button==btPrev) ? 1:2 );
   nepruh1=false;
 }
 if(!(nepruh0 || nepruh1 || Pruhu0->Position || Pruhu1->Position)){
   Pruhu0->Position++;
   zmenp0(Pruhu0->Position);
 }
 zmenp1(Pruhu1->Position);
 UpdateLabel();
 modif=true;
 zmenaR();
}
//---------------------------------------------------------------------------
void __fastcall TFormSiln::RychlostClick(TObject *Sender, TUDBtnType Button)
{
TUsiln *s;
short i;

 if(nerych){
   if(nerych0 || nerych1){
     i=Smallint(Button==btPrev ? 3:4);
     Rychlost0->Position=i;
     Rychlost1->Position=i;
   }else{
     if((Rychlost0->Position > Rychlost1->Position)==(Button==btPrev) ){
       Rychlost0->Position= Rychlost1->Position;
     }else{
       Rychlost1->Position= Rychlost0->Position;
     }
   }
 }else{
   Rychlost0->Position= Rychlost->Position;
   Rychlost1->Position= Rychlost->Position;
 }
 nerych0=nerych1=false;

 fors(s,selsiln){
   s->c->rychlost= Rychlost->Position;
   s->c->opac->rychlost= Rychlost->Position;
 }
 UpdateLabel();
 modif=true;
}
//---------------------------------------------------------------------------
void __fastcall TFormSiln::Rychlost0Click(TObject *Sender, TUDBtnType Button)
{
TUsiln *s;

 if(nerych0){
   Rychlost0->Position= Smallint( (Button==btPrev) ? 3:4 );
   nerych0=false;
 }
 fors(s,selsiln){
   s->c->rychlost= Rychlost0->Position;
 }
 UpdateLabel();
 modif=true;
}
//---------------------------------------------------------------------------
void __fastcall TFormSiln::Rychlost1Click(TObject *Sender, TUDBtnType Button)
{
TUsiln *s;

 if(nerych1){
   Rychlost1->Position= Smallint( (Button==btPrev) ? 3:4 );
   nerych1=false;
 }
 fors(s,selsiln){
   s->c->opac->rychlost= Rychlost1->Position;
 }
 UpdateLabel();
 modif=true;
}
//---------------------------------------------------------------------------
void __fastcall TFormSiln::PaintBox1Paint(TObject *Sender)
{
const double dU=0.5;
const double dR=0.4;
Tpos p1,p2;
int X,Y;
double dm,dx,dy,u;
TPaintBox *pb=((TPaintBox*)Sender);
TCanvas* ca;
int x0,y0;

 ca=pb->Canvas;
 x0=pb->Width/2,
 y0=pb->Height/2;

//koncov� body
 p1= selsiln->c->opac->uzel->pos;
 p2= endlist(selsiln)->c->uzel->pos;
//sm�rov� vektor
 dx= (p2.x-p1.x);
 dy= (p2.y-p1.y);
 if(dx || dy){
  if(pb->Tag) dx=-dx, dy=-dy;
  u=atan2(dy,dx);
  dm= sqrt(sqr(dx)+sqr(dy));
  dx/=dm;
  dy/=dm;
 //nakresli �ipku
  ca->MoveTo((1-dx)*x0,(1-dy)*y0);
  ca->LineTo(X=(1+dx)*x0,Y=(1+dy)*y0);
  ca->LineTo( x0*(1+dR*cos(u+dU)), y0*(1+dR*sin(u+dU)) );
  ca->MoveTo(X,Y);
  ca->LineTo( x0*(1+dR*cos(u-dU)), y0*(1+dR*sin(u-dU)) );
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormSiln::SpeedButton1Click(TObject *Sender)
{
 Application->HelpContext(103);
}
//---------------------------------------------------------------------------
