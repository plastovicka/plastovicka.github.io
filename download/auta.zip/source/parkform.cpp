/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include "parkform.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TFormPark *FormPark;
Tpark *selpark;

extern int changing;
extern void edch(short &p,TUpDown *h,bool repaint);
//---------------------------------------------------------------------------
__fastcall TFormPark::TFormPark(TComponent* Owner)
	: TFormE(Owner){}
//---------------------------------------------------------------------------
void TFormPark::UpdateAll()
{
 changing++;
 Prijizdi->Position= selpark->prijizdi;
 Edit1->Text= selpark->jmeno;
 Park->Position= selpark->Mpark;
 changing--;
}
//---------------------------------------------------------------------------
void __fastcall TFormPark::EditKeyPress(TObject *Sender, char &Key)
{
 if(Key==13){
   ActiveControl=0;
   activMain();
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormPark::Edit1Exit(TObject *Sender)
{
 if(strcmp(selpark->jmeno,Edit1->Text.c_str())){
   strcpy(selpark->jmeno,Edit1->Text.c_str());
   modif=true;
   prekresli();
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormPark::FormCreate(TObject *Sender)
{
 Edit1->MaxLength= sizeof(Tjmeno)-1;
}
//---------------------------------------------------------------------------
void __fastcall TFormPark::EditHChange(TObject *Sender)
{
 edch(selpark->prijizdi, Prijizdi, false);
}
//---------------------------------------------------------------------------
void __fastcall TFormPark::EditParkChange(TObject *Sender)
{
int r0;
 edch(selpark->Mpark, Park, false);
 r0=selpark->R;
 selpark->spoctiR();
 if(r0!=selpark->R) zmenaR();
}
//---------------------------------------------------------------------------

