//---------------------------------------------------------------------------
#ifndef krizformH
#define krizformH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\ComCtrls.hpp>
//---------------------------------------------------------------------------
#include "autasim.h"

#define Msemaf 16

class TFormKriz : public TFormE
{
__published:	// IDE-managed Components
	TEdit *EditD;
	TEdit *EditL;
	TEdit *EditS;
	TEdit *EditR;
	TSpeedButton *ButtonLeft;
	TSpeedButton *ButtonRight;
	TUpDown *DelOdboc;
	TUpDown *Vlevo;
	TUpDown *Rovne;
	TUpDown *Vpravo;
	TLabel *LabelL;
	TLabel *LabelS;
	TLabel *LabelR;
 TLabel *Label4;
	TCheckBox *Jesemaf;
	TPaintBox *PaintBox1;
	TPanel *PanelSemaf;
	TSpeedButton *ButtonUp;
	TSpeedButton *ButtonDown;
	TLabel *Celkem;
	TLabel *Label7;
	TLabel *Label8;
	TLabel *Label9;
	TLabel *Label10;
	TSpeedButton *ButtonNew;
	TSpeedButton *ButtonDel;
	TEdit *EditZ;
	TUpDown *Zacatek;
	TScrollBox *ScrollBox1;
	TPaintBox *PaintBox2;
	TLabel *Label1;
	TBevel *Bevel2;
	TCheckBox *LSpolec;
	TCheckBox *RSpolec;
	TBevel *Bevel1;
	TSpeedButton *BtnKrizem;
	TSpeedButton *BtnPravaRuka;
	TSpeedButton *BtnHlavVedlR;
	TSpeedButton *BtnHlavVedlL;
	TCheckBox *Viceurovn;
	TSpeedButton *SpeedButton1;
	TSpeedButton *SpeedButton2;
	TSpeedButton *SpeedButton3;
	void __fastcall ButtonRightClick(TObject *Sender);
	void __fastcall JesemafClick(TObject *Sender);
	void __fastcall PaintBox1Paint(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall ButtonLeftClick(TObject *Sender);
	void __fastcall ButtonNewClick(TObject *Sender);
	void __fastcall ButtonDelClick(TObject *Sender);
	void __fastcall ButtonUpClick(TObject *Sender);
	void __fastcall ButtonDownClick(TObject *Sender);
	void __fastcall PaintBox2MouseDown(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y);
	void __fastcall LSpolecClick(TObject *Sender);
	void __fastcall RSpolecClick(TObject *Sender);
	void __fastcall EditKeyPress(TObject *Sender, char &Key);
	void __fastcall EditClick(TObject *Sender);
	void __fastcall PaintBox1MouseDown(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y);
	void __fastcall BtnHlavVedlRClick(TObject *Sender);
	void __fastcall BtnHlavVedlLClick(TObject *Sender);
	void __fastcall ViceurovnClick(TObject *Sender);
	void __fastcall BtnPravaRukaClick(TObject *Sender);
	void __fastcall BtnKrizemClick(TObject *Sender);
	void __fastcall EditZChange(TObject *Sender);
	void __fastcall EditLChange(TObject *Sender);
	void __fastcall EditSChange(TObject *Sender);
	void __fastcall EditRChange(TObject *Sender);
	void __fastcall EditDChange(TObject *Sender);
	void __fastcall SpeedButton1Click(TObject *Sender);
	void __fastcall SpeedButton2Click(TObject *Sender);
	void __fastcall SpeedButton3Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
  void UpdateAll();
  void UpdatePruhy();
  void UpdateSemaf();
  void UpdateCelkem();
  void setselsem(int i);
  void prohodsemaf();
  void __fastcall PaintSemaf(TObject *Sender);
  void __fastcall updwClick(TObject *Sender, TUDBtnType Button);
  void __fastcall boxClick(TObject *Sender);
  void __fastcall edEnter(TObject *Sender);
  void __fastcall edChange(TObject *Sender);
  virtual __fastcall TFormKriz(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TFormKriz *FormKriz;
//---------------------------------------------------------------------------
#endif
