//---------------------------------------------------------------------------
#ifndef parkformH
#define parkformH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>
//---------------------------------------------------------------------------
#include "autasim.h"

class TFormPark : public TFormE
{
__published:	// IDE-managed Components
	TLabel *Label3;
	TEdit *Edit1;
	TLabel *Label1;
	TEdit *EditH;
	TUpDown *Prijizdi;
	TLabel *LabelPark;
	TEdit *EditPark;
	TUpDown *Park;
	
	
	
	void __fastcall EditKeyPress(TObject *Sender, char &Key);
	
	
	void __fastcall Edit1Exit(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall EditHChange(TObject *Sender);
	void __fastcall EditParkChange(TObject *Sender);
private:	// User declarations
public:		// User declarations
	void UpdateAll();
	virtual __fastcall TFormPark(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TFormPark *FormPark;
//---------------------------------------------------------------------------
#endif
