//---------------------------------------------------------------------------
#ifndef autasimH
#define autasimH
//---------------------------------------------------------------------------

#define MAXDS 6

class Tuzel;

typedef char Tjmeno[20];
typedef char TcisSilnice[10];

struct Tpos
{
 int x,y;
 operator==(Tpos &p2){ return x==p2.x && y==p2.y;};
 operator!=(Tpos &p2){ return x!=p2.x || y!=p2.y;};
};

class Tauto
{
 public:
  Tauto* nxt; //n�sleduj�c� auto
  int d;      //vzd�lenost od p�edchoz�ho auta
  short X,Y,X2,Y2,X3,Y3; //sou�adnice na obrazovce (v bodech)
  int barva;
  int cil;  //��slo c�le, kam jede
  int smer; //odkud p�ij�d� ke k�i�ovatce
  Tauto();
  void smaz();
};

struct Tzatacka
{
  Tzatacka *nxt;
  Tpos pos;     //sou�adnice ve m�st� (v metrech)
  double px,py; //posunut� na dal�� pruhy
  Tzatacka(){};
  Tzatacka(Tpos p,Tzatacka* n):pos(p),nxt(n){};
};

struct Tsemafory
{
  Tsemafory* nxt;
  int id;          //��slo stavu
  short interval;  //doba trv�n� v sekund�ch
  Tsemafory(){};
  Tsemafory(int i);
};

struct Tfronta
{
  Tauto *auta, **autok; //prvn� a posledn� auto ve front�
  Tauto *auton;   //nov� auto, co p�ijelo p�ed zpracov�n�m fronty
  Tauto *autol;   //n�sleduj�c� auta jedou plynule bez br�d�n�
  int dk;         //vzd�lenost za posledn�m
  Tfronta():auta(0),autok(&auta),auton(0),autol(0){};
  ~Tfronta();
};

class Tsilnice
{
 public:
  Tuzel *uzel;    //Parent
  Tsilnice* opac; //opa�n� sm�r silnice
  short delodboc; //d�lka v�tven� p�ed k�i�ovatkou, pro vstup/park. je zde 0
  short pruhu0;   //po�et pruh� silnice
  short rychlost; // 3= 50km/h
  Tsilnice *nxt;
  Tsilnice **pre; //pro Dijkstra
  Tzatacka* zatacky; //seznam zat��ek

  bool selected;
  Tfronta* fronty;//ukaz. do pole front, nejd��v silnice, pak v�tven�
  int delka;      //celkov� d�lka silnice v metrech
  int t;          //pro Dijkstra, p�i simulaci po�ad� zpracov�n�

  Tsilnice(Tuzel *);
  ~Tsilnice();
  Tzatacka * getZatac();
  void spoctiZatac(int b); //spo�te px,py v zat��k�ch, p�i b=0 oba sm�ry
  void zruszatac();   //odstran� v�echny mal� zat��ky
  int spoctidelku();  //d�lka prost�edku silnice
  int delkaP(int m);  //d�lka m-t�ho pruhu
  void paint();
  void paint2(); //oba sm�ry
  void autapaint(); //zobraz� auta
  void Save();
  void Load();
  int getSmer();
  __property int smer={read=getSmer};
};

class Tpruhy : public Tsilnice
{
 public:
  short pruhu[4]; //po�ty pruh�: [1]=vpravo,[2]=rovn�,[3]=vlevo
  bool lspolec,rspolec; //spole�n� pruh pro rovn� a vlevo/vpravo
  __property int pruhu1={read=getPruhu1}; //po�et pruh� p�ed k�i�ovatkou

  char *trasa; //pro pruhu0!=0 ukazuje na pole char[Dcile] se sm�ry

  Tpruhy(Tuzel *);
  int getPruhu1();
};

#define KONEC 0
#define VSTUP 1
#define PARK 2
#define CIL 3
#define KRIZ 4
#define PRECHOD 8
#define SEMAF 12

class Tuzel
{
 public:
  Tsilnice *s[MAXDS];
  Tuzel *nxt;
  int Ds;  //stupe�
  int typ; //vstup|parkovi�t�|k�i�ovatka|pomocn� uzel
  Tpos pos;//sou�adnice (v metrech)

  int t;   //pro Dijkstra
  int tag; //��slo c�le (nejd��v vstupy, pak parkovi�t�), po�ad� v souboru
  int R;   //polom�r
  bool selected; //vybr�n

  Tuzel();
  virtual ~Tuzel();
  virtual int paint();            //nakresl� uzel
  virtual void spoctiR();         //velikost uzle
  virtual Tsilnice* pridejsmer(); //p�id� novou silnici
  virtual void ubersmer(int smer);//sma�e silnici uzel->s[smer]
  virtual void setrid();   //se�ad� silnice proti sm�ru hodin. ru�i�ek
  virtual void start(){};  //spu�t�n� simulace
  double uhel(int smer);   //sm�rov� �hel silnice
  bool naZatac();          //p�ed�l�n� uzle stupn� 2 na zat��ku
};

class Tkonec : public Tuzel
{
 public:
  Tkonec *nxt;

  Tkonec();
  ~Tkonec();
  virtual Tsilnice* pridejsmer();
};

class Tcil : public Tuzel
{
 public:
  Tjmeno jmeno;   //n�zev
  short prijizdi; //mno�stv� proj�d�j�c�ch aut za minutu

  int prijelo,vyjelo;
  int Iprojede; //po��tadlo
  double u;     //pro set��d�n� podle �hlu od st�edu mapy
  char *trasa;  //ukazuje na pole char[Dcile] se sm�ry

  Tcil();
  virtual ~Tcil();
  virtual int paint(); //zobraz� tak� jmeno
  void start();
};

class Tvstup : public Tcil
{
 public:
  Tvstup *nxt;
  TcisSilnice cislo;

  Tvstup();
  ~Tvstup();
  virtual Tsilnice* pridejsmer();
};

class Tpark : public Tcil
{
 public:
  Tpark *nxt;
  short Mpark;  //velikost parkovi�t�

  int parkaut;  //po�et zaparkovan�ch aut

  Tpark();
  ~Tpark();
  void start();
  virtual void spoctiR();
};

class Tuzelsemaf : public Tuzel
{
 public:
  short caszmen0;   //za��tek semafor� (v sekund�ch)
  bool jesemaf;     //zapnuty semafory

  int caszmen;      //�as p��t� zm�ny semafor�
  unsigned volno;   //sv�tla na semaforech
  int projelo;      //kolik projelo aut od spu�t�n� simulace

  Tuzelsemaf();
  void paintSemaf();
};

class Tprechod : public Tuzelsemaf
{
 public:
  Tprechod *nxt;
  short chodci,auta,tlacitko; //doba zelen� na semaforu (v sekund�ch)

  Tprechod();
  ~Tprechod();
  void start();
  virtual Tsilnice* pridejsmer();
  virtual void ubersmer(int smer);
};

class Tkriz : public Tuzelsemaf
{
 public:
  Tkriz *nxt;
  int hlavni;       //typ hlavn� silnice
  bool viceurovn;   //v�ce�rov�ov�
  Tsemafory *semaf;//seznam semafor�

  Tsemafory *stav;  //aktu�ln� stav semafor�
  unsigned jeauto;

  Tkriz();
  ~Tkriz();
  void start();
  void prohod(int smer);
  virtual void spoctiR();
  virtual Tsilnice* pridejsmer();
  virtual void ubersmer(int smer);
  virtual void setrid();
  Tpruhy** Gets(){ return (Tpruhy**)Tuzel::s;}
  __property Tpruhy **s={read=Gets};
};

struct TUsiln
{
 Tsilnice *c;
 TUsiln *nxt;
 TUsiln(Tsilnice *_c):c(_c){};
};

class TFormE : public TForm
{
 public:
 __fastcall TFormE(TComponent* Owner): TForm(Owner){};
  virtual void UpdateAll()=0;
  virtual void update(){};
};

class TFormInfo : public TFormE
{
 public:
 __fastcall TFormInfo(TComponent* Owner): TFormE(Owner){};
};

//---------------------------------------------------------------------------

//funkce
void startsim();
void resetsim();
void kroksim();
double vzdalenost(Tpos p1,Tpos p2);
void prekresli();
void zmenaR();
void UpdateForms();
void activMain();

//prom�nn�
extern Tuzel* uzly;
extern Tkriz* krizovatky;
extern Tprechod* prechody;
extern Tkonec* konce;
extern Tvstup* vstupy;
extern Tpark* parkoviste;
extern Tsilnice* silnice;

extern Tuzel *seluzel;
extern Tkriz *selkriz;
extern Tvstup *selvstup;
extern Tpark *selpark;
extern Tprechod *selprechod;
extern TUsiln *selsiln;
extern Tauto *selauto;

extern bool sim;
extern int cas;
extern bool modif;

extern int mapLeft,mapRight, mapTop,mapBottom;
extern Tfronta* Afronty;
extern int Dcile,Dfronty;
extern int Daut,Nvyjelo,Nprijelo;
extern Tauto *kos, *odjela;

//norm�ln� ���ka j�zdn�ho pruhu (m)
#define DPRUHU 2.8
//---------------------------------------------------------------------------

#include "list1.h"

template <class T> inline T sqr(const T x)
{
 return x*x;
}

template <class T> inline void amin(T &a,T b)
{
 if(b>a) a=b;
}

template <class T> inline void amax(T &a,T b)
{
 if(b<a) a=b;
}

#if !defined( __MINMAX_DEFINED)
#define __MINMAX_DEFINED
template <class T> inline const T _FAR &min(const T _FAR &t1, const T _FAR &t2)
{
 if(t1<t2) return t1; else return t2;
}
template <class T> inline const T _FAR &max(const T _FAR &t1, const T _FAR &t2)
{
 if(t1>t2) return t1; else return t2;
}
#endif
//---------------------------------------------------------------------------
#endif
