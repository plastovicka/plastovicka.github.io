//---------------------------------------------------------------------------
#ifndef prechfrmH
#define prechfrmH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>
#include <vcl\ExtCtrls.hpp>
//---------------------------------------------------------------------------
#include "autasim.h"

class TFormPrechod : public TFormE
{
__published:	// IDE-managed Components
	TCheckBox *Jesemaf;
	TPanel *PanelSemaf;
	TPanel *Panel1;
	TLabel *Label4;
	TEdit *Edit1;
	TUpDown *Chodci;
	TPanel *Panel2;
	TLabel *Label6;
	TEdit *Edit2;
	TUpDown *Auta;
	TPanel *Panel3;
	TLabel *Label9;
	TEdit *Edit3;
	TUpDown *Tlacitko;
	TPanel *Panel4;
	TLabel *Label7;
	TLabel *Celkem;
	TPanel *Panel5;
	TLabel *Label8;
	TEdit *EditZ;
	TUpDown *Zacatek;
	void __fastcall EditKeyPress(TObject *Sender, char &Key);
	void __fastcall Edit1Change(TObject *Sender);
	void __fastcall Edit2Change(TObject *Sender);
	void __fastcall Edit3Change(TObject *Sender);
	void __fastcall EditZChange(TObject *Sender);
	
	
	
	
	void __fastcall JesemafClick(TObject *Sender);
	
private:	// User declarations
public:		// User declarations
 void UpdateAll();
 void UpdateCelkem();
	virtual __fastcall TFormPrechod(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TFormPrechod *FormPrechod;
//---------------------------------------------------------------------------
#endif
