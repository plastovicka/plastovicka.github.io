//---------------------------------------------------------------------------
#ifndef krizinfoH
#define krizinfoH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
//---------------------------------------------------------------------------
#include "autasim.h"

class TInfoKriz : public TFormInfo
{
__published:	// IDE-managed Components
	TPanel *Panel1;
	TPaintBox *PaintBox1;
	TLabel *Label2;
	TLabel *LabelCas;
	TLabel *LabelInt;
	TLabel *Label6;
	TLabel *Label1;
	TPaintBox *PaintBox2;
	TLabel *Projelo;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Souradnice;
	void __fastcall PaintBox1Paint(TObject *Sender);
	
	void __fastcall PaintBox2Paint(TObject *Sender);
private:	// User declarations
public:		// User declarations
 void update();
 void UpdateAll();
	virtual __fastcall TInfoKriz(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TInfoKriz *InfoKriz;
//---------------------------------------------------------------------------
#endif
