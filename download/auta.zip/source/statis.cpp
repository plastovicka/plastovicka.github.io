/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "statis.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TFormStatis *FormStatis;
//---------------------------------------------------------------------------
__fastcall TFormStatis::TFormStatis(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall setnum(TLabel* l,int i)
{
 l->Caption= IntToStr(i);
}
//---------------------------------------------------------------------------
void __fastcall setnumm(TLabel* l,int i)
{
int m=i%1000;
AnsiString a;

 if(i<1000){
   l->Caption= IntToStr(i)+" m";
 }else{
   if(m<10) a=" 00";
   else if(m<100) a=" 0";
   else a=" ";
   l->Caption= IntToStr(i/1000) + a + IntToStr(m) + "  m";
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormStatis::FormShow(TObject *Sender)
{
Tkriz *k;
Tvstup *v;
Tpark *r;
Tkonec *o;
Tsilnice *c;
int Dk,Dv,Dp,Dc,d;

 d=Dk=Dv=Dp=Dc=0;
 fors(c,silnice) if(c->zatacky){ Dc++; d+= c->spoctidelku(); }
 fors(k,krizovatky) Dk++;
 fors(o,konce) Dk++;
 fors(v,vstupy) Dv++;
 fors(r,parkoviste) Dp++;

 setnum(LabelDk,Dk);
 setnum(LabelDv,Dv);
 setnum(LabelDc,Dc);
 setnum(LabelDp,Dp);
 setnumm(LabelDelka,d);
 setnumm(LabelSirka,mapRight-mapLeft);
 setnumm(LabelVyska,mapBottom-mapTop);
}
//---------------------------------------------------------------------------
