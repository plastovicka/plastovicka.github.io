/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include "vstupfrm.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TFormVstup *FormVstup;
Tvstup *selvstup;

extern int changing;
extern void edch(short &p,TUpDown *h,bool repaint);
//---------------------------------------------------------------------------
__fastcall TFormVstup::TFormVstup(TComponent* Owner)
	: TFormE(Owner){}
//---------------------------------------------------------------------------
void TFormVstup::UpdateAll()
{
 changing++;
 Prijizdi->Position= selvstup->prijizdi;
 Edit1->Text= selvstup->jmeno;
 Edit2->Text= selvstup->cislo;
 changing--;
}
//---------------------------------------------------------------------------
void __fastcall TFormVstup::EditKeyPress(TObject *Sender, char &Key)
{
 if(Key==13){
   ActiveControl=0;
   activMain();
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormVstup::FormCreate(TObject *Sender)
{
 Edit1->MaxLength= sizeof(Tjmeno)-1;
 Edit2->MaxLength= sizeof(TcisSilnice)-1;
}
//---------------------------------------------------------------------------
void __fastcall TFormVstup::Edit1Exit(TObject *Sender)
{
 if(strcmp(selvstup->jmeno,Edit1->Text.c_str())){
   strcpy(selvstup->jmeno,Edit1->Text.c_str());
   modif=true;
   prekresli();
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormVstup::Edit2Exit(TObject *Sender)
{
 if(strcmp(selvstup->cislo,Edit2->Text.c_str())){
   strcpy(selvstup->cislo,Edit2->Text.c_str());
   modif=true;
   prekresli();
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormVstup::EditHChange(TObject *Sender)
{
 edch(selvstup->prijizdi, Prijizdi, false);
}
//---------------------------------------------------------------------------


