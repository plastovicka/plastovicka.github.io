/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include <math.h>
#include "prechfrm.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TFormPrechod *FormPrechod;
Tprechod *selprechod;

extern int changing;
extern void edch(short &p,TUpDown *h,bool repaint);
extern void cbch(bool &p,TCheckBox *h,bool repaint);
extern int tabrych[];
//---------------------------------------------------------------------------
__fastcall TFormPrechod::TFormPrechod(TComponent* Owner)
	: TFormE(Owner)
{
}
//---------------------------------------------------------------------------
void TFormPrechod::UpdateCelkem()
{
 Celkem->Caption= IntToStr(selprechod->chodci + selprechod->auta + selprechod->tlacitko);
}
//---------------------------------------------------------------------------
void TFormPrechod::UpdateAll()
{
 changing++;
 Chodci->Position= selprechod->chodci;
 Auta->Position= selprechod->auta;
 Tlacitko->Position= selprechod->tlacitko;
 UpdateCelkem();
 Zacatek->Position=selprechod->caszmen0;
 Jesemaf->Checked= selprechod->jesemaf;
 changing--;
}
//---------------------------------------------------------------------------
void __fastcall TFormPrechod::EditKeyPress(TObject *Sender, char &Key)
{
 if(Key==13){
   ActiveControl=0;
   activMain();
 }
}
//---------------------------------------------------------------------------
void __fastcall TFormPrechod::Edit1Change(TObject *Sender)
{
 edch(selprechod->chodci,Chodci,false);
 UpdateCelkem();
}
//---------------------------------------------------------------------------
void __fastcall TFormPrechod::Edit2Change(TObject *Sender)
{
 edch(selprechod->auta,Auta,false);
 UpdateCelkem();
}
//---------------------------------------------------------------------------
void __fastcall TFormPrechod::Edit3Change(TObject *Sender)
{
 edch(selprechod->tlacitko,Tlacitko,false);
 UpdateCelkem();
}
//---------------------------------------------------------------------------
void __fastcall TFormPrechod::EditZChange(TObject *Sender)
{
 edch(selprechod->caszmen0,Zacatek,false);
}
//---------------------------------------------------------------------------
void __fastcall TFormPrechod::JesemafClick(TObject *Sender)
{
 cbch(selprechod->jesemaf, (TCheckBox*)Sender, false);
 PanelSemaf->Visible= selprechod->jesemaf;
}
//---------------------------------------------------------------------------
