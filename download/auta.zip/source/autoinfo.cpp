/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "autoinfo.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TInfoAuto *InfoAuto;
Tauto *selauto= 0;

extern char * intToCas(int);
extern int __fastcall calxm(int x);
extern int __fastcall calym(int y);

//---------------------------------------------------------------------------
__fastcall TInfoAuto::TInfoAuto(TComponent* Owner)
	: TFormE(Owner){
}
//---------------------------------------------------------------------------
void TInfoAuto::update()
{
int t;
static int sec=0;

if(selauto){
 if(selauto->X<0) Souradnice->Caption= "???";
 else Souradnice->Caption= "[" + IntToStr(calxm(selauto->X)) + ", "
    + IntToStr(calym(selauto->Y)) + "]";
 LabelPred->Caption= IntToStr(selauto->d);
 LabelZa->Caption= IntToStr(selauto->nxt ? selauto->nxt->d : 0);
 t=(cas-cas0)/5;
 if(t!=sec){
   LabelCas->Caption= intToCas(sec=t);
 }
}
}
//---------------------------------------------------------------------------
void TInfoAuto::UpdateAll()
{
Tcil *cil;
Tpark *r;
Tvstup *v;
AnsiString s;

 if(selauto){
  update();
  s="";
  cil=0;
  fors(v,vstupy) if(v->tag==selauto->cil) cil=v;
  fors(r,parkoviste) if(r->tag==selauto->cil) cil=r;
  if(cil){
   s=cil->jmeno;
   if(s.IsEmpty()){
     s= cil->typ==PARK ? "Parkovi�t� " : "V�stup z m�sta";
     s= s + " [" + IntToStr(cil->pos.x) + ", "
        + IntToStr(cil->pos.y) + "]";
     LabelCil->Font->Size=10;
   }else{
     LabelCil->Font->Size=12;
   }
  }
  LabelCil->Caption= s;
 }
}
//---------------------------------------------------------------------------
