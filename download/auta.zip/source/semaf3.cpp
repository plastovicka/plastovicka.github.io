/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include "semaf3.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TFormSemaf3 *FormSemaf3;
void __fastcall PaintSemaf1(TPaintBox* b,bool s);
//---------------------------------------------------------------------------
__fastcall TFormSemaf3::TFormSemaf3(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormSemaf3::FormKeyDown(TObject *Sender, WORD &Key,
	TShiftState Shift)
{
 if(Key==VK_LEFT) if((--sel)<1) sel=3;
 if(Key==VK_RIGHT) if((++sel)>3) sel=1;
 if(Key==VK_RETURN || Key==VK_SPACE) ModalResult=mrOk;
 if(Key==VK_ESCAPE) ModalResult=mrCancel;
 Panel1->Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TFormSemaf3::PaintBox1Paint(TObject *Sender)
{
 PaintSemaf1((TPaintBox*)Sender,((TPaintBox*)Sender)->Tag==sel);
}
//---------------------------------------------------------------------------
void __fastcall TFormSemaf3::FormShow(TObject *Sender)
{
 sel=1;
}
//---------------------------------------------------------------------------
void __fastcall TFormSemaf3::PaintBox1MouseUp(TObject *Sender,
	TMouseButton Button, TShiftState Shift, int X, int Y)
{
  if(X>0 && Y>0 && X<40 && Y<40) ModalResult=mrOk;
}
//---------------------------------------------------------------------------
void __fastcall TFormSemaf3::PaintBox1MouseDown(TObject *Sender,
	TMouseButton Button, TShiftState Shift, int X, int Y)
{
 sel=((TPaintBox*)Sender)->Tag;
 Panel1->Invalidate();
}
//---------------------------------------------------------------------------
