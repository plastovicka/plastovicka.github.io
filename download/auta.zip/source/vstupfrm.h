//---------------------------------------------------------------------------
#ifndef vstupfrmH
#define vstupfrmH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>
#include <vcl\ExtCtrls.hpp>
//---------------------------------------------------------------------------
#include "autasim.h"

class TFormVstup : public TFormE
{
__published:	// IDE-managed Components
	TEdit *EditH;
	TUpDown *Prijizdi;
	TLabel *Label1;
	TEdit *Edit1;
	TLabel *Label3;
	TLabel *Label4;
	TEdit *Edit2;
	
	
	
	
	void __fastcall EditKeyPress(TObject *Sender, char &Key);
	
	
	
	
	
	void __fastcall Edit1Exit(TObject *Sender);

	
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall Edit2Exit(TObject *Sender);
	void __fastcall EditHChange(TObject *Sender);
	
private:	// User declarations
public:		// User declarations
	void UpdateAll();
 virtual __fastcall TFormVstup(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TFormVstup *FormVstup;
//---------------------------------------------------------------------------
#endif
