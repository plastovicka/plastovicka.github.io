/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include "parkinfo.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TInfoPark *InfoPark;
//---------------------------------------------------------------------------
__fastcall TInfoPark::TInfoPark(TComponent* Owner)
	: TFormInfo(Owner)
{
}
//---------------------------------------------------------------------------
void TInfoPark::update()
{
 LabelPrijelo->Caption= IntToStr(selpark->prijelo);
 Park->Caption= IntToStr(selpark->parkaut);
}
//---------------------------------------------------------------------------
void TInfoPark::UpdateAll()
{
 update();
 Caption= selpark->jmeno;
 Prijizdi->Caption= IntToStr(selpark->prijizdi);
 Souradnice->Caption= "[" + IntToStr(selpark->pos.x) + ", "
    + IntToStr(selpark->pos.y) + "]";
}
//---------------------------------------------------------------------------
