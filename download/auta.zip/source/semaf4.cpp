/*
 (C) 2000  Petr Lastovicka

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include "semaf4.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TFormSemaf4 *FormSemaf4;
void __fastcall PaintSemaf1(TPaintBox* b,bool s);
//---------------------------------------------------------------------------
__fastcall TFormSemaf4::TFormSemaf4(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormSemaf4::PaintBox1Paint(TObject *Sender)
{
 PaintSemaf1((TPaintBox*)Sender,((TPaintBox*)Sender)->Tag==sel);
}
//---------------------------------------------------------------------------
void __fastcall TFormSemaf4::FormKeyDown(TObject *Sender, WORD &Key,
	TShiftState Shift)
{
 if(Key==VK_LEFT) if((--sel)<4) sel=11;
 if(Key==VK_RIGHT) if((++sel)>11) sel=4;
 if(Key==VK_RETURN || Key==VK_SPACE) ModalResult=mrOk;
 if(Key==VK_ESCAPE) ModalResult=mrCancel;
 Panel1->Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TFormSemaf4::FormShow(TObject *Sender)
{
 sel=4;
}
//---------------------------------------------------------------------------
void __fastcall TFormSemaf4::PaintBox1MouseUp(TObject *Sender,
	TMouseButton Button, TShiftState Shift, int X, int Y)
{
  if(X>0 && Y>0 && X<40 && Y<40) ModalResult=mrOk;
}
//---------------------------------------------------------------------------
void __fastcall TFormSemaf4::PaintBox1MouseDown(TObject *Sender,
	TMouseButton Button, TShiftState Shift, int X, int Y)
{
 sel=((TPaintBox*)Sender)->Tag;
 Panel1->Invalidate();
}
//---------------------------------------------------------------------------