//---------------------------------------------------------------------------
#ifndef silnformH
#define silnformH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>
//---------------------------------------------------------------------------
#include "autasim.h"
#include <vcl\ExtCtrls.hpp>
#include <vcl\Buttons.hpp>

class TFormSiln : public TFormE
{
__published:	// IDE-managed Components
	TPanel *Panel1;
	TPaintBox *PaintBox0;
	TLabel *Label6;
	TLabel *LabelPruh0;
	TUpDown *Pruhu0;
	TLabel *LabelRych0;
	TLabel *Label7;
	TUpDown *Rychlost0;
	TPanel *Panel2;
	TPaintBox *PaintBox1;
	TLabel *Label12;
	TLabel *LabelPruh1;
	TLabel *LabelRych1;
	TLabel *Label15;
	TUpDown *Pruhu1;
	TUpDown *Rychlost1;
	TPanel *Panel3;
	TBevel *Bevel2;
	TBevel *Bevel1;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *LabelRych;
	TLabel *LabelPruh;
	TUpDown *Rychlost;
	TUpDown *Pruhu;
	TLabel *Label3;
	TLabel *LabelDelka;
	TSpeedButton *SpeedButton1;
	void __fastcall PruhuClick(TObject *Sender, TUDBtnType Button);
	void __fastcall RychlostClick(TObject *Sender, TUDBtnType Button);
	void __fastcall Pruhu0Click(TObject *Sender, TUDBtnType Button);
	void __fastcall Rychlost0Click(TObject *Sender, TUDBtnType Button);
	void __fastcall Pruhu1Click(TObject *Sender, TUDBtnType Button);
	void __fastcall Rychlost1Click(TObject *Sender, TUDBtnType Button);
	void __fastcall PaintBox1Paint(TObject *Sender);
	void __fastcall SpeedButton1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
 void UpdateAll();
 void UpdateLabel();
	virtual __fastcall TFormSiln(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TFormSiln *FormSiln;
//---------------------------------------------------------------------------
#endif
