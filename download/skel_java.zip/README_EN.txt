How to create your own AI
-------------------------
Replace file RandomAlg.java with your own algorithm. File GomokuInterface.java contains communication between your AI and the game manager and it is not recommended to modify that file, because it might be changed in future protocol versions.
More information about the protocol and tournament rules can be found at http://gomocup.org
