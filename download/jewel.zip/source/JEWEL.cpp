/*
(C)  Petr La�tovi�ka
 
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.

7.1998
1.2003 skins, variable block length
3.2004 languages
*/
//---------------------------------------------------------------------------
#include <windows.h>
#pragma hdrstop
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "lang.h"
/*
 USERC("Jewel.rc");
*/
//---------------------------------------------------------------------------
#ifndef __BORLANDC__
inline int random(int num){ return(int)(((long)rand()*num)/(RAND_MAX+1));}
#endif
template <class T> inline void amin(T &x,int m){ if(x<m) x=m; }
template <class T> inline void amax(T &x,int m){ if(x>m) x=m; }
template <class T> inline void aminmax(T &x,int l,int h){
 if(x<l) x=l;
 if(x>h) x=h;
}
#define sizeA(A) (sizeof(A)/sizeof(*A))
#define endA(a) (a+(sizeof(a)/sizeof(*a)))

#define BM_NUM 11
#define maxx 20
#define maxy 50
#define maxb 8

bool
 fast,
 pending,
 start=true,
 closing=false,
 delreg=false,
 playing=false;

int
 width=8,	//number of columns
 height=20,	//number of rows
 left=100,
 top=10,
 widthW=280,	//window width
 heightW=560,	//window height
 widthB,heightB,
 Ncolors=7,	 //number of colors/symbols
 speed=1000, //timer (ms)
 Dblock=3,	 //block height in squares
 Dmatch=3,
 titleTimer=5000,
 score,		//score
 r,s,		//current block coordinates (row,column)
 dr,
 bmH,bmW;	//square size (pixels)

short
 p[maxx][maxy],	//board
 k[maxb],	    //current block colors
 knext[maxb];	//next block colors

typedef char TfileName[MAX_PATH];
TfileName fnskin;

enum{ clBkgnd,clBox,clNext,clScore,clNumber };
static COLORREF colors[]={ 0, 0x00ff00, 0xff8000, 0xa0a0a0, 0xffffff };

char *title="Jewel";
const char *subkey="Software\\Petr Lastovicka\\jewel";
struct Treg { char *s; int *i; } regVal[]={
{"vyska",&height},{"sirka",&width},
{"X",&left},{"Y",&top},
{"barev",&Ncolors},{"rychlost",&speed},
{"blok",&Dblock},{"match",&Dmatch},
};
struct Tregs { char *s; char *i; DWORD n; } regValS[]={
 {"skin",fnskin,sizeof(fnskin)},
 {"language",lang,sizeof(lang)},
};

HWND hWin;
HINSTANCE inst;
HBITMAP bm;
HDC dc,bmpdc;
HACCEL haccel;

OPENFILENAME skinOfn={
 sizeof(OPENFILENAME),0, 0,0,0,0,1,
 fnskin, sizeof(fnskin),
 0,0,0, 0, 0,0,0, "BMP", 0,0,0
};
//---------------------------------------------------------------------------
void msg(char *text, ...)
{
 char buf[1024];
 va_list ap;
 va_start(ap,text);
 vsprintf(buf,text,ap);
 MessageBox(hWin,buf,title,MB_OK|MB_ICONERROR);
 va_end(ap);
}

void langChanged()
{
 static int menuSubId[]={402,401,400};
 loadMenu(hWin,"MENU1",menuSubId);
 skinOfn.lpstrFilter=lng(500,"Skins (*.bmp)\0*.bmp\0");
 RECT rc;
 SetRect(&rc,widthB+2,0,widthW,heightW);
 InvalidateRect(hWin,&rc,TRUE);
}
//---------------------------------------------------------------------------
char *loadSkin(HBITMAP fbmp)
{
 int w;
 BITMAP bmp;
 char *errs;

 if(!fbmp){
  errs= lng(700,"Cannot create bitmap for skin");
 }else{
  GetObject(fbmp,sizeof(BITMAP),&bmp);
  w= bmp.bmWidth;
  bmH= bmp.bmHeight;
  if((w-1)%11){
   errs=lng(701,"Bitmap does not contain five squares");
  }else{
    bmW=(w-1)/11;
    DeleteObject(SelectObject(bmpdc,fbmp));
    bm=fbmp;
    for(int i=0; i<5; i++){
      colors[i]= GetPixel(bmpdc,w-1,i);
    }
    SetBkColor(dc,colors[clBkgnd]);
    InvalidateRect(hWin,0,TRUE);
    errs=0;
  }
 }
 return errs;
}
//---------------------------------------------------------------------------
void setTitle(char *txt)
{
 char buf[256],*s;

 strcpy(buf, title);
 if(txt && *txt){
  strcat(buf," - ");
  s=strchr(txt,0);
  while(s>=txt && *s!='\\') s--;
  strcat(buf,s+1);
  s= strchr(buf,0);
  while(s>=buf && *s!='.') s--;
  if(*s=='.') *s=0;
  SetTimer(hWin,300,titleTimer,0);
 }
 SetWindowText(hWin,buf);
}
//---------------------------------------------------------------------------
char *loadSkin()
{
 BITMAPFILEHEADER hdr;
 HANDLE h;
 DWORD r,s;
 char *errs= lng(702,"Cannot load BMP file");

 h= CreateFile(fnskin, GENERIC_READ,FILE_SHARE_READ,
   0,OPEN_EXISTING,0,0);
 if(h!=INVALID_HANDLE_VALUE){
  ReadFile(h,&hdr,sizeof(BITMAPFILEHEADER),&r,0);
  if(r==sizeof(BITMAPFILEHEADER) && ((char*)&hdr.bfType)[0]=='B' && ((char*)&hdr.bfType)[1]=='M'){
   s = GetFileSize(h,0) - sizeof(BITMAPFILEHEADER);
   char *b= new char[s];
   if(b){
    ReadFile(h,b,s,&r,0);
    if(r==s){
     BITMAPINFOHEADER* info = (BITMAPINFOHEADER*)b;
     HBITMAP fbmp = CreateDIBitmap(dc, info, CBM_INIT,
      b+hdr.bfOffBits-sizeof(BITMAPFILEHEADER),
      (BITMAPINFO*)b, DIB_RGB_COLORS);
     errs= loadSkin(fbmp);
     if(errs){
      DeleteObject(fbmp);
     }else{
      setTitle(fnskin);
     }
    }
    delete[] b;
   }
  }
  CloseHandle(h);
 }
 return errs;
}
//---------------------------------------------------------------------------
void openSkin()
{
 skinOfn.hwndOwner= hWin;
 skinOfn.Flags= OFN_FILEMUSTEXIST|OFN_HIDEREADONLY|OFN_READONLY|OFN_NOCHANGEDIR;
 if(GetOpenFileName(&skinOfn)){
   char *err= loadSkin();
   if(err) msg(err);
 }else{
   if(CommDlgExtendedError()==FNERR_INVALIDFILENAME && *fnskin){
     *fnskin=0;
     openSkin();
   }
 }
}
//---------------------------------------------------------------------------
char *onlyExt(char *dest)
{
 char *s;

 if(!*fnskin) strcpy(fnskin,"skins\\");
 strcpy(dest, fnskin);
 for(s=strchr(dest,0); s>=dest && *s!='\\'; s--) ;
 s++;
 strcpy(s,"*.bmp");
 return fnskin + (s-dest);
}
//---------------------------------------------------------------------------
void prevSkin()
{
 WIN32_FIND_DATA fd;
 TfileName buf,prev;
 HANDLE h;
 char *t;
 int pass=0;

 t= onlyExt(buf);
 h= FindFirstFile(buf,&fd);
 if(h==INVALID_HANDLE_VALUE){
  openSkin();
 }else{
  *prev=0;
  do{
    if(!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)){
      if(!stricmp(t,fd.cFileName) || pass>10){
        strcpy(t, prev);
        if(!loadSkin()) break;
      }else{
        strcpy(prev, fd.cFileName);
      }
    }
    if(!FindNextFile(h,&fd)){
      FindClose(h);
      h = FindFirstFile(buf,&fd);
      pass++;
    }
  }while(pass<20);
  FindClose(h);
 }
}
//---------------------------------------------------------------------------
void nextSkin()
{
 WIN32_FIND_DATA fd;
 TfileName buf;
 HANDLE h;
 char *t;
 int pass=0;

 t= onlyExt(buf);
 h= FindFirstFile(buf,&fd);
 if(h==INVALID_HANDLE_VALUE){
  openSkin();
 }else{
  do{
    if(!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)){
      if(pass){
       strcpy(t, fd.cFileName);
       if(!loadSkin()) break;
      }
      else if(!stricmp(t,fd.cFileName)) pass++;
    }
    if(!FindNextFile(h,&fd)){
      FindClose(h);
      h = FindFirstFile(buf,&fd);
      pass++;
    }
  }while(pass<3);
  FindClose(h);
 }
}
//---------------------------------------------------------------------------
void textOut(int x, int y, char *s)
{
 TextOut(dc, x,y, s, (int)strlen(s));
}
//---------------------------------------------------------------------------
void addScore(int i)
{
 char buf[12];
 score+=i;
 sprintf(buf,"%d", score);
 SetTextColor(dc, colors[clNumber]);
 textOut((widthW+widthB)/2, heightW-100, buf);
}
//---------------------------------------------------------------------------
// x,y are in pixels
void paintSquare1(int x,int y,int b)
{
 BitBlt(dc, x,y, bmW, bmH, bmpdc, b*bmW,0, SRCCOPY);
}
//---------------------------------------------------------------------------
// x,y are column and row
void paintSquare(int x, int y, int b)
{
 int d=0;
 if(x==s && y>=r && y<r+Dblock && b) d-=dr;
 paintSquare1(x*bmW+1, y*bmH+d, b);
}

void paintSquare(int x,int y)
{
 paintSquare(x,y, p[x][y]);
}
//---------------------------------------------------------------------------
void set(int x,int y,short h)
{
 p[x][y]=h; //write
 paintSquare(x,y,h);  //show
}
//---------------------------------------------------------------------------
void paintNext()
{
 if(knext[0]){
  int x= (widthW+widthB-bmW)/2;
  for(int i=0; i<Dblock; i++){
    paintSquare1(x, 50+i*bmH, knext[i]);
  }
 }
}
//---------------------------------------------------------------------------
void newBlock()
{
 r=0;
 fast=false;
 SetTimer(hWin,10, speed, NULL);
 if(p[s=width/2][Dblock]){
   //game over
   KillTimer(hWin,10);
   playing=false;
 }
 do{
  for(int i=0; i<Dblock; i++){
   set(s,i,k[i]=knext[i]);  //show next block
   //Next:
   aminmax(Ncolors,2,10);
   knext[i]=(short)(random(Ncolors)+1);
  }
  paintNext();
 }while(!k[0]); //twice just after game start
}
//---------------------------------------------------------------------------
void testMatches()
{
 bool matched;
 int i,j,b,x,y,xs=0,ys=0,x2,y2,h,f;
 static bool o[maxx][maxy];

//fall
 if(r+Dblock>=height || p[s][r+Dblock]){
//remove matched squares
  for(;;){
   matched=false;
   memset(o,0,sizeof o);
   for(x=0; x<width; x++){
    y=height-1;
    while((h=p[x][y])!=0 && y>=0){
      for(i=0;i<4;i++){  // 4 directions
        switch(i){
         case 0: xs=1,ys=1; break;
         case 1:
         case 2: ys--; break;
         case 3: xs--;
        }
        //test if colors match
        for(x2=x,y2=y, j=1; ;x2+=xs,y2+=ys, j++){
          if(y2>=height || y2<0 || x2>=width || p[x2][y2]!=h) break;
          if(j==Dmatch){
            //mark block for removal
            for(x2=x,y2=y; j>0 ;x2+=xs,y2+=ys, j--){
              o[x2][y2]=true;
            }
            matched=true;
            break;
          }
        }
      }
      y--;
    }
   }
   if(!matched) break; //nothing to remove
   //hilite found squares
   for(f=0; f<3; f++){
     for(x=0; x<width; x++){
      for(y=height-1; y>=0; y--)
        if(o[x][y]){
          paintSquare(x,y, 11-p[x][y]);
        }
     }
     Sleep(80);
     UpdateWindow(hWin);
     for(x=0; x<width; x++){
      for(y=height-1; y>=0; y--)
        if(o[x][y]){
          paintSquare(x,y);
        }
     }
     Sleep(80);
     UpdateWindow(hWin);
   }
   for(;;){
     matched=false;
     //scroll column by pixels
     for(b=0; b<bmH; b++){
       Sleep(10);
       UpdateWindow(hWin);
       for(x=0; x<width; x++){
        for(y=height-1; y>=0; y--)
         if(o[x][y]){
           if(!b) paintSquare(x,y,0);
           for(i=y-1; i>=0 && p[x][i]; i--){
             paintSquare1(x*bmW+1, b+i*bmH+1, p[x][i]);
           }
           BitBlt(dc, x*bmW+1, b+(i+1)*bmH, bmW, 1, bmpdc, 0,b, SRCCOPY);
           matched=true;
           break;
         }
       }
     }
     if(!matched) break;
     //move values in array
     for(x=0; x<width; x++){
      for(y=height-1; y>=0; y--)
        if(o[x][y]){
          addScore(25);
          for(i=y; i>0; i--){
            p[x][i]=p[x][i-1];
            o[x][i]=o[x][i-1];
          }
          p[x][0]=0;
          o[x][0]=false;
          break;
        }
     }
   }
  }
  newBlock();
  pending=true;
 }
}
//---------------------------------------------------------------------------
void moveDown()
{
 int i;
 MSG mesg;

 testMatches();
 addScore(1);
 dr=bmH-1;
 p[s][r]=0;
 r++;
 for(i=Dblock-1; i>=0; i--) p[s][r+i]=k[i];
//move current block down
 for(;;){
   BitBlt(dc, s*bmW+1, r*bmH-dr-1, bmW, 1, bmpdc, 0,bmH-dr-1, SRCCOPY);
   for(i=Dblock-1; i>=0; i--){
     paintSquare(s,r+i);
   }
   if(!dr) break;
   while(PeekMessage(&mesg, NULL, 0, 0, PM_REMOVE)){
     if(TranslateAccelerator(hWin,haccel,&mesg)==0){
       TranslateMessage(&mesg);
       DispatchMessage(&mesg);
     }
   }
   if(!fast) Sleep(speed/bmH);
   dr--;
 }
 testMatches();
}
//---------------------------------------------------------------------------
void newGame()
{
 aminmax(Dblock,1,maxb);
 aminmax(width,3,maxx);
 aminmax(height,Dblock+5,maxy);
 aminmax(Dmatch,2,width);
 memset(p,0,sizeof p);
 knext[0]=0;   //for newBlock() to set next block
 score=0;
 InvalidateRect(hWin,0,TRUE); //redraw
 newBlock();                  //start game
 playing=true;
 start=false;
}
//---------------------------------------------------------------------------
void repaint()
{
 int x,y;
 HGDIOBJ penOld;

 penOld= SelectObject(dc, CreatePen(PS_SOLID,1,colors[clBox]));
 MoveToEx(dc,0,0,0);
 LineTo(dc,0,heightB);
 LineTo(dc,widthB+1,heightB);
 LineTo(dc,widthB+1,-1);
 DeleteObject(SelectObject(dc,penOld));

 addScore(0);
 SetTextColor(dc, colors[clNext]);
 textOut(widthW-65, 20, lng(710,"Next:"));
 SetTextColor(dc, colors[clScore]);
 textOut(widthW-65, heightW-130, lng(711,"Score:"));

 paintSquare(s,r+Dblock-1,0);
 for(x=0; x<width; x++)
  for(y=0; y<height; y++)
    paintSquare(x,y);
 paintNext();
}
//---------------------------------------------------------------------------
void deleteini()
{
 HKEY key;
 DWORD i;

 delreg=true;
 if(RegDeleteKey(HKEY_CURRENT_USER, subkey)==ERROR_SUCCESS){
  if(RegOpenKey(HKEY_CURRENT_USER,
    "Software\\Petr Lastovicka",&key)==ERROR_SUCCESS){
   i=1;
   RegQueryInfoKey(key,0,0,0,&i,0,0,0,0,0,0,0);
   RegCloseKey(key);
   if(!i)
    RegDeleteKey(HKEY_CURRENT_USER, "Software\\Petr Lastovicka");
  }
 }
}

void writeini()
{
 HKEY key;
 if(delreg) return;
 if(RegCreateKey(HKEY_CURRENT_USER, subkey, &key)==ERROR_SUCCESS){
  for(Treg *u=regVal; u<endA(regVal); u++){
    RegSetValueEx(key, u->s, 0,REG_DWORD,
      (BYTE *)u->i, sizeof(int));
  }
  for(Tregs *v=regValS; v<endA(regValS); v++){
    RegSetValueEx(key, v->s, 0,REG_SZ,
      (BYTE *)v->i, strlen(v->i)+1);
  }
  RegCloseKey(key);
 }
}

void readini()
{
 HKEY key;
 DWORD d;
 if(RegOpenKey(HKEY_CURRENT_USER, subkey, &key)==ERROR_SUCCESS){
  for(Treg *u=regVal; u<endA(regVal); u++){
    d=sizeof(int);
    RegQueryValueEx(key,u->s,0,0, (BYTE *)u->i, &d);
  }
  for(Tregs *v=regValS; v<endA(regValS); v++){
    d=v->n;
    RegQueryValueEx(key,v->s,0,0, (BYTE *)v->i, &d);
  }
  RegCloseKey(key);
 }
}
//---------------------------------------------------------------------------
//dialog box procedure
BOOL CALLBACK OptionsProc(HWND hWnd, UINT msg, WPARAM wP, LPARAM )
{
 int s,v;

 switch(msg){

  case WM_INITDIALOG:
   setDlgTexts(hWnd,12);
   SetDlgItemInt(hWnd,101, width, FALSE);
   SetDlgItemInt(hWnd,102, height, FALSE);
   SetDlgItemInt(hWnd,103, speed, FALSE);
   SetDlgItemInt(hWnd,104, Ncolors, FALSE);
   SetDlgItemInt(hWnd,105, Dblock, FALSE);
   SetDlgItemInt(hWnd,106, Dmatch, FALSE);
   return TRUE;

  case WM_COMMAND:
   wP=LOWORD(wP);
   switch(wP){
    case IDOK:
     s=width; v=height;
     width= GetDlgItemInt(hWnd,101,NULL,FALSE);
     height= GetDlgItemInt(hWnd,102,NULL,FALSE);
     speed= GetDlgItemInt(hWnd,103,NULL,FALSE);
     Ncolors= GetDlgItemInt(hWnd,104,NULL,FALSE);
     Dblock= GetDlgItemInt(hWnd,105,NULL,FALSE);
     Dmatch= GetDlgItemInt(hWnd,106,NULL,FALSE);
     if(s!=width || v!=height) wP=123;
     else if(playing){
       SetTimer(hWin,10, speed, NULL);
       fast=false;
     }
    //!
    case IDCANCEL:
     EndDialog(hWnd, wP);
   }
  break;
 }
 return FALSE;
}
//---------------------------------------------------------------------------
BOOL CALLBACK DlgProc(HWND hWnd, UINT msg, WPARAM wP, LPARAM )
{
 switch(msg){
  case WM_INITDIALOG:
   setDlgTexts(hWnd,11);
   return TRUE;
  case WM_COMMAND:
   EndDialog(hWnd, wP);
 }
 return FALSE;
}
//---------------------------------------------------------------------------
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT msg, WPARAM wP, LPARAM lP)
{
 static PAINTSTRUCT ps;
 RECT rc,rcw;
 int i,cmd;
 short j;

 switch (msg) {

 case WM_COMMAND:
  cmd=LOWORD(wP);
  setLang(cmd);
  if(playing)
   switch(cmd){
    case 301: //left
     if(s>0){
      s--;
      for(i=0; ; i++){
        if(p[s][r+i]){
          s++;
          break;
        }
        if(i==Dblock-1){
          for(; i>=0; i--){
            set(s,r+i,k[i]);
            set(s+1,r+i,0);
          }
          paintSquare(s+1,r-1);
          break;
        }
      }
     }
    break;
    case 302: //right
     if(s+1<width){
      s++;
      for(i=0; ; i++){
        if(p[s][r+i]){
          s--;
          break;
        }
        if(i==Dblock-1){
          for(; i>=0; i--){
            set(s,r+i,k[i]);
            set(s-1,r+i,0);
          }
          paintSquare(s-1,r-1);
          break;
        }
      }
     }
    break;
    case 303: //rotation down
     j=k[Dblock-1];
     for(i=Dblock-1; i>0; i--){
       set(s,r+i,k[i]=k[i-1]);
     }
     set(s,r,k[0]=j);
    break;
    case 305: //rotation up
     j=k[0];
     for(i=1; i<Dblock; i++){
       set(s,r+i-1,k[i-1]=k[i]);
     }
     set(s,r+i-1,k[Dblock-1]=j);
    break;
    case 304: //down
     fast=!fast;
     SetTimer(hWin,10, fast ? 20 : speed, NULL);
    break;
   }

  switch(cmd){
   case 304:
    if(start) newGame();
   break;
   case 100:
    DialogBoxParam(inst, "ABOUT", hWnd, (DLGPROC) DlgProc, cmd);
   break;
   case 101: //new game
    newGame();
   break;
   case 102: //save settings
    writeini();
   break;
   case 103: //exit
    PostMessage(hWnd,WM_CLOSE,0,0);
   break;
   case 104: //options
    if( DialogBox(inst,"OPTIONS",hWnd,(DLGPROC) OptionsProc)
        == 123) newGame();
    else InvalidateRect(hWnd,0,FALSE);
   break;
   case 105: //delete settings
    deleteini();
   break;
   case 201: //open skin
    openSkin();
   break;
   case 202: //next skin
    nextSkin();
   break;
   case 203: //previous skin
    prevSkin();
   break;
   case 204: //refresh skin
    loadSkin();
   break;
  }
 break;

 case WM_TIMER:

  switch(wP){
   case 300:
    KillTimer(hWin,wP);
    setTitle(0);
   break;
   default:
    if(playing && GetFocus() && IsWindowEnabled(hWnd)){
      if(dr){
        pending=true;
      }else{
        moveDown();
        if(closing) PostMessage(hWnd,WM_CLOSE,0,0);
        if(pending){
          pending=false;
          PostMessage(hWnd,WM_TIMER,0,0);
        }
      }
    }
  }
 break;

 case WM_PAINT:
  GetClientRect(hWnd,&rc);
  GetWindowRect(hWnd,&rcw);
  widthB = width*bmW;
  heightB = height*bmH;
  widthW = widthB+123 + rcw.right-rcw.left-rc.right;
  heightW = heightB+1 + rcw.bottom-rcw.top-rc.bottom;
  amin(heightW,310);
  amin(widthW,250);
  SetWindowPos(hWnd,0,0,0, widthW,heightW, SWP_NOMOVE|SWP_NOZORDER);
  BeginPaint(hWnd,&ps);
  repaint();
  EndPaint(hWnd, &ps);
 break;

 case WM_ERASEBKGND:{
  HBRUSH brush=CreateSolidBrush(colors[clBkgnd]);
  SetRect(&rc,widthB+2,0,widthW,heightW);
  FillRect(dc,&rc,brush); //right
  DeleteObject(brush);
 }break;

 case WM_MOVE:
  if(!IsZoomed(hWnd) && !IsIconic(hWnd)){
    GetWindowRect(hWnd,&rcw);
    top= rcw.top;
    left= rcw.left;
  }
 break;

 case WM_QUERYENDSESSION:
  writeini();
  return TRUE;

 case WM_CLOSE:
  if(dr){
   closing=true;
  }else{
   writeini();
   DestroyWindow(hWnd);
  }
 break;

 case WM_DESTROY:
  PostQuitMessage(0);
 break;

 default:
  return DefWindowProc(hWnd, msg, wP, lP);
}
return 0;
}
//---------------------------------------------------------------------------
int pascal WinMain(HINSTANCE hInstance,HINSTANCE hPrevInst,LPSTR,int cmdShow)
{
 WNDCLASS wc;
 MSG msg;
 static LOGFONT fnt;
 HGDIOBJ newFont;

 inst=hInstance;
 readini();
 initLang();
 wc.style= CS_OWNDC;
 wc.lpfnWndProc= MainWndProc;
 wc.cbClsExtra= 0;
 wc.cbWndExtra= 0;
 wc.hInstance= hInstance;
 wc.hIcon= LoadIcon(hInstance, MAKEINTRESOURCE(1));
 wc.hCursor= LoadCursor(NULL, IDC_ARROW);
 wc.hbrBackground= 0;
 wc.lpszMenuName= MAKEINTRESOURCE(2);
 wc.lpszClassName= "JewelWCLS";
 if(!hPrevInst && !RegisterClass(&wc)) return 1;
 aminmax(left,0,1500);
 aminmax(top,0,1000);
 hWin = CreateWindow( "JewelWCLS", "Jewel",
   WS_OVERLAPPEDWINDOW-WS_THICKFRAME-WS_MAXIMIZEBOX, left, top,
   300, 100, NULL, NULL, hInstance, NULL);
 if(!hWin) return 2;
 dc= GetDC(hWin);
 bmpdc= CreateCompatibleDC(dc);
 loadSkin(LoadBitmap(hInstance, MAKEINTRESOURCE(10)));
 if(!*fnskin){
   getExeDir(fnskin,"skins\\");
 }else{
   loadSkin();
 }
 setTitle(0);
 langChanged();
 SetTextAlign(dc,TA_CENTER);
 GetObject(GetCurrentObject(dc,OBJ_FONT),sizeof(LOGFONT),&fnt);
 fnt.lfHeight= 25;
 fnt.lfWidth= 0;
 fnt.lfWeight= FW_BOLD;
 strcpy(fnt.lfFaceName,"Arial");
 SelectObject(dc, newFont= CreateFontIndirect(&fnt));
 ShowWindow(hWin, cmdShow);

 srand((unsigned) time(NULL));
 haccel=LoadAccelerators(hInstance, MAKEINTRESOURCE(3));

 while(GetMessage(&msg, NULL, 0, 0)==TRUE)
  if(TranslateAccelerator(hWin,haccel,&msg)==0){
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }

 DeleteDC(bmpdc);
 DeleteObject(bm);
 DeleteObject(newFont);
 return msg.wParam;
}

