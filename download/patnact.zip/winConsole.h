#include <windows.h>

extern HANDLE hOutput,hInput;
void initConsole();
void gotoxy(int x, int y);
void clrscr();
#define _NOCURSOR 0
void _setcursortype(int t);
void delay(int ms);
