/*
(C) Petr La�tovi�ka
 
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.


 20.6.1998 - �ernob�l�
14.11.2002 - barevn�

  Form�t vstupn�ho textov�ho souboru:
Na prvn�m ��dku jsou rozm�ry obr�zku ve tvaru ���ka,v��ka
Pak ka�d� ��dek souboru odpov�d� jednomu sloupci obr�zku a
obsahuje ��sla znamenaj�c� d�lky vypln�n�ch �sek� obr�zku.
��sla jsou odd�lena ��rkami.
Pak je voln� ��dek a za n�m n�sleduj� hodnoty pro ��dky obr�zku.
D�lky pr�zdn�ch �sek� se nezad�vaj�, na n� program mus� p�ij�t s�m.

M��e se st�t, �e obr�zek nen� ur�en jednozna�n�.
Na konec souboru za voln� ��dek je mo�n� p�idat sou�adnice
n�kolika vypln�n�ch pol��ek.
Prvn� slo�ka sou�adnic je sm�rem zleva vpravo
Druh� slo�ka sou�adnic je sm�rem shora dol�
Lev� horn� roh m� sou�adnice 1,1

Barvy se zna�� velk�mi p�smeny A a� Z.
Jsou uvedeny t�sn� za p��slu�n�mi ��sly.
Pokud nen� barva uvedena, pak se pou�ije �ern� barva.
Barevnou paletu si prohl�dn�te otev�en�m souboru BARVY.txt

F5 - znovu na�ten� ze souboru a nov� v�po�et
ESC - p�eru�en� v�po�tu
*/
//---------------------------------------------------------------------------
#include <windows.h>
#pragma hdrstop
#include <commdlg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
//---------------------------------------------------------------------------
/*
 USERC("obrazek.rc");
*/
//---------------------------------------------------------------------------
//kostka znamen� souvisl� �ern� �sek v ��dku nebo sloupci
struct Tkostka{
 int d;     //d�lka p�e�ten� ze souboru
 char color; //barva
 int beg,end;//min. a max. pozice, kter� m��e p�ekr�vat
 char *poz; // poz[j]==1 ,pak na pozici j nem��e le�et, poz[beg]=poz[end]=0
 char *pol; // pol[j]==0, pak u� nem��e le�et p�es j-t� pol��ko
};

#define MC 26
typedef char Tcltab[MC];

struct Tradek{
 int N;         //po�et kostek v ��dce|sloupci
 Tkostka *k;    //ukazatel na pole kostek
 int *Nkostek;	//kolik kostek m��e le�et na tomto pol��ku
 Tcltab *Ncolor; //jak� barvy mohou b�t na tomto pol��ku
};

enum{ clFirst, clLast=MC-1, clAqua, clUnknown };
COLORREF colors[MC+2]={
0x000000,//A black
0xff0000,//B blue
0xf0c000,//C
0xff00b8,//D
0x00a000,//E dark green
0xff00ff,//F fuchsia
0x00d000,//G light green
0x00a0c0,//H brown
0xa0a0f0,//I pink
0xa0c0f0,//J
0x8000c8,//K
0x00ff00,//L lime
0x0000b0,//M maroon
0x900000,//N navy
0x00c0f0,//O orange
0x900090,//P purple
0xffff00,//Q aqua
0x0000ff,//R red
0xe0e0e0,//S silver
0x808000,//T teal
0x404090,//U
0x008080,//V olive
0xffffff,//W white
0xa0a0a0,//X light gray
0x00ffff,//Y yellow
0x6000d0,//Z
0xe0e0c0,//blank
0xc0c0c0,//unknown
};

int sirka=1,vyska=1, //rozm�ry obr�zku
    delkar,delkas;  //���ka nebo v��ka (podle prom�nn� jesloup)
int mriz;            //velikost jednoho pol��ka
char fn[256];        //jm�no souboru
FILE *soubor=0;
int chyba;
BOOL jesloup;
bool busy;
int depth;

char *pole=0;        //v�sledek
Tkostka *rkostky,*skostky;  //kostky
Tradek *radky,*sloupce,*rs; //��dky|sloupce
int Drkostky,Dskostky;      //po�ty kostek
int *rpk,*spk;     //po�et kostek p�ekr�vaj�c�ch pol��ko; p�i 0 je pr�zdn�
Tcltab *rpc,*spc;
char *polohy;      //pam� pro polo�ky pol ve struktu�e kostka
char *pozice;      //pam� pro polo�ky poz ve struktu�e kostka
int Dpolohy,Dpole;

HWND hWin;
char *errTitle="Chyba - K�dovan� obr�zek";
int timer;

void cerne(int poz, int l, char color);
void prazdne(int poz, int l, char color);

#ifndef __BORLANDC__
inline int random(int num){ return(int)(((long)rand()*num)/(RAND_MAX+1));}
#endif
//---------------------------------------------------------------------------
void inverze()
{
//prohod� pojmy ��dek a sloupec
 if(jesloup) rs=radky, delkar=sirka, delkas=vyska, jesloup=FALSE;
 else rs=sloupce, delkar=vyska, delkas=sirka, jesloup=TRUE;
}
//---------------------------------------------------------------------------
void omezb(int l, Tkostka *k, int b)
{
int bl,e,d,i;
Tkostka *k2;

 assert(l>=0 && l<delkas);
 bl= k->beg;
 if(b<=bl) return; //u� bylo omezeno
 if(b<0) b=0;
 inverze();
 while(b<delkas && (k->poz[b] || !rs[b].Ncolor[l][k->color])){
   b++;
 }
 inverze();
 d= k->d;
 e= k->end - d + 1;
 if(e<b){ chyba|=1; return; }  //konec < za��tek
//zapi� novou hodnotu
 k->beg=b;
//vypl� prost�edek �zem�
 for(i= max(bl+d,e); i<b+d; i++) cerne(l,i,k->color);
//omez tak� sousedn� kostky, aby bylo zachov�no po�ad�
 if(k+1<rs[l+1].k){
   omezb(l, k+1, b+d+ ((k+1)->color==k->color) );
 }
//najdi nejbli��� �ern� pole v uvoln�n� oblasti a k n�mu omez sousedn� kostku
 for(i=b-1; i>=bl && i>0; i--){
  char c= pole[jesloup ? l*vyska+i : i*vyska+l];
  if(c<=clLast){
    for(k2=k; ; ){
      if(k2==rs[l].k){ chyba|=4; break; }
      k2--;
      if(k2->color==c){ omezb(l,k2, i- k2->d +1); break; }
    }
    break;
  }
 }
//ud�lej pr�zdn� pole, kde u� nem��e le�et ��dn� kostka
 for(i=b-1; i>=max(bl,0); i--){
   if(k->pol[i]){
     k->pol[i]=0;
     --rs[l].Nkostek[i];
     if((--rs[l].Ncolor[i][k->color])==0){
       prazdne(l,i,k->color);
     }
   }
 }
}
//---------------------------------------------------------------------------
void omeze(int l,Tkostka *k,int e)
{
int el,b,d,i;
Tkostka *k2;

 assert(l>=0 && l<delkas);
 el= k->end;
 if(e>=el) return; //u� bylo omezeno
 if(e>=delkar) e=delkar-1;
 d=k->d;
 b=k->beg;
 e-=d-1; //!!!
 inverze();
 while(e>=0 && (k->poz[e] || !rs[e+d-1].Ncolor[l][k->color])){
   e--;
 }
 inverze();
 if(e<b){ chyba|=1; return; } //konec < za��tek
//zapi� novou hodnotu
 k->end= e+d-1;
//vypl� prost�edek �zem�
 for(i=min(el-d,b+d-1); i>=e; i--) cerne(l,i,k->color);
//omez tak� sousedn� kostky, aby bylo zachov�no po�ad�
 if(k>rs[l].k){
   omeze(l, k-1, e-1 - ((k-1)->color==k->color) );
 }
//najdi nejbli��� �ern� pole v uvoln�n� oblasti a k n�mu omez sousedn� kostku
 for(i=k->end+1; i<=el && i<delkar; i++){
  char c= pole[jesloup ? l*vyska+i : i*vyska+l];
  if(c<=clLast){
    for(k2=k; ; ){
      k2++;
      if(k2==rs[l+1].k){ chyba|=4; break; }
      if(k2->color==c){ omeze(l, k2, i +k2->d -1); break; }
    }
    break;
  }
 }
//ud�lej pr�zdn� pole, kde u� nem��e le�et ��dn� kostka
 for(i=k->end+1; i<min(el+1,delkar); i++){
   if(k->pol[i]){
     k->pol[i]=0;
     --rs[l].Nkostek[i];
     if((--rs[l].Ncolor[i][k->color])==0){
       prazdne(l,i,k->color);
     }
   }
 }
}
//---------------------------------------------------------------------------
void omezu(int l,Tkostka *k,int poz)
{
int i,i1;

 assert(l>=0 && l<delkas);
 if(poz<0 || poz+k->d >delkar || k->poz[poz]) return; //u� bylo omezeno
 k->poz[poz]=1;

//Test mez� b,e
 if(poz==k->beg) omezb(l,k,poz+1);
 else
 if(poz==k->end - k->d +1) omeze(l,k,poz + k->d -2);

//vyhledej pol��ka, kde u� tato kostka b�t nem��e
 else
 for(i1=max(k->beg,poz- k->d +1); i1<=min(k->end -k->d,poz +k->d -1); i1++)
  if(k->poz[i1]){
   i=i1+k->d-1;  //uchovej pozici prvn�ho pr�zdn�ho pole
   while(k->poz[++i1] && i1<delkar);  //na konec oblasti, kde kostka nem��e le�et
   for( ;i<min(i1,delkar); i++)
     if(k->pol[i]){    //aby nebylo v�ckr�t
       k->pol[i]=0;
       --rs[l].Nkostek[i];
       if((--rs[l].Ncolor[i][k->color])==0){
         prazdne(l,i,k->color);
       }
     }
  }
}
//---------------------------------------------------------------------------
//ve sloupci|��dku poz je na pozici l pol��ko barvy color
void cerne(int poz, int l, char color)
{
char *uz;
Tkostka *k;

 assert(poz>=0 && poz<delkas);
 if(l<0 || l>=delkar){ chyba|=1; return; }
//poz,l jsou prohozeny; p�i inverze() se nem�n�
 uz= pole+(jesloup ? poz*vyska+l : l*vyska+poz);
 if(*uz==color) return; //u� bylo �ern�
 if(*uz!=clUnknown){ chyba|=1; return; }
 *uz=color;

 #ifdef DBG
 InvalidateRect(hWin,0,0);
 UpdateWindow(hWin);
 #endif

 //v kolm� �ad� omez ob� krajn� kostky na okol� vypln�n�ho pol��ka
 inverze();
 //prvn� kostku vlevo od nov�ho pol��ka posune vpravo
 for(k=rs[l+1].k-1; ; k--){
   if(k<rs[l].k){ chyba|=2; goto cleanup; }
   if(k->beg<=poz && k->color==color){
     omezb(l,k,poz- k->d +1);
     break;
   }
 }
 //prvn� kostku vpravo od nov�ho pol��ka posune vlevo
 for(k=rs[l].k; ; k++){
   if(k>=rs[l+1].k){ chyba|=4; goto cleanup; }
   if(k->end>=poz && k->color==color){
     omeze(l,k,poz+ k->d -1);
     break;
   }
 }
 for(k=rs[l+1].k-1;  k>=rs[l].k;  k--){
   //na okraj�ch v�ech kostek mus� b�t voln� pol��ka nebo jin� barva
   if(k->color==color){
     omezu(l,k,poz - k->d);
     omezu(l,k,poz+1);
   }
 }
cleanup:
 inverze(); //obnov
}
//---------------------------------------------------------------------------
void cerne2x(int i, int j, char color)
{
 assert(jesloup);
 assert(i>=0 && i<delkas);
 assert(j>=0 && j<delkar);
 cerne(i,j,color);
 if(!chyba){
  inverze();
  assert(pole[jesloup ? j*vyska+i : i*vyska+j]==color);
  pole[jesloup ? j*vyska+i : i*vyska+j]= clUnknown;
  cerne(j,i,color);
  inverze();
 }
}
//---------------------------------------------------------------------------
//ve sloupci|��dku poz na pozici l je pr�zdn� pol��ko
void prazdne(int poz, int l)
{
int j;
Tkostka *k;
char *uz;

 assert(poz>=0 && poz<delkas);
 if(l<0 || l>=delkar){ chyba|=1; return; }
 //poz,l jsou prohozeny (p�i inverzi() se nem�n�)
 uz= pole+(jesloup ? poz*vyska+l : l*vyska+poz);
 if(*uz==clAqua) return; //u� bylo pr�zdn�
 if(*uz!=clUnknown){ chyba|=1; return; }
 *uz=clAqua;

 #ifdef DBG
 InvalidateRect(hWin,0,0);
 UpdateWindow(hWin);
 #endif

 inverze();
 //v kolm� �ad� omez v�echny kostky p�ekr�vaj�c� pr�zdn� pole
 for(k=rs[l+1].k-1; k>=rs[l].k && k->beg>poz; k--) ; //najdi prvn� zprava
 for(; k>=rs[l].k && k->end>=poz;  k--){
   for(j=poz- k->d +1;  j<=poz;  j++) omezu(l,k,j);
 }
 inverze();
}
//---------------------------------------------------------------------------
//ve sloupci|��dku poz na pozici l nem��e b�t color
void prazdne(int poz, int l, char color)
{
int j;
Tkostka *k;
char *uz;

 assert(poz>=0 && poz<delkas);
 if(l<0 || l>=delkar){ chyba|=1; return; }
 if(!rs[poz].Nkostek[l]){
   prazdne(poz,l);
   return;
 }
 //poz,l jsou prohozeny (p�i inverzi() se nem�n�)
 uz= pole+(jesloup ? poz*vyska+l : l*vyska+poz);
 if(*uz==clAqua) return; //u� bylo pr�zdn�

 inverze();
 //v kolm� �ad� omez v�echny kostky p�ekr�vaj�c� toto pole
 for(k=rs[l+1].k-1; k>=rs[l].k && k->beg>poz; k--) ; //najdi prvn� zprava
 for(; k>=rs[l].k && k->end>=poz;  k--){
   if(k->color==color){
    for(j=poz- k->d +1;  j<=poz;  j++) omezu(l,k,j);
   }
 }
 inverze();
}
//---------------------------------------------------------------------------
void prazdne2x(int i, int j)
{
 assert(jesloup);
 assert(i>=0 && i<delkas);
 assert(j>=0 && j<delkar);
 prazdne(i,j);
 if(!chyba){
  inverze();
  assert(pole[jesloup ? j*vyska+i : i*vyska+j]==clAqua);
  pole[jesloup ? j*vyska+i : i*vyska+j]= clUnknown;
  prazdne(j,i);
  inverze();
 }
}
//---------------------------------------------------------------------------
//backtracking
void backtrack()
{
 char *u;
 int i,j,i0,j0;
 char cl,cl0;
 char *pole2;
 Tkostka *rkostky2,*skostky2;
 Tradek *radky2,*sloupce2;
 int *rpk2,*spk2;
 Tcltab *rpc2,*spc2;
 char *polohy2;
 char *pozice2;
 static MSG mesg;

 if(depth>1){
  timer++;
  if(!(timer&0xff)){
    InvalidateRect(hWin,0,0);
    UpdateWindow(hWin);
  }
  while(PeekMessage(&mesg, NULL, 0, 0, PM_REMOVE)){
    if(mesg.message==WM_QUIT) exit(1);
    if(mesg.message==WM_KEYDOWN){
      if(mesg.wParam==VK_ESCAPE) return;
    }
    busy=true;
    TranslateMessage(&mesg);
    DispatchMessage(&mesg);
    busy=false;
  }
 }

 pole2= new char[Dpole];
 rkostky2= new Tkostka[Drkostky];
 skostky2= new Tkostka[Dskostky];
 radky2= new Tradek[vyska+1];
 sloupce2= new Tradek[sirka+1];
 polohy2= new char[Dpolohy];
 pozice2= new char[Dpolohy];
 rpk2= new int[Dpole];
 spk2= new int[Dpole];
 rpc2= new Tcltab[Dpole];
 spc2= new Tcltab[Dpole];
 memcpy(pole2,pole,Dpole);
 memcpy(rkostky2,rkostky,sizeof(Tkostka)*Drkostky);
 memcpy(skostky2,skostky,sizeof(Tkostka)*Dskostky);
 memcpy(radky2,radky,sizeof(Tradek)*(vyska+1));
 memcpy(sloupce2,sloupce,sizeof(Tradek)*(sirka+1));
 memcpy(polohy2,polohy,Dpolohy);
 memcpy(pozice2,pozice,Dpolohy);
 memcpy(rpk2,rpk,sizeof(int)*Dpole);
 memcpy(spk2,spk,sizeof(int)*Dpole);
 memcpy(rpc2,rpc,sizeof(Tcltab)*Dpole);
 memcpy(spc2,spc,sizeof(Tcltab)*Dpole);

 i=i0=random(sirka);
 j=j0=random(vyska);
 u=pole + i0*vyska + j0;
 do{
   if(*u==clUnknown){
    cl0=random(MC+1)-1;
    for(cl=cl0; ; ){
      chyba=0;
      if(cl<0) prazdne2x(i,j);
      else if(!radky[j].Ncolor[i][cl] ||
        !sloupce[i].Ncolor[j][cl]){ chyba=1; goto nxt; }
      else cerne2x(i,j,cl);
      if(!chyba){
        depth++;
        backtrack();
        depth--;
        if(!chyba) goto cleanup;
      }
      memcpy(pole,pole2,Dpole);
      memcpy(rkostky,rkostky2,sizeof(Tkostka)*Drkostky);
      memcpy(skostky,skostky2,sizeof(Tkostka)*Dskostky);
      memcpy(radky,radky2,sizeof(Tradek)*(vyska+1));
      memcpy(sloupce,sloupce2,sizeof(Tradek)*(sirka+1));
      memcpy(polohy,polohy2,Dpolohy);
      memcpy(pozice,pozice2,Dpolohy);
      memcpy(rpk,rpk2,sizeof(int)*Dpole);
      memcpy(spk,spk2,sizeof(int)*Dpole);
      memcpy(rpc,rpc2,sizeof(Tcltab)*Dpole);
      memcpy(spc,spc2,sizeof(Tcltab)*Dpole);
      nxt:
      cl++;
      if(cl>clLast) cl=-1;
      if(cl==cl0) break;
    }
    goto cleanup;
   }
   u++;
   j++;
   if(j==vyska){
     j=0;
     i++;
     if(i==sirka){ i=0; u=pole; }
   }
 }while(j!=j0 || i!=i0);
cleanup:
 delete[] spc2;
 delete[] rpc2;
 delete[] spk2;
 delete[] rpk2;
 delete[] pozice2;
 delete[] polohy2;
 delete[] sloupce2;
 delete[] radky2;
 delete[] skostky2;
 delete[] rkostky2;
 delete[] pole2;
}
//---------------------------------------------------------------------------
//spu�t�n� algoritmu
void hlavni()
{
int i,j;
char c;
int cl;

 chyba=0;
 jesloup=TRUE;
//Omez kostky do rozm�r� sirka|vyska
//��dky
 inverze();
 for(i=0;i<vyska;i++){
   if(rs[i].N!=1 || rs[i].k->d){
    omezb(i,rs[i].k,0);
    omeze(i,rs[i+1].k-1,sirka-1);
   }else{
    for(j=0;j<sirka;j++) prazdne(i,j); //pr�zdn� ��dek
   }
 }
 inverze();
//sloupce
 for(i=0;i<sirka;i++){
   if(rs[i].N!=1 || rs[i].k->d){
    omezb(i,rs[i].k,0);
    omeze(i,rs[i+1].k-1,vyska-1);
   }else{
    for(j=0;j<vyska;j++) prazdne(i,j); //pr�zdn� sloupec
   }
 }

//Dod�lej �ern� pole, kter� jsou p�id�na na konci souboru
 while(!feof(soubor)){
  fscanf(soubor,"%d",&i); //sloupec
  fscanf(soubor,"%c",&c); //��rka
  if(c!=',' || feof(soubor)) break;
  fscanf(soubor,"%d",&j); //��dek
  fscanf(soubor,"%c",&c); //konec ��dku
  cl=0;
  if(c>='A' && c<'A'+MC){
    cl=c-'A';
    fscanf(soubor,"%c",&c); //konec ��dku
  }
  i--; j--;
  if(i>=0 && j>=0 && i<sirka && j<vyska){
    cerne2x(i,j,(char)cl);
  }else{
    MessageBox(0,"Sou�adnice jsou mimo.",errTitle,MB_OK);
  }
 }
 fclose(soubor);
 depth=0;
 backtrack();
}
//---------------------------------------------------------------------------
void deleteAll()
{
 delete[] spk;
 delete[] rpk;
 delete[] spc;
 delete[] rpc;
 delete[] pozice;
 delete[] polohy;
 delete[] sloupce;
 delete[] radky;
 delete[] skostky;
 delete[] rkostky;
}
//---------------------------------------------------------------------------
//na�te soubor do pam�ti
//vrac� 0 nebo �et�zec chybov� zpr�vy
char * otevri1()
{
char c;
int i,j,k,h;
long sumas=0,sumar=0,sumal;
Tkostka *Ukostky;
Tradek *Uradky;
char *Upolohy,*Upozice;
int *Upk;
Tcltab *Upc;
int cl,cll;
char clbuf[MC];
static char *strr="Sou�et ��sel v    . ��dku je moc velk�",
   *strs="Sou�et ��sel v    . sloupci je moc velk�";

 if((soubor=fopen(fn,"rt"))==0) return "Soubor nelze otev��t !";
 fscanf(soubor,"%d,%d/n",&i,&j);
 if(i<1 || j<1 || i>127 || j>127)
    return "Chybn� form�t souboru, chybn� rozm�ry obr�zku.";

 sirka=i; vyska=j;

//Testuj sloupce
 Dskostky=0;
 for(i=0;i<sirka;i++){
  j=0;
  sumal=0;
  cll=-1;
  do{
   j++;
   fscanf(soubor,"%d",&h);
   fscanf(soubor,"%c",&c);
   cl=0;
   if(c>='A' && c<'A'+MC){
     cl=c-'A';
     fscanf(soubor,"%c",&c);
   }
   sumas+=h;
   sumal+=h;
   if(cl==cll) sumal++;
   cll=cl;
   Dskostky++;
   if(h<0) return "Ve sloupci je z�porn� ��slo.";
   if(sumal>vyska){ //sou�et kostek ve sloupci
     sprintf(strs+15,"%3d", i+1);
     strs[18]='.';
     return strs;
   }
  }while(c==',');
 }
//mus� b�t voln� ��dek
 fscanf(soubor,"%c",&c);
 if(c!='\n') return "Chybn� po�et sloupc�.";

//Testuj ��dky
 Drkostky=0;
 for(i=0;i<vyska;i++){
  j=0;
  sumal=0;
  cll=-1;
  do{
   j++;
   if(feof(soubor)) return "Chybn� po�et ��dek.";
   fscanf(soubor,"%d",&h);
   fscanf(soubor,"%c",&c);
   cl=0;
   if(c>='A' && c<'A'+MC){
     cl=c-'A';
     fscanf(soubor,"%c",&c);
   }
   sumar+=h;
   sumal+=h;
   if(cl==cll) sumal++;
   cll=cl;
   Drkostky++;
   if(h<0) return "V ��dku je z�porn� ��slo.";
   if(sumal>sirka){ //sou�et kostek v ��dku
     sprintf(strr+15,"%3d", i+1);
     strr[18]='.';
     return strr;
   }
  }while(c==',' && !feof(soubor));
 }
 fscanf(soubor,"%c",&c);
 if(!feof(soubor) && c!='\n') return "Chybn� po�et ��dek.";
 if(sumas!=sumar) //sou�et ��sel ve sloupc�ch mus� b�t stejn� jako v ��dc�ch
    return "Chybn� data !";

//Dynamick� alokace pol�
 delete[] pole;
 Dpole= sirka*vyska+1;
 pole= new char[Dpole];
 memset(pole,clUnknown,Dpole);
 rkostky= new Tkostka[Drkostky];
 skostky= new Tkostka[Dskostky];
 radky= new Tradek[vyska+1];
 sloupce= new Tradek[sirka+1];
 Dpolohy= Dskostky*vyska + Drkostky*sirka;
 polohy= new char[Dpolohy];
 memset(polohy,1,Dpolohy);
 pozice= new char[Dpolohy];
 memset(pozice,0,Dpolohy);
 rpk= new int[Dpole];
 spk= new int[Dpole];
 rpc= new Tcltab[Dpole];
 spc= new Tcltab[Dpole];

 if(!spc){
   deleteAll();
   delete[] pole;
   return "Nedostatek pam�ti !";
 }

//Data jsou v po��dku => na�ti ��sla do pol�
 rewind(soubor);
 fscanf(soubor,"%d,%d/n",&sirka,&vyska);

//Na�ti sloupce
 Upolohy=polohy; Upozice=pozice;
 Uradky= sloupce; Ukostky= skostky; Upk=spk; Upc=spc;
 for(i=0;i<sirka;i++){
   Uradky->k= Ukostky;
   memset(clbuf,0,sizeof(clbuf));
   j=0;
   do{
    j++;
    fscanf(soubor,"%d",&Ukostky->d);
    fscanf(soubor,"%c",&c);
    cl=0;
    if(c>='A' && c<'A'+MC){
      cl=c-'A';
      fscanf(soubor,"%c",&c);
    }
    clbuf[cl]++;
    Ukostky->color= (char)cl;
    Ukostky->beg= -vyska;
    Ukostky->end= 2*vyska;
    Ukostky->poz= Upozice;
    Upozice+=vyska;
    Ukostky->pol= Upolohy;
    Upolohy+=vyska;
    Ukostky++;
   }while(c==',');
   Uradky->N=j; //po�et kostek v sloupci
   Uradky->Nkostek=Upk;
   Uradky->Ncolor=Upc;
   Uradky++;
   for(k=0; k<vyska; k++){
     *Upk++ = j;
     memcpy(Upc,clbuf,sizeof(Tcltab));
     Upc++;
   }
 }
 Uradky->k=Ukostky;
 fscanf(soubor,"%c",&c); //voln� ��dek

//Na�ti ��dky
 Uradky= radky; Ukostky= rkostky; Upk=rpk; Upc=rpc;
 for(i=0;i<vyska;i++){
   Uradky->k= Ukostky;
   memset(clbuf,0,sizeof(clbuf));
   j=0;
   do{
    j++;
    fscanf(soubor,"%d",&Ukostky->d);
    fscanf(soubor,"%c",&c);
    cl=0;
    if(c>='A' && c<'A'+MC){
      cl=c-'A';
      fscanf(soubor,"%c",&c);
    }
    clbuf[cl]++;
    Ukostky->color= (char)cl;
    Ukostky->beg= -sirka;
    Ukostky->end= 2*sirka;
    Ukostky->poz= Upozice;
    Upozice+=sirka;
    Ukostky->pol= Upolohy;
    Upolohy+=sirka;
    Ukostky++;
   }while(c==',' && !feof(soubor));
   Uradky->N=j; //po�et kostek v ��dku
   Uradky->Nkostek=Upk;
   Uradky->Ncolor=Upc;
   Uradky++;
   for(k=0; k<sirka; k++){
     *Upk++ = j;
     memcpy(Upc,clbuf,sizeof(Tcltab));
     Upc++;
   }
 }
 Uradky->k=Ukostky;
 return 0; //OK
}
//---------------------------------------------------------------------------
//vypo�te velikost m��e, nastav� rozm�ry okna a p�ekresl�
void Resize()
{
int wx,wy,xmax,ymax,xmin,ymin;
RECT rc,rcw;

//vypo�te mriz, nastav� rozm�ry okna a vytiskne
 xmax=GetSystemMetrics(SM_CXFULLSCREEN);
 ymax=GetSystemMetrics(SM_CYFULLSCREEN);
 xmin=GetSystemMetrics(SM_CXMIN);
 ymin=GetSystemMetrics(SM_CYMIN);
 GetClientRect(hWin,&rc);
 GetWindowRect(hWin,&rcw);
 wx= 1+rcw.right-rcw.left-rc.right;
 wy= 1+rcw.bottom-rcw.top-rc.bottom;

 mriz= ( (rc.right+1)/sirka + (rc.bottom+1)/vyska )/2;
 if(IsZoomed(hWin)) mriz= xmax/sirka;
 if(mriz*vyska+ wy +rcw.top > ymax) mriz=(ymax -rcw.top -wy)/vyska;
 if(mriz*sirka+ wx +rcw.left > xmax) mriz=(xmax -rcw.left -wx)/sirka;
 if(mriz*vyska+ wy <ymin) mriz=(ymin-wy)/vyska+1;
 if(mriz*sirka+ wx <xmin) mriz=(xmin-wx)/sirka+1;
 if(mriz<3) mriz=3;
 SetWindowPos(hWin,0,0,0,sirka*mriz +wx,
    vyska*mriz +wy, SWP_NOMOVE|SWP_NOZORDER);
}
//---------------------------------------------------------------------------
//zobraz� dialog otev��t, p�e�te soubor a zobraz� v�sledek
void otevri(int n)
{
char *str;

OPENFILENAME ofns={
 sizeof(OPENFILENAME),
 hWin,
 0,
 "Textov� soubory (*.txt)\0*.txt\0V�echny soubory\0*.*\0\0",
 0,0,1,
 fn, sizeof(fn),
 0,0,0,
 "Otev��t - k�dovan� obr�zek",
 OFN_FILEMUSTEXIST|OFN_HIDEREADONLY|OFN_READONLY,
 0,0,
 "TXT",
 0,0,0
};

 if(busy) return;
 for(;;){
   if(n++){
    if(!GetOpenFileName(&ofns)){
      return;
    }
    char buf[256];
    char *s=strchr(fn,0);
    while(s>=fn && *s!='\\') s--;
    strcpy(buf,s+1);
    s= strchr(buf,0);
    while(s>=buf && *s!='.') s--;
    if(*s=='.') *s=0;
    SetWindowText(hWin,buf);
   }
   str=otevri1();
   if(!str) break;
  //chyba v datech v souboru
   if(soubor) fclose(soubor);
   MessageBox(0,str,errTitle,MB_OK);
 }

//v�po�et
 Resize();
 hlavni();
 InvalidateRect(hWin,NULL,FALSE);
 UpdateWindow(hWin);
 if(chyba){
   MessageBox(0,"Nebylo nalezeno spr�vn� �e�en�",errTitle,MB_OK);
 }
//dealokace pol�
 deleteAll();
//vytiskni
 Resize();
}
//---------------------------------------------------------------------------
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT msg, WPARAM wP, LPARAM lP)
{
switch (msg) {

 case WM_LBUTTONDOWN:
  otevri(1);
 break;

 case WM_KEYDOWN:
  if(wP==VK_F5){ otevri(0); UpdateWindow(hWnd); }
  else if(wP!=VK_ESCAPE) otevri(1);
 break;

 case WM_SIZE:
  if(pole){
    Resize();
    InvalidateRect(hWin,NULL,FALSE);
  }
 break;

 case WM_PAINT:{
  int x,y,b,bl;
  char *u;
  PAINTSTRUCT ps;

  bl=-2;
  HDC hdc = BeginPaint(hWnd,&ps);
  if(pole){
  //Vykresli cel� pole
   u=pole;
   for(x=0;x<sirka;x++)
   for(y=0;y<vyska;y++){
    b= *u++;
    if(b!=bl){
      DeleteObject(SelectObject(hdc,CreateSolidBrush(colors[b])));
      bl=b;
    }
    Rectangle(hdc,x*mriz,y*mriz,(x+1)*mriz+1,(y+1)*mriz+1);
   }
  }else{
    FillRect(hdc,&ps.rcPaint,(HBRUSH)GetStockObject(LTGRAY_BRUSH));
  }
  DeleteObject(SelectObject(hdc,GetStockObject(BLACK_BRUSH)));
  EndPaint(hWnd, &ps);
 }
 break;

 case WM_DESTROY:
  PostQuitMessage(0);
 break;

 default:
  return DefWindowProc(hWnd, msg, wP, lP);
}
return 0;
}
//---------------------------------------------------------------------------
int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrev, LPSTR, int cmdShow)
{
MSG msg;
WNDCLASS wc;

 wc.style=		0;
 wc.lpfnWndProc=	MainWndProc;
 wc.cbClsExtra=		0;
 wc.cbWndExtra=		0;
 wc.hInstance=		hInstance;
 wc.hIcon=		LoadIcon(hInstance, "MAINICON");
 wc.hCursor=		LoadCursor(NULL, IDC_ARROW);
 wc.hbrBackground=	0;
 wc.lpszMenuName=	NULL;
 wc.lpszClassName=	"ObrWndCls";

 if(!hPrev && !RegisterClass(&wc)) return 1;
 hWin = CreateWindow(
   "ObrWndCls", "K�dovan� obr�zek",
   WS_OVERLAPPEDWINDOW,
   CW_USEDEFAULT, CW_USEDEFAULT,
   640, 450,
   NULL, NULL, hInstance, NULL
 );
 if(!hWin) return 2;

 ShowWindow(hWin,cmdShow);
 otevri(1);

 while(GetMessage(&msg, NULL, 0, 0)==TRUE){
   TranslateMessage(&msg);
   DispatchMessage(&msg);
 }
 return msg.wParam;
}
//---------------------------------------------------------------------------

