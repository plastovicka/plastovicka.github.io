/*

(C) 10.1999  Petr Lastovicka
 
 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License.
*/
//---------------------------------------------------------------------------
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>
#pragma hdrstop
/*
 USERC("Lode.rc");
*/
//---------------------------------------------------------------------------
#ifndef __BORLANDC__
inline int random(int num){ return(int)(((long)rand()*num)/(RAND_MAX+1));}
inline void randomize() { srand((unsigned) time(NULL)); }
#endif

#define xM 22
#define yM 14

int A[xM][yM];  //��slo po�tu viditeln�ch lod�; -1 pro lo�; okraje jsou -2
bool T[xM][yM], //je zde ��slo nebo lo�
     O[xM][yM]; //je ozna�eno

const int grid=38;    //velikost m��ky
const int r0=7,r1=12; //velikosti krou�k�

int
 width=10,	//���ka
 height=7,	//v��ka
 Nship=3,	//po�et lod�
 direct4=0,	//1= jen 4 sm�ry, 0= v�ech 8 sm�r�
 lookOver=0,	//1=je vid�t p�es lod�
 move,		//po��tadlo tah�
 fontH,		//v��ka fontu
 winWidth,
 left=180, top=100,
 xp,yp,xk,yk,direction,
 lodWidth,lodHeight,//velikost bitmapy lod�
 remains;		//po�et je�t� nenalezen�ch lod�

bool
 isFinish, O2, selecting=false;

COLORREF clCislo=RGB(255,255,0), clVoda=RGB(0,255,255),
 clPrazdne=RGB(210,210,210), clPozadi=RGB(192,192,192);

const char *subkey="Software\\Petr Lastovicka\\lode";
const struct Treg { char *s; int *i; } regVal[]={
{"vyska",&height},{"sirka",&width},
{"X",&left},{"Y",&top},
{"lodi",&Nship},{"pres",&lookOver},
{"smeru4",&direct4}
};

HBITMAP lod;
HDC dc;
HWND hWin;
HINSTANCE inst;

//---------------------------------------------------------------------------
template <class T> inline void amin(T &x,int m){ if(x<m) x=m; }
template <class T> inline void amax(T &x,int m){ if(x>m) x=m; }

inline int sgn(int x)
{
 return x>0 ? 1: (x<0 ? -1:0);
}

void line(int x1,int y1,int x2,int y2)
{
 MoveToEx(dc, x1,y1, NULL);
 LineTo(dc, x2,y2);
}

void vprint(int x, int y, char *format, va_list va)
{
 char buf[128];
 int n = vsprintf(buf,format,va);
 SetBkColor(dc,clPozadi);
 SetTextAlign(dc,TA_TOP|TA_LEFT);
 TextOut(dc, x, y, buf, n);
}

void print(int x, char *format, ...)
{
 va_list va;
 va_start(va,format);
 vprint(winWidth*x/300, height*grid, format,va);
 va_end(va);
}

void printMove()
{
 print(4, "Tah: %d  ", move);
}
//---------------------------------------------------------------------------
void paintSquare(int x,int y)
{
 int xv,yv;
 char ch;
 HGDIOBJ hbrOld,oldBitmap;
 HDC dc1;

 xv= x*grid - grid/2;
 yv= y*grid - grid/2;
 if(T[x][y]){
  if(A[x][y]>=0){
   //��slo
    hbrOld= SelectObject(dc, CreateSolidBrush(clCislo));
    Ellipse(dc, xv-r1,yv-r1, xv+r1,yv+r1);
    DeleteObject(SelectObject(dc,hbrOld));
    ch= char('0'+A[x][y]);
    SetBkColor(dc,clCislo);
    SetTextAlign(dc,TA_CENTER|TA_TOP);
    TextOut(dc, xv,yv-(fontH>>1), &ch, 1);
  }else{
   //lo�
    dc1= CreateCompatibleDC(dc);
    oldBitmap= SelectObject(dc1,lod);
    BitBlt(dc, xv-lodWidth/2+1, yv-lodHeight/2,
      lodWidth, lodHeight, dc1, 0,0,SRCCOPY);
    SelectObject(dc1, oldBitmap);
    DeleteDC(dc1);
  }
 }else{
  //pr�zdn� nebo ozna�en� pole
   hbrOld= SelectObject(dc,
     CreateSolidBrush(O[x][y] ? clVoda:clPrazdne) );
   Ellipse(dc, xv-r0,yv-r0, xv+r0,yv+r0);
   DeleteObject(SelectObject(dc,hbrOld));
 }
}
//---------------------------------------------------------------------------
void paintSelect(int x,int y,int o)
{
 bool old;

 if(x>0 && y>0 && x<=width && y<=height){
   if(!T[x][y]){
     old=O[x][y];
     if(o<2) O[x][y]= o!=0;
     paintSquare(x,y);
     O[x][y]=old;
   }
 }
}
//---------------------------------------------------------------------------
void repaint()
{
 int x,y,x2,y2,i,xk,yk,x0,y0;

 x0=grid/2-lodWidth/2;
 y0=grid/2-lodHeight/2;
 xk=width*grid-grid/2+lodWidth/2;
 yk=height*grid-grid/2+lodHeight/2;

//stavov� ��dek
 printMove();
 print(70, "���ka: %d",width);
 print(150,"V��ka: %d",height);
 print(228,"Lod�: %d",Nship);

//svisl� ��ry
 x=grid/2;
 for(i=1; i<=width; i++){
   line(x, y0, x, yk);
   x+=grid;
 }
//vodorovn� ��ry
 y=grid/2;
 for(i=1; i<=height; i++){
   line(x0, y, xk, y);
   y+=grid;
 }
//�ikm� ��ry
 if(!direct4){
  x2= x0+lodWidth;
  x=  x0;
  y2= yk;
  y=  yk-lodHeight;
  xk= width*grid;
  for(i=1; i<width+height; i++){
   line(x,y,x2,y2);
   line(xk-x, y, xk-x2, y2);
   if(y>grid) y-=grid; else x+=grid;
   if(x2<xk-grid) x2+=grid; else y2-=grid;
  }
 }
//kole�ka, ��sla a lod�
 for(y=1; y<=height; y++)
  for(x=1; x<=width; x++)
   paintSquare(x,y);
}
//---------------------------------------------------------------------------
void calcNumber(int x0,int y0)
{
 int p,s,x,y,xs,ys;

 if(A[x0][y0]<0) return;
 p=0;
 xs=ys=0;
 for(s=0; s<(direct4 ? 4:8); s++){
  x=x0,y=y0;
  switch(s){
   case 0: xs=1; break;
   case 1: xs=-1; break;
   case 2: xs=0,ys=1; break;
   case 3: ys=-1; break;
   case 4: xs=-1; break;
   case 5: xs=1; break;
   case 6: ys=1; break;
   case 7: xs=-1;
  }
  do{
   if(A[x][y]<0){ p++; if(!lookOver) break;}
   x+=xs,y+=ys;
  }while(A[x][y]!=-2);
 }
 A[x0][y0]=p;
}
//---------------------------------------------------------------------------
void newGame()
{
 int x,y,i;

 amin(height,2);
 amax(height,yM-2);
 amin(width,3);
 amax(width,xM-2);
 amin(Nship,1);
 amax(Nship, width*height/2);

 memset(A,0,sizeof(A));
 for(x=0; x<=width+1; x++) A[x][0]=A[x][height+1]=-2;
 for(y=1; y<=height; y++) A[0][y]=A[width+1][y]=-2;
 for(x=1; x<=width; x++)
  for(y=1; y<=height; y++)
    O[x][y]=T[x][y]=false;
 isFinish=false;
 remains=Nship;
 move=0;
//vygeneruj lod�
 for(i=0; i<Nship; i++){
   do x=random(width)+1, y=random(height)+1; while(A[x][y]);
   A[x][y]=-1;
 }
 InvalidateRect(hWin,0,TRUE);
}
//---------------------------------------------------------------------------
void setO(int x,int y,bool o)
{
 if(x>0 && y>0 && x<=width && y<=height){
  O[x][y]=o;
  paintSquare(x,y);
 }
}
//---------------------------------------------------------------------------
void selectLine(int x,int y,int o)
{
 int xs,ys;

 xs=sgn(xp-x), ys=sgn(yp-y);
 while(x!=xp || y!=yp){
  paintSelect(x,y,o);
  x+=xs,y+=ys;
 }
}
//---------------------------------------------------------------------------
void mouseMove(int x1, int y1)
{
 int xr,yr, x2,y2,direction2;

 if(selecting){
//nov� sm�r
  xr=x1-xp, yr=y1-yp;
  if(xr==0) direction2=0;
  else if(xr==-yr && !direct4) direction2=1;
  else if(yr==0)  direction2=2;
  else if(xr==yr && !direct4) direction2=3;
  else direction2=direction;
//nov� koncov� bod
  switch(direction2){
   default: x2=xp, y2=y1; break;
   case 1: x2=xp+(xr-yr)/2, y2=yp-(xr-yr)/2; break;
   case 2: x2=x1, y2=yp; break;
   case 3: x2=xp+(xr+yr)/2, y2=yp+(xr+yr)/2;
  }
  if(x2!=xk || y2!=yk){
//tisk
   if(direction==direction2 && sgn(x2-xk)==sgn(xk-xp) && sgn(y2-yk)==sgn(yk-yp) ||
     xp==xk && yp==yk)
     selectLine(x2,y2,O2);
   else{
     direction=direction2;
     selectLine(xk,yk,2);
     selectLine(x2,y2,O2);
   }
   xk=x2, yk=y2;
  }
 }
}
//---------------------------------------------------------------------------
void deleteini()
{
 HKEY key;
 DWORD i;

 if(RegDeleteKey(HKEY_CURRENT_USER, subkey)==ERROR_SUCCESS){
  if(RegOpenKey(HKEY_CURRENT_USER,
    "Software\\Petr Lastovicka",&key)==ERROR_SUCCESS){
   i=1;
   RegQueryInfoKey(key,0,0,0,&i,0,0,0,0,0,0,0);
   RegCloseKey(key);
   if(!i)
    RegDeleteKey(HKEY_CURRENT_USER, "Software\\Petr Lastovicka");
  }
 }
}

void writeini()
{
 HKEY key;
 if(RegCreateKey(HKEY_CURRENT_USER, subkey, &key)!=ERROR_SUCCESS)
   MessageBox(hWin,"Nelze ulo�it nastaven� do registr� Windows.",
     "Pi�kvorky", MB_OK|MB_ICONWARNING);
 else{
  for(int k=0; k<sizeof(regVal)/sizeof(Treg); k++)
    RegSetValueEx(key,regVal[k].s,0,REG_DWORD,
      (BYTE *)regVal[k].i, sizeof(int));
  RegCloseKey(key);
 }
}

void readini()
{
 HKEY key;
 DWORD d;
 if(RegOpenKey(HKEY_CURRENT_USER, subkey, &key)==ERROR_SUCCESS){
  for(int k=0; k<sizeof(regVal)/sizeof(Treg); k++){
    d=sizeof(int);
    RegQueryValueEx(key,regVal[k].s,0,0, (BYTE *)regVal[k].i, &d);
  }
  RegCloseKey(key);
 }
}
//---------------------------------------------------------------------------
//procedura pro dialogov� okno
BOOL CALLBACK optionsProc(HWND hWnd, UINT msg, WPARAM wP, LPARAM )
{
 switch(msg){

  case WM_INITDIALOG:
   SetDlgItemInt(hWnd,101, width, FALSE);
   SetDlgItemInt(hWnd,102, height, FALSE);
   SetDlgItemInt(hWnd,104, Nship, FALSE);
   CheckRadioButton(hWnd,106,107, 107 - direct4);
   CheckDlgButton(hWnd,103, lookOver ? BST_CHECKED:BST_UNCHECKED);
   return 1;

  case WM_COMMAND:
   wP=LOWORD(wP);
   switch(wP){
    case IDOK:
     width= GetDlgItemInt(hWnd,101,NULL,FALSE);
     height= GetDlgItemInt(hWnd,102,NULL,FALSE);
     Nship= GetDlgItemInt(hWnd,104,NULL,FALSE);
     direct4= IsDlgButtonChecked(hWnd,106)==BST_CHECKED;
     lookOver= IsDlgButtonChecked(hWnd,103)==BST_CHECKED;
    //!
    case IDCANCEL:
     EndDialog(hWnd, wP);
   }
  break;
 }
 return 0;
}
//---------------------------------------------------------------------------
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT msg, WPARAM wP, LPARAM lP)
{
 static PAINTSTRUCT ps;
 RECT rc,rcw;
 int xs,ys,x,y;

 switch (msg) {

 case WM_COMMAND:
  wP=LOWORD(wP);
  switch(wP){
   case 101: //nov� hra
    newGame();
   break;
   case 104: //mo�nosti
    if( DialogBox(inst,MAKEINTRESOURCE(4),hWnd,(DLGPROC) optionsProc)
        == IDOK) newGame();
   break;
   case 102: //ulo�it nastaven�
    writeini();
   break;
   case 105: //odstranit nastaven�
    deleteini();
   break;
   case 103: //konec
    DestroyWindow(hWin);
   break;
  }
 break;

 case WM_RBUTTONUP:
  if(selecting){
   ReleaseCapture();
   selecting=false;
   xs=sgn(xp-xk), ys=sgn(yp-yk);
   while(xk!=xp || yk!=yp){
     setO(xk,yk,O2);
     xk+=xs,yk+=ys;
   }
  }
 break;

 case WM_LBUTTONDOWN:
 case WM_RBUTTONDOWN:
  x= LOWORD(lP)/grid+1;
  y= HIWORD(lP)/grid+1;
  if(x>0 && y>0 && x<=width && y<=height && !isFinish)
  if(msg==WM_LBUTTONDOWN){
   if(!T[x][y] && !O[x][y]){
    T[x][y]=true;
    calcNumber(x,y);
    paintSquare(x,y);
    move++;
    printMove();
    if(A[x][y]<0) if(!--remains) isFinish=true;
   }
  }else{
    SetCapture(hWin);
    selecting=true;
    if(T[x][y]) O[x][y]=false;
    setO(xk=xp=x,yk=yp=y,O2=!O[x][y]);
  }
 break;

 case WM_MOUSEMOVE:
  mouseMove(LOWORD(lP)/grid+1, HIWORD(lP)/grid+1);
 break;

 case WM_PAINT:
  fontH=HIWORD(GetDialogBaseUnits());
  GetClientRect(hWnd,&rc);
  GetWindowRect(hWnd,&rcw);
  winWidth= max(18*fontH, int(width*grid+1 + rcw.right-rcw.left-rc.right));
  SetWindowPos(hWnd,0,0,0, winWidth,
    height*grid+4+fontH + rcw.bottom-rcw.top-rc.bottom,
    SWP_NOMOVE|SWP_NOZORDER);
  BeginPaint(hWnd,&ps);
  repaint();
  EndPaint(hWnd, &ps);
 break;

 case WM_MOVE:
  GetWindowRect(hWnd,&rcw);
  top= rcw.top;
  left= rcw.left;
 break;

 case WM_DESTROY:
  PostQuitMessage(0);
 break;

 default:
  return DefWindowProc(hWnd, msg, wP, lP);
}
return 0;
}
//---------------------------------------------------------------------------
int pascal WinMain(HINSTANCE hInstance,HINSTANCE hPrevInst,LPSTR,int cmdShow)
{
 WNDCLASS wc;
 MSG msg;
 HACCEL haccel;
 BITMAP bmp;

 typedef BOOL(WINAPI *TGetProcAddress)();
 TGetProcAddress getProcAddress = (TGetProcAddress) GetProcAddress(GetModuleHandle("user32"), "SetProcessDPIAware");
 if(getProcAddress) getProcAddress();

 readini();
 inst=hInstance;
 lod= LoadBitmap(hInstance, MAKEINTRESOURCE(10));
 GetObject(lod,sizeof(BITMAP),&bmp);
 lodWidth= bmp.bmWidth;
 lodHeight= bmp.bmHeight;

 wc.style= CS_OWNDC;
 wc.lpfnWndProc= MainWndProc;
 wc.cbClsExtra= 0;
 wc.cbWndExtra= 0;
 wc.hInstance= hInstance;
 wc.hIcon= LoadIcon(hInstance, MAKEINTRESOURCE(1));
 wc.hCursor= LoadCursor(NULL, IDC_ARROW);
 wc.hbrBackground= CreateSolidBrush(clPozadi);
 wc.lpszMenuName= MAKEINTRESOURCE(2);
 wc.lpszClassName= "Lode";
 if(!hPrevInst && !RegisterClass(&wc)) return 1;

 hWin = CreateWindow( "Lode", "Lod�",
   WS_OVERLAPPED|WS_MINIMIZEBOX|WS_SYSMENU,
   left,top, CW_USEDEFAULT,CW_USEDEFAULT,
   NULL, NULL, hInstance, NULL);
 if(!hWin) return 2;
 dc= GetDC(hWin);

 randomize();
 newGame();
 haccel=LoadAccelerators(hInstance, MAKEINTRESOURCE(3));
 ShowWindow(hWin, cmdShow);

 while(GetMessage(&msg, NULL, 0, 0)==TRUE)
  if(TranslateAccelerator(hWin,haccel,&msg)==0){
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }

 DeleteObject(lod);
 return 0;
}

