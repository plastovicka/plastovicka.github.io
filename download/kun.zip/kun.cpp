/*
 16.1.2003  Petr Lastovicka

 program se spousti z prikazove radky -  parametry jsou sirka vyska
 vysledek se zapisuje do souboru
 pokud chcete generovat jen uzavrene cesty, pak definujte makro cyclic
   (uzavrena cesta neexistuje, kdyz je sirka a vyska licha)

*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#define cyclic

struct Square {
 int i,n;
};
typedef Square *Psquare;

Psquare board,corner1,corner2,corner3,corner4,last;
FILE *f;

int tah,poli,reseni,width,height,width2,end,poli2,diroff[8],tridit;
#define nxtP(p,i) ((Psquare)(((char*)p)+i))
//---------------------------------------------------------------------------
void out()
{
 int x,y;
 Psquare p=board;

 reseni++;
 for(y=0; y<height+4; y++){
  for(x=0; x<width+4; x++){
    if(p->i>0) fprintf(f,"%3d",p->i);
    p++;
  }
  if(y<height+3 && y>1) fputc('\n',f);
 }
}
//---------------------------------------------------------------------------
void kun1(Psquare p)
{
 int *s;
 Psquare p1;
 int N,d,i,j;
 Psquare t[8],*ut,w,u;

 ++tah;
 p->i=tah;
 if(tah==poli){
   out();
 }else{
   if(p->n==1) end--;
   if(end<2){
    for(s=diroff; s<diroff+8; s++){
      p1=nxtP(p,*s);
      if(!p1->i) if(--p1->n == 1) end++;
    }
    if(end<3){
     ut=t;
     for(s=diroff; s<diroff+8; s++){
       p1=nxtP(p,*s);
       if(!p1->i) *ut++=p1;
     }
     if(tridit){
       d=N=ut-t;
       while((d/=2)>0)
        for(j=0; j<N-d; j++)
         for(i=j; i>=0 && t[i]->n>t[i+d]->n; i-=d)
           w=t[i], t[i]=t[i+d], t[i+d]=w;
     }
     while(--ut>=t){
       u=*ut;
       #ifdef cyclic
       if(u==last && tah+1!=poli) continue;
       #else
       if(!corner1->i && (u==corner2 || u==corner3 || u==corner4)) continue;
       if(u==corner3 && !corner2->i && width==height) continue;
       #endif
       kun1(u);
     }
    }
    for(s=diroff; s<diroff+8; s++){
      p1=nxtP(p,*s);
      if(!p1->i) if(p1->n++ == 1) end--;
    }
   }
   if(p->n==1) end++;
 }
 p->i=0;
 --tah;
}
//---------------------------------------------------------------------------
int main(int argc, char **argv)
{
 int x,y,s;
 Psquare u;
 char fn[256];

 width=height=8;
 if(argc>1){
   width=height=atoi(argv[1]);
   if(argc>2) height=atoi(argv[2]);
 }
 if(width<3) width=3;
 if(height<3) height=3;
 if(width>16) width=16;
 if(height>16) height=16;

 sprintf(fn,
  #ifdef cyclic
   "Kun%dx%dc.txt"
  #else
   "Kun%dx%d.txt"
  #endif
   ,width,height);
 f=fopen(fn,"wt");
 if(!f) return 1;
 reseni=0;
 tridit= width>7 || height>7;
 poli=width*height;
 poli2=(width+4)*(height+4);
 board= new Square[poli2];
 memset(board,0,poli2*sizeof(Square));
 width2=width+4;
 diroff[0]=(+1*width2+2)*sizeof(Square);
 diroff[1]=(+1*width2-2)*sizeof(Square);
 diroff[2]=(-1*width2+2)*sizeof(Square);
 diroff[3]=(-1*width2-2)*sizeof(Square);
 diroff[4]=(+2*width2+1)*sizeof(Square);
 diroff[5]=(+2*width2-1)*sizeof(Square);
 diroff[6]=(-2*width2+1)*sizeof(Square);
 diroff[7]=(-2*width2-1)*sizeof(Square);
 corner1= &board[2*width2+2];
 corner2= &board[3*width2-3];
 corner3= &board[poli2-3*width2+2];
 corner4= &board[poli2-2*width2-3];
 last= &board[4*width2+3];

 u=board;
 for(y=0; y<height+4; y++){
  for(x=0; x<width+4; x++){
    if(x<2 || y<2 || x>width+1 || y>height+1){
      u->i=-1;
    }else{
      for(s=0; s<8; s++) nxtP(u,diroff[s])->n++;
    }
    u++;
   }
  }
 tah=0;
 end=0;
 #ifdef cyclic
   tah++;
   corner1->i=1;
   last->n--;
   board[3*width2+4].n--;
   kun1(board+ 3*width2+4);
 #else
   for(u=corner1; u<corner4; u++){
     if(!u->i && u!=corner2 && u!=corner3) kun1(u);
   }
 #endif
 delete[] board;
 fprintf(f,"Celkem: %d\n",reseni);
 fclose(f);
 return 0;
}

